"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const prisma = new client_1.PrismaClient();
async function main() {
    console.log('🌱 Starting comprehensive database seeding for PLACEMENTHUB...');
    // Clean existing data in reverse order of dependencies
    await prisma.auditLog.deleteMany();
    await prisma.notification.deleteMany();
    await prisma.offer.deleteMany();
    await prisma.interview.deleteMany();
    await prisma.application.deleteMany();
    await prisma.job.deleteMany();
    await prisma.recruiterProfile.deleteMany();
    await prisma.company.deleteMany();
    await prisma.studentProfile.deleteMany();
    await prisma.user.deleteMany();
    const demoPassword = await bcryptjs_1.default.hash('DemoPass123!', 10);
    // 1. Create System Admin
    const adminUser = await prisma.user.create({
        data: {
            email: 'admin@placementhub.demo',
            password: demoPassword,
            role: 'ADMIN',
            isApproved: true,
        },
    });
    // 2. Create Companies
    const nexora = await prisma.company.create({
        data: {
            name: 'Nexora Technologies',
            logo: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=128&h=128&fit=crop',
            industry: 'Enterprise Software & Cloud Platforms',
            website: 'https://nexora.tech',
            description: 'Global cloud solutions and high-performance distributed systems provider.',
            headquarters: 'Bengaluru, India',
            companySize: '1,000-5,000 employees',
            hrContactEmail: 'campus@nexora.tech',
            hrContactPhone: '+91 80 4123 4567',
            isVerified: true,
        },
    });
    const bluepeak = await prisma.company.create({
        data: {
            name: 'BluePeak Solutions',
            logo: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=128&h=128&fit=crop',
            industry: 'FinTech & AI Analytics',
            website: 'https://bluepeaksolutions.io',
            description: 'Pioneering high-frequency fintech analytics and real-time transaction intelligence.',
            headquarters: 'Hyderabad, India',
            companySize: '500-1,000 employees',
            hrContactEmail: 'careers@bluepeaksolutions.io',
            hrContactPhone: '+91 40 6789 0123',
            isVerified: true,
        },
    });
    const vertex = await prisma.company.create({
        data: {
            name: 'Vertex Innovations',
            logo: 'https://images.unsplash.com/photo-1535378917042-10a22c95931a?w=128&h=128&fit=crop',
            industry: 'Autonomous Systems & Embedded IoT',
            website: 'https://vertexinnovations.com',
            description: 'Next-generation robotics, IoT sensory gateways, and automotive edge software.',
            headquarters: 'Pune, India',
            companySize: '250-500 employees',
            hrContactEmail: 'talent@vertexinnovations.com',
            hrContactPhone: '+91 20 2345 6789',
            isVerified: true,
        },
    });
    // 3. Create Demo Recruiter (linked to Nexora)
    const recruiterUser = await prisma.user.create({
        data: {
            email: 'recruiter@placementhub.demo',
            password: demoPassword,
            role: 'RECRUITER',
            isApproved: true,
            recruiterProfile: {
                create: {
                    fullName: 'Vikram Malhotra',
                    designation: 'Senior University Talent Partner',
                    phone: '+91 98765 11223',
                    companyId: nexora.id,
                },
            },
        },
        include: { recruiterProfile: true },
    });
    // Additional Recruiters for BluePeak and Vertex
    await prisma.user.create({
        data: {
            email: 'priya.bluepeak@placementhub.demo',
            password: demoPassword,
            role: 'RECRUITER',
            isApproved: true,
            recruiterProfile: {
                create: {
                    fullName: 'Priya Sharma',
                    designation: 'Head of Campus Relations',
                    phone: '+91 98765 22334',
                    companyId: bluepeak.id,
                },
            },
        },
    });
    // 4. Create 5+ Job Openings
    const deadlineFuture = new Date();
    deadlineFuture.setDate(deadlineFuture.getDate() + 30);
    const jobNexoraSde = await prisma.job.create({
        data: {
            companyId: nexora.id,
            title: 'Graduate Software Development Engineer (SDE-1)',
            description: 'Design and implement scalable microservices using TypeScript, Node.js, and Kubernetes. Work with distributed databases and high-throughput event buses.',
            location: 'Bengaluru / Hybrid',
            employmentType: 'FULL_TIME',
            salaryRange: '14 - 18 LPA',
            minSalary: 14.0,
            maxSalary: 18.0,
            vacancies: 15,
            selectionProcess: 'Online Assessment -> Technical Interview 1 -> Technical Interview 2 -> HR Culture Fit',
            status: 'PUBLISHED',
            applicationDeadline: deadlineFuture,
            minCgpa: 7.5,
            maxActiveBacklogs: 0,
            eligibleDepartments: JSON.stringify(['CSE', 'IT', 'ECE']),
            eligibleGraduationYears: JSON.stringify([2025, 2026]),
            requiredSkills: JSON.stringify(['JavaScript', 'Node.js', 'React', 'Data Structures', 'SQL']),
        },
    });
    const jobNexoraCloud = await prisma.job.create({
        data: {
            companyId: nexora.id,
            title: 'Cloud Infrastructure & DevOps Engineer',
            description: 'Build automated CI/CD deployment pipelines, manage AWS/GCP multi-region clusters, and implement site reliability engineering best practices.',
            location: 'Hyderabad / Bengaluru',
            employmentType: 'FULL_TIME',
            salaryRange: '12 - 15 LPA',
            minSalary: 12.0,
            maxSalary: 15.0,
            vacancies: 8,
            selectionProcess: 'Aptitude Test -> Systems Practical Round -> Technical Interview -> Managerial Round',
            status: 'PUBLISHED',
            applicationDeadline: deadlineFuture,
            minCgpa: 7.0,
            maxActiveBacklogs: 0,
            eligibleDepartments: JSON.stringify(['CSE', 'IT', 'ECE', 'EEE']),
            eligibleGraduationYears: JSON.stringify([2025, 2026]),
            requiredSkills: JSON.stringify(['Linux', 'Docker', 'AWS', 'Python', 'Networking']),
        },
    });
    const jobBluepeakFintech = await prisma.job.create({
        data: {
            companyId: bluepeak.id,
            title: 'Quantitative Systems Analyst',
            description: 'Analyze real-time transaction datasets, optimize algorithmic execution engines, and construct predictive analytical models.',
            location: 'Mumbai / Hyderabad',
            employmentType: 'FULL_TIME',
            salaryRange: '16 - 22 LPA',
            minSalary: 16.0,
            maxSalary: 22.0,
            vacancies: 6,
            selectionProcess: 'Math & Coding Assessment -> Technical Deep Dive -> Leadership Interview',
            status: 'PUBLISHED',
            applicationDeadline: deadlineFuture,
            minCgpa: 8.0,
            maxActiveBacklogs: 0,
            eligibleDepartments: JSON.stringify(['CSE', 'IT']),
            eligibleGraduationYears: JSON.stringify([2025, 2026]),
            requiredSkills: JSON.stringify(['Python', 'Data Structures', 'SQL', 'Algorithms', 'Mathematics']),
        },
    });
    const jobBluepeakFrontend = await prisma.job.create({
        data: {
            companyId: bluepeak.id,
            title: 'Frontend Product Engineer (React / TypeScript)',
            description: 'Craft responsive, high-performance web dashboards for institutional financial traders and market analytics suites.',
            location: 'Hyderabad / Remote',
            employmentType: 'FULL_TIME',
            salaryRange: '10 - 13 LPA',
            minSalary: 10.0,
            maxSalary: 13.0,
            vacancies: 10,
            selectionProcess: 'Frontend Take-home Task -> Live Pair Programming -> Team Fit',
            status: 'PUBLISHED',
            applicationDeadline: deadlineFuture,
            minCgpa: 6.5,
            maxActiveBacklogs: 1,
            eligibleDepartments: JSON.stringify(['CSE', 'IT', 'ECE', 'AI & DS']),
            eligibleGraduationYears: JSON.stringify([2025, 2026, 2027]),
            requiredSkills: JSON.stringify(['React', 'TypeScript', 'Tailwind CSS', 'Next.js', 'UI/UX']),
        },
    });
    const jobVertexEmbedded = await prisma.job.create({
        data: {
            companyId: vertex.id,
            title: 'Embedded Systems & IoT Firmware Engineer',
            description: 'Develop low-level C/C++ firmware for microcontrollers, RTOS kernels, CAN bus communication, and sensor interface peripherals.',
            location: 'Pune',
            employmentType: 'FULL_TIME',
            salaryRange: '9 - 12 LPA',
            minSalary: 9.0,
            maxSalary: 12.0,
            vacancies: 5,
            selectionProcess: 'Embedded Quiz -> Lab Hardware Coding -> Technical Interview -> HR Round',
            status: 'PUBLISHED',
            applicationDeadline: deadlineFuture,
            minCgpa: 6.8,
            maxActiveBacklogs: 0,
            eligibleDepartments: JSON.stringify(['ECE', 'EEE', 'Mechanical Engineering']),
            eligibleGraduationYears: JSON.stringify([2025, 2026]),
            requiredSkills: JSON.stringify(['C', 'C++', 'Microcontrollers', 'RTOS', 'Embedded Systems']),
        },
    });
    const jobPendingAdmin = await prisma.job.create({
        data: {
            companyId: vertex.id,
            title: 'Robotics Perception & Computer Vision Intern',
            description: 'Research edge vision algorithms for automated warehouse navigation using OpenCV and PyTorch.',
            location: 'Pune / Bengaluru',
            employmentType: 'INTERNSHIP',
            salaryRange: '45,000/month stipend',
            minSalary: 5.4,
            maxSalary: 5.4,
            vacancies: 4,
            selectionProcess: 'Portfolio Review -> Research Interview',
            status: 'PENDING_APPROVAL', // Needs Admin Approval
            applicationDeadline: deadlineFuture,
            minCgpa: 7.0,
            maxActiveBacklogs: 0,
            eligibleDepartments: JSON.stringify(['CSE', 'ECE', 'AI & DS']),
            eligibleGraduationYears: JSON.stringify([2026, 2027]),
            requiredSkills: JSON.stringify(['Python', 'OpenCV', 'PyTorch', 'Computer Vision']),
        },
    });
    // 5. Create 20 Fictional Students
    const studentSeeds = [
        {
            name: 'Aarav Sharma',
            email: 'student@placementhub.demo', // Primary Demo Student
            studentId: '21CS001',
            dept: 'CSE',
            gradYear: 2025,
            cgpa: 8.85,
            backlogs: 0,
            skills: ['JavaScript', 'Node.js', 'React', 'Data Structures', 'SQL', 'TypeScript'],
            tenth: 92.5,
            twelfth: 90.0,
        },
        {
            name: 'Ananya Verma',
            email: 'ananya.verma@demo.univ.edu',
            studentId: '21CS002',
            dept: 'CSE',
            gradYear: 2025,
            cgpa: 9.42,
            backlogs: 0,
            skills: ['Python', 'Data Structures', 'SQL', 'Algorithms', 'Mathematics', 'C++'],
            tenth: 96.0,
            twelfth: 94.5,
        },
        {
            name: 'Rohan Iyer',
            email: 'rohan.iyer@demo.univ.edu',
            studentId: '21IT003',
            dept: 'IT',
            gradYear: 2025,
            cgpa: 7.82,
            backlogs: 0,
            skills: ['React', 'TypeScript', 'Tailwind CSS', 'Node.js', 'MongoDB'],
            tenth: 84.0,
            twelfth: 82.5,
        },
        {
            name: 'Sneha Patel',
            email: 'sneha.patel@demo.univ.edu',
            studentId: '21EC004',
            dept: 'ECE',
            gradYear: 2025,
            cgpa: 8.10,
            backlogs: 0,
            skills: ['C', 'C++', 'Microcontrollers', 'Linux', 'Data Structures'],
            tenth: 89.0,
            twelfth: 87.0,
        },
        {
            name: 'Karthik Nair',
            email: 'karthik.nair@demo.univ.edu',
            studentId: '21EE005',
            dept: 'EEE',
            gradYear: 2025,
            cgpa: 7.15,
            backlogs: 0,
            skills: ['C', 'MATLAB', 'Microcontrollers', 'Embedded Systems'],
            tenth: 81.0,
            twelfth: 79.5,
        },
        {
            name: 'Diya Sengupta',
            email: 'diya.sengupta@demo.univ.edu',
            studentId: '21CS006',
            dept: 'CSE',
            gradYear: 2025,
            cgpa: 6.45, // Ineligible for 7.5+ cutoffs
            backlogs: 1, // Has 1 active backlog
            skills: ['JavaScript', 'HTML/CSS', 'Python'],
            tenth: 75.0,
            twelfth: 72.0,
        },
        {
            name: 'Aditya Kulkarni',
            email: 'aditya.kulkarni@demo.univ.edu',
            studentId: '21ME007',
            dept: 'Mechanical Engineering',
            gradYear: 2025,
            cgpa: 7.60,
            backlogs: 0,
            skills: ['AutoCAD', 'SolidWorks', 'Python', 'MATLAB'],
            tenth: 85.0,
            twelfth: 83.0,
        },
        {
            name: 'Meera Rao',
            email: 'meera.rao@demo.univ.edu',
            studentId: '21IT008',
            dept: 'IT',
            gradYear: 2025,
            cgpa: 8.65,
            backlogs: 0,
            skills: ['Python', 'SQL', 'AWS', 'Docker', 'Linux', 'Node.js'],
            tenth: 91.0,
            twelfth: 88.5,
        },
        {
            name: 'Varun Reddy',
            email: 'varun.reddy@demo.univ.edu',
            studentId: '21EC009',
            dept: 'ECE',
            gradYear: 2025,
            cgpa: 7.95,
            backlogs: 0,
            skills: ['C', 'C++', 'RTOS', 'Python', 'Networking'],
            tenth: 86.5,
            twelfth: 85.0,
        },
        {
            name: 'Ishaan Gupta',
            email: 'ishaan.gupta@demo.univ.edu',
            studentId: '21CS010',
            dept: 'CSE',
            gradYear: 2025,
            cgpa: 8.90,
            backlogs: 0,
            skills: ['Java', 'Spring Boot', 'Data Structures', 'SQL', 'Docker'],
            tenth: 93.0,
            twelfth: 91.5,
        },
        {
            name: 'Tanvi Joshi',
            email: 'tanvi.joshi@demo.univ.edu',
            studentId: '22CS011',
            dept: 'CSE',
            gradYear: 2026,
            cgpa: 8.75,
            backlogs: 0,
            skills: ['React', 'TypeScript', 'Node.js', 'Data Structures'],
            tenth: 90.0,
            twelfth: 89.0,
        },
        {
            name: 'Siddharth Jain',
            email: 'siddharth.jain@demo.univ.edu',
            studentId: '22IT012',
            dept: 'IT',
            gradYear: 2026,
            cgpa: 7.40,
            backlogs: 0,
            skills: ['JavaScript', 'Python', 'SQL', 'Git'],
            tenth: 82.0,
            twelfth: 80.0,
        },
        {
            name: 'Pooja Hegde',
            email: 'pooja.hegde@demo.univ.edu',
            studentId: '22EC013',
            dept: 'ECE',
            gradYear: 2026,
            cgpa: 8.30,
            backlogs: 0,
            skills: ['C', 'Embedded Systems', 'Verilog', 'Microcontrollers'],
            tenth: 88.0,
            twelfth: 86.0,
        },
        {
            name: 'Nikhil Saxena',
            email: 'nikhil.saxena@demo.univ.edu',
            studentId: '21CS014',
            dept: 'CSE',
            gradYear: 2025,
            cgpa: 6.20,
            backlogs: 2,
            skills: ['PHP', 'MySQL', 'JavaScript'],
            tenth: 71.0,
            twelfth: 69.5,
        },
        {
            name: 'Bhavna Menon',
            email: 'bhavna.menon@demo.univ.edu',
            studentId: '21IT015',
            dept: 'IT',
            gradYear: 2025,
            cgpa: 9.15,
            backlogs: 0,
            skills: ['Python', 'Data Structures', 'Machine Learning', 'SQL', 'React'],
            tenth: 95.0,
            twelfth: 93.0,
        },
        {
            name: 'Gaurav Bhatia',
            email: 'gaurav.bhatia@demo.univ.edu',
            studentId: '21EE016',
            dept: 'EEE',
            gradYear: 2025,
            cgpa: 7.55,
            backlogs: 0,
            skills: ['Linux', 'Networking', 'Python', 'Docker'],
            tenth: 83.5,
            twelfth: 81.0,
        },
        {
            name: 'Ritu Deshmukh',
            email: 'ritu.deshmukh@demo.univ.edu',
            studentId: '21CE017',
            dept: 'Civil Engineering',
            gradYear: 2025,
            cgpa: 7.80,
            backlogs: 0,
            skills: ['AutoCAD', 'Revit', 'Project Management'],
            tenth: 84.0,
            twelfth: 82.0,
        },
        {
            name: 'Ayush Singhal',
            email: 'ayush.singhal@demo.univ.edu',
            studentId: '22CS018',
            dept: 'CSE',
            gradYear: 2026,
            cgpa: 8.50,
            backlogs: 0,
            skills: ['JavaScript', 'TypeScript', 'Node.js', 'React', 'MongoDB'],
            tenth: 89.0,
            twelfth: 88.0,
        },
        {
            name: 'Kavya Pillai',
            email: 'kavya.pillai@demo.univ.edu',
            studentId: '21EC019',
            dept: 'ECE',
            gradYear: 2025,
            cgpa: 8.40,
            backlogs: 0,
            skills: ['C++', 'RTOS', 'Microcontrollers', 'Embedded Systems'],
            tenth: 90.0,
            twelfth: 87.5,
        },
        {
            name: 'Mohit Agarwal',
            email: 'mohit.agarwal@demo.univ.edu',
            studentId: '22IT020',
            dept: 'IT',
            gradYear: 2026,
            cgpa: 7.90,
            backlogs: 0,
            skills: ['Python', 'SQL', 'AWS', 'Docker'],
            tenth: 85.0,
            twelfth: 84.0,
        },
    ];
    const createdStudents = [];
    for (const s of studentSeeds) {
        const user = await prisma.user.create({
            data: {
                email: s.email,
                password: demoPassword,
                role: 'STUDENT',
                isApproved: true,
                studentProfile: {
                    create: {
                        fullName: s.name,
                        studentId: s.studentId,
                        collegeEmail: s.email,
                        phone: '+91 9' + Math.floor(100000000 + Math.random() * 900000000),
                        department: s.dept,
                        course: 'B.Tech',
                        graduationYear: s.gradYear,
                        cgpa: s.cgpa,
                        backlogs: s.backlogs,
                        activeBacklogs: s.backlogs,
                        tenthPercentage: s.tenth,
                        twelfthPercentage: s.twelfth,
                        graduationStatus: 'PURSUING',
                        technicalSkills: JSON.stringify(s.skills),
                        programmingLanguages: JSON.stringify(['JavaScript', 'Python', 'C++']),
                        certifications: JSON.stringify([
                            { title: 'AWS Cloud Practitioner', issuer: 'Amazon Web Services', year: '2024' },
                            { title: 'Full Stack Open', issuer: 'University of Helsinki', year: '2023' },
                        ]),
                        projects: JSON.stringify([
                            {
                                title: 'High-Throughput Microservice Gateway',
                                techStack: 'Node.js, Redis, Docker',
                                description: 'Engineered rate limiting and authentication proxy handling 5000+ req/sec.',
                                link: 'https://github.com/example/gateway',
                            },
                        ]),
                        internshipExperience: JSON.stringify([
                            {
                                role: 'Software Development Intern',
                                company: 'HyperTech Labs',
                                duration: 'Summer 2024 (3 months)',
                                description: 'Refactored reporting queries resulting in 40% performance gain.',
                            },
                        ]),
                        linkedInUrl: `https://linkedin.com/in/${s.name.toLowerCase().replace(/\s+/g, '-')}`,
                        gitHubUrl: `https://github.com/${s.name.toLowerCase().replace(/\s+/g, '')}`,
                        resumeUrl: `/uploads/resumes/sample-resume-${s.studentId}.pdf`,
                        resumeFilename: `${s.name.replace(/\s+/g, '_')}_Resume.pdf`,
                        resumeUpdatedAt: new Date(),
                        profileCompletion: 92,
                    },
                },
            },
            include: { studentProfile: true },
        });
        createdStudents.push(user.studentProfile);
    }
    // 6. Create realistic application records with varied statuses
    const primaryStudent = createdStudents[0]; // Aarav Sharma (student@placementhub.demo)
    const topStudent = createdStudents[1]; // Ananya Verma (9.42 CGPA)
    const itStudent = createdStudents[2]; // Rohan Iyer
    const eceStudent = createdStudents[3]; // Sneha Patel
    // App 1: Primary Student applied to Nexora SDE -> SELECTED & OFFERED!
    const app1 = await prisma.application.create({
        data: {
            studentId: primaryStudent.id,
            jobId: jobNexoraSde.id,
            status: 'SELECTED',
            resumeUrl: primaryStudent.resumeUrl,
            notes: 'Strong candidate with deep knowledge of React and Distributed Node systems.',
            eligibilityReport: JSON.stringify({
                isEligible: true,
                canApply: true,
                criteriaBreakdown: [
                    { name: 'Minimum CGPA', status: 'PASS', message: 'CGPA requirement satisfied (8.85 ≥ 7.50)', required: 7.5, studentValue: 8.85 },
                    { name: 'Active Backlogs', status: 'PASS', message: 'Active backlog requirement satisfied (0 ≤ 0)', required: 0, studentValue: 0 },
                    { name: 'Eligible Department', status: 'PASS', message: 'Department requirement satisfied (CSE)', required: ['CSE', 'IT', 'ECE'], studentValue: 'CSE' },
                    { name: 'Graduation Year', status: 'PASS', message: 'Graduation year requirement satisfied (2025)', required: [2025, 2026], studentValue: 2025 },
                ],
                passedReasons: ['CGPA requirement satisfied.', 'Active backlog requirement satisfied.', 'Department requirement satisfied.', 'Graduation year requirement satisfied.'],
                failedReasons: [],
                skillMatch: { matchPercentage: 100, matchedSkills: ['JavaScript', 'Node.js', 'React', 'Data Structures', 'SQL'], missingSkills: [] },
            }),
        },
    });
    // Schedule Interview for App 1 (Completed)
    await prisma.interview.create({
        data: {
            applicationId: app1.id,
            studentId: primaryStudent.id,
            jobId: jobNexoraSde.id,
            round: 'TECHNICAL',
            scheduledDate: '2026-11-05',
            scheduledTime: '10:00 AM',
            durationMinutes: 60,
            mode: 'ONLINE',
            meetingLink: 'https://meet.google.com/nex-sde-round1',
            status: 'COMPLETED',
            feedback: 'Excellent problem solving skills, solved graph traversal question in 20 minutes.',
            result: 'PASSED',
        },
    });
    await prisma.interview.create({
        data: {
            applicationId: app1.id,
            studentId: primaryStudent.id,
            jobId: jobNexoraSde.id,
            round: 'FINAL',
            scheduledDate: '2026-11-08',
            scheduledTime: '02:30 PM',
            durationMinutes: 45,
            mode: 'ONLINE',
            meetingLink: 'https://meet.google.com/nex-sde-round2',
            status: 'COMPLETED',
            feedback: 'Strong leadership traits and clear communicator. Recommended for immediate offer.',
            result: 'PASSED',
        },
    });
    // Create Offer for App 1
    await prisma.offer.create({
        data: {
            applicationId: app1.id,
            studentId: primaryStudent.id,
            jobId: jobNexoraSde.id,
            companyId: nexora.id,
            ctc: '16.5 LPA',
            designation: 'Software Development Engineer - I',
            location: 'Bengaluru, India',
            joiningDate: '2026-07-01',
            status: 'ACCEPTED',
        },
    });
    // App 2: Primary Student applied to BluePeak Fintech -> INTERVIEW SCHEDULED!
    const app2 = await prisma.application.create({
        data: {
            studentId: primaryStudent.id,
            jobId: jobBluepeakFintech.id,
            status: 'INTERVIEW_SCHEDULED',
            resumeUrl: primaryStudent.resumeUrl,
            eligibilityReport: JSON.stringify({
                isEligible: true,
                canApply: true,
                criteriaBreakdown: [
                    { name: 'Minimum CGPA', status: 'PASS', message: 'CGPA requirement satisfied (8.85 ≥ 8.00)', required: 8.0, studentValue: 8.85 },
                    { name: 'Active Backlogs', status: 'PASS', message: 'Active backlog requirement satisfied (0 ≤ 0)', required: 0, studentValue: 0 },
                    { name: 'Eligible Department', status: 'PASS', message: 'Department requirement satisfied (CSE)', required: ['CSE', 'IT'], studentValue: 'CSE' },
                    { name: 'Graduation Year', status: 'PASS', message: 'Graduation year requirement satisfied (2025)', required: [2025, 2026], studentValue: 2025 },
                ],
                passedReasons: ['CGPA requirement satisfied.', 'Active backlog requirement satisfied.', 'Department requirement satisfied.', 'Graduation year requirement satisfied.'],
                failedReasons: [],
                skillMatch: { matchPercentage: 60, matchedSkills: ['Data Structures', 'SQL', 'Algorithms'], missingSkills: ['Python', 'Mathematics'] },
            }),
        },
    });
    await prisma.interview.create({
        data: {
            applicationId: app2.id,
            studentId: primaryStudent.id,
            jobId: jobBluepeakFintech.id,
            round: 'TECHNICAL',
            scheduledDate: '2026-11-12',
            scheduledTime: '11:00 AM',
            durationMinutes: 60,
            mode: 'ONLINE',
            meetingLink: 'https://bluepeak.zoom.us/j/9128392182',
            instructions: 'Please be in a quiet room with IDE prepared for algorithmic coding exercise.',
            status: 'SCHEDULED',
            result: 'PENDING',
        },
    });
    // App 3: Top Student (Ananya Verma) -> OFFERED BluePeak Fintech 20 LPA!
    const app3 = await prisma.application.create({
        data: {
            studentId: topStudent.id,
            jobId: jobBluepeakFintech.id,
            status: 'SELECTED',
            resumeUrl: topStudent.resumeUrl,
            notes: 'Rank 1 candidate, scored 100% on Quantitative assessment.',
        },
    });
    await prisma.offer.create({
        data: {
            applicationId: app3.id,
            studentId: topStudent.id,
            jobId: jobBluepeakFintech.id,
            companyId: bluepeak.id,
            ctc: '21.0 LPA',
            designation: 'Quantitative Systems Analyst',
            location: 'Hyderabad, India',
            joiningDate: '2026-06-15',
            status: 'OFFERED',
        },
    });
    // App 4: IT Student (Rohan Iyer) -> SHORTLISTED for BluePeak Frontend
    await prisma.application.create({
        data: {
            studentId: itStudent.id,
            jobId: jobBluepeakFrontend.id,
            status: 'SHORTLISTED',
            resumeUrl: itStudent.resumeUrl,
            notes: 'Impressive portfolio of React applications.',
        },
    });
    // App 5: ECE Student (Sneha Patel) -> OFFERED Vertex Embedded
    const app5 = await prisma.application.create({
        data: {
            studentId: eceStudent.id,
            jobId: jobVertexEmbedded.id,
            status: 'SELECTED',
            resumeUrl: eceStudent.resumeUrl,
            notes: 'Hands-on experience with ARM Cortex and RTOS scheduling.',
        },
    });
    await prisma.offer.create({
        data: {
            applicationId: app5.id,
            studentId: eceStudent.id,
            jobId: jobVertexEmbedded.id,
            companyId: vertex.id,
            ctc: '11.5 LPA',
            designation: 'Embedded Systems Engineer',
            location: 'Pune, India',
            joiningDate: '2026-07-15',
            status: 'ACCEPTED',
        },
    });
    // 7. Seed Notifications for Primary Student
    const primaryUserId = (await prisma.studentProfile.findUnique({ where: { id: primaryStudent.id } })).userId;
    await prisma.notification.createMany({
        data: [
            {
                userId: primaryUserId,
                title: '🌟 Placement Offer Received!',
                message: 'Congratulations! Nexora Technologies has extended an official placement offer for Software Development Engineer - I with package 16.5 LPA.',
                type: 'OFFER',
                link: '/offers',
                isRead: false,
            },
            {
                userId: primaryUserId,
                title: '📅 Interview Scheduled: Technical Round',
                message: 'BluePeak Solutions has scheduled your Technical interview on 2026-11-12 at 11:00 AM (ONLINE).',
                type: 'INTERVIEW',
                link: '/interviews',
                isRead: false,
            },
            {
                userId: primaryUserId,
                title: 'Application Submitted',
                message: 'Your application for Graduate Software Development Engineer at Nexora Technologies has been received.',
                type: 'APPLICATION',
                link: '/applications',
                isRead: true,
            },
        ],
    });
    // 8. Seed Audit Logs
    await prisma.auditLog.createMany({
        data: [
            {
                userEmail: 'admin@placementhub.demo',
                userRole: 'ADMIN',
                action: 'COMPANY_VERIFIED',
                entityType: 'Company',
                entityId: nexora.id,
                details: JSON.stringify({ company: 'Nexora Technologies', status: 'VERIFIED' }),
            },
            {
                userEmail: 'admin@placementhub.demo',
                userRole: 'ADMIN',
                action: 'JOB_APPROVED',
                entityType: 'Job',
                entityId: jobNexoraSde.id,
                details: JSON.stringify({ jobTitle: 'Graduate Software Development Engineer (SDE-1)', company: 'Nexora Technologies' }),
            },
            {
                userEmail: 'student@placementhub.demo',
                userRole: 'STUDENT',
                action: 'APPLICATION_SUBMITTED',
                entityType: 'Application',
                entityId: app1.id,
                details: JSON.stringify({ jobTitle: 'Graduate Software Development Engineer (SDE-1)', candidate: 'Aarav Sharma' }),
            },
            {
                userEmail: 'recruiter@placementhub.demo',
                userRole: 'RECRUITER',
                action: 'OFFER_EXTENDED',
                entityType: 'Offer',
                entityId: app1.id,
                details: JSON.stringify({ candidate: 'Aarav Sharma', ctc: '16.5 LPA', designation: 'Software Development Engineer - I' }),
            },
        ],
    });
    console.log('✅ Database seeded successfully with:');
    console.log(` - 20 Students (including primary demo: student@placementhub.demo)`);
    console.log(` - 3 Companies (Nexora Technologies, BluePeak Solutions, Vertex Innovations)`);
    console.log(` - 6 Job Openings with varied criteria and status`);
    console.log(` - Realistic Applications, Interviews, Offers, Notifications, and Audit Logs`);
    console.log(` - Demo Accounts Password: DemoPass123!`);
}
main()
    .catch((e) => {
    console.error('Seeding failed:', e);
    process.exit(1);
})
    .finally(async () => {
    await prisma.$disconnect();
});
