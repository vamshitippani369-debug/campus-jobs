export interface StudentAcademicData {
  id: string;
  fullName: string;
  department: string;
  graduationYear: number;
  cgpa: number;
  activeBacklogs: number;
  backlogs?: number;
  technicalSkills?: string[];
  resumeUrl?: string | null;
  profileCompletion?: number;
}

export interface JobCriteriaData {
  id: string;
  title: string;
  status: string;
  minCgpa: number;
  maxActiveBacklogs: number;
  eligibleDepartments: string[]; // e.g. ["CSE", "IT", "ECE"] or full names
  eligibleGraduationYears: number[]; // e.g. [2025, 2026, 2027]
  requiredSkills?: string[];
  applicationDeadline: Date | string;
}

export interface CriterionResult {
  name: string;
  status: 'PASS' | 'FAIL';
  message: string;
  required: string | number | string[] | number[];
  studentValue: string | number | null;
}

export interface SkillMatchResult {
  matchPercentage: number;
  matchedSkills: string[];
  missingSkills: string[];
}

export interface EligibilityReport {
  isEligible: boolean;
  canApply: boolean;
  blockReason?: string;
  criteriaBreakdown: CriterionResult[];
  passedReasons: string[];
  failedReasons: string[];
  skillMatch: SkillMatchResult;
  evaluatedAt: string;
}

export class EligibilityService {
  /**
   * Normalizes department strings for robust matching:
   * e.g., "Computer Science & Engineering" -> matches "CSE" or "Computer Science"
   */
  private static normalizeDept(dept: string): string[] {
    const d = dept.toLowerCase().trim();
    const aliases: { [key: string]: string[] } = {
      cse: ['cse', 'computer science', 'computer science & engineering', 'cs'],
      it: ['it', 'information technology'],
      ece: ['ece', 'electronics & communication engineering', 'electronics and communication'],
      eee: ['eee', 'electrical & electronics engineering', 'electrical and electronics'],
      me: ['me', 'mechanical engineering', 'mechanical'],
      ce: ['ce', 'civil engineering', 'civil'],
      ai_ds: ['ai & ds', 'aids', 'artificial intelligence & data science', 'artificial intelligence', 'data science'],
    };

    for (const [key, list] of Object.entries(aliases)) {
      if (list.some(alias => d.includes(alias) || alias.includes(d))) {
        return [...list, key];
      }
    }
    return [d];
  }

  private static checkDepartmentMatch(studentDept: string, eligibleDepts: string[]): boolean {
    if (!eligibleDepts || eligibleDepts.length === 0) return true;
    const studentAliases = this.normalizeDept(studentDept);
    
    return eligibleDepts.some(eligibleDept => {
      const elAliases = this.normalizeDept(eligibleDept);
      return studentAliases.some(s => elAliases.includes(s));
    });
  }

  /**
   * Evaluates student eligibility against job requirements deterministically
   */
  public static evaluate(
    student: StudentAcademicData,
    job: JobCriteriaData
  ): EligibilityReport {
    const criteriaBreakdown: CriterionResult[] = [];
    const passedReasons: string[] = [];
    const failedReasons: string[] = [];

    // 1. CGPA Criterion
    const isCgpaPass = student.cgpa >= job.minCgpa;
    if (isCgpaPass) {
      criteriaBreakdown.push({
        name: 'Minimum CGPA',
        status: 'PASS',
        message: `CGPA requirement satisfied (${student.cgpa.toFixed(2)} ≥ ${job.minCgpa.toFixed(2)})`,
        required: job.minCgpa,
        studentValue: student.cgpa,
      });
      passedReasons.push(`CGPA requirement satisfied.`);
    } else {
      criteriaBreakdown.push({
        name: 'Minimum CGPA',
        status: 'FAIL',
        message: `Minimum CGPA required: ${job.minCgpa.toFixed(2)}. Your current CGPA: ${student.cgpa.toFixed(2)}`,
        required: job.minCgpa,
        studentValue: student.cgpa,
      });
      failedReasons.push(`Minimum CGPA required is ${job.minCgpa.toFixed(2)}, but your CGPA is ${student.cgpa.toFixed(2)}.`);
    }

    // 2. Active Backlogs Criterion
    const isBacklogPass = student.activeBacklogs <= job.maxActiveBacklogs;
    if (isBacklogPass) {
      criteriaBreakdown.push({
        name: 'Active Backlogs',
        status: 'PASS',
        message: `Active backlog requirement satisfied (${student.activeBacklogs} ≤ ${job.maxActiveBacklogs})`,
        required: job.maxActiveBacklogs,
        studentValue: student.activeBacklogs,
      });
      passedReasons.push(`Active backlog requirement satisfied.`);
    } else {
      criteriaBreakdown.push({
        name: 'Active Backlogs',
        status: 'FAIL',
        message: `Maximum allowed active backlogs: ${job.maxActiveBacklogs}. Your active backlogs: ${student.activeBacklogs}`,
        required: job.maxActiveBacklogs,
        studentValue: student.activeBacklogs,
      });
      failedReasons.push(`Maximum allowed active backlogs is ${job.maxActiveBacklogs}, but you have ${student.activeBacklogs} active backlog(s).`);
    }

    // 3. Department Criterion
    const isDeptPass = this.checkDepartmentMatch(student.department, job.eligibleDepartments);
    if (isDeptPass) {
      criteriaBreakdown.push({
        name: 'Eligible Department',
        status: 'PASS',
        message: `Department requirement satisfied (${student.department})`,
        required: job.eligibleDepartments,
        studentValue: student.department,
      });
      passedReasons.push(`Department requirement satisfied.`);
    } else {
      criteriaBreakdown.push({
        name: 'Eligible Department',
        status: 'FAIL',
        message: `Your department (${student.department}) is not among the eligible departments (${job.eligibleDepartments.join(', ')})`,
        required: job.eligibleDepartments,
        studentValue: student.department,
      });
      failedReasons.push(`Eligible departments: ${job.eligibleDepartments.join(', ')}. Your department is ${student.department}.`);
    }

    // 4. Graduation Year Criterion
    const isYearPass =
      !job.eligibleGraduationYears ||
      job.eligibleGraduationYears.length === 0 ||
      job.eligibleGraduationYears.includes(Number(student.graduationYear));

    if (isYearPass) {
      criteriaBreakdown.push({
        name: 'Graduation Year',
        status: 'PASS',
        message: `Graduation year requirement satisfied (${student.graduationYear})`,
        required: job.eligibleGraduationYears,
        studentValue: student.graduationYear,
      });
      passedReasons.push(`Graduation year requirement satisfied.`);
    } else {
      criteriaBreakdown.push({
        name: 'Graduation Year',
        status: 'FAIL',
        message: `Graduation year ${student.graduationYear} is not eligible. Required batch: ${job.eligibleGraduationYears.join(', ')}`,
        required: job.eligibleGraduationYears,
        studentValue: student.graduationYear,
      });
      failedReasons.push(`Eligible graduation batches: ${job.eligibleGraduationYears.join(', ')}. Your batch is ${student.graduationYear}.`);
    }

    // Overall academic eligibility
    const isEligible = isCgpaPass && isBacklogPass && isDeptPass && isYearPass;

    // Check additional blockers for applying
    let canApply = isEligible;
    let blockReason: string | undefined;

    // A. Job Status Check
    if (job.status !== 'PUBLISHED') {
      canApply = false;
      blockReason = `Recruitment drive is currently ${job.status.toLowerCase().replace('_', ' ')}`;
    }

    // B. Deadline Check
    const deadline = new Date(job.applicationDeadline);
    if (new Date() > deadline) {
      canApply = false;
      blockReason = 'Application deadline has passed';
    }

    // C. Resume check
    if (!student.resumeUrl) {
      canApply = false;
      blockReason = blockReason || 'Please upload a PDF resume in your profile before applying';
    }

    // 5. Skills Matching Analysis (Informational & scoring)
    const studentSkills = (student.technicalSkills || []).map(s => s.toLowerCase().trim());
    const requiredSkills = (job.requiredSkills || []).map(s => s.trim());
    
    const matchedSkills: string[] = [];
    const missingSkills: string[] = [];

    requiredSkills.forEach(reqSkill => {
      const isMatched = studentSkills.some(s => s.toLowerCase() === reqSkill.toLowerCase());
      if (isMatched) {
        matchedSkills.push(reqSkill);
      } else {
        missingSkills.push(reqSkill);
      }
    });

    const matchPercentage = requiredSkills.length > 0
      ? Math.round((matchedSkills.length / requiredSkills.length) * 100)
      : 100;

    return {
      isEligible,
      canApply,
      blockReason,
      criteriaBreakdown,
      passedReasons,
      failedReasons,
      skillMatch: {
        matchPercentage,
        matchedSkills,
        missingSkills,
      },
      evaluatedAt: new Date().toISOString(),
    };
  }
}

