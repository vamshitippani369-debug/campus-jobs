import { prisma } from '../config/db.js';

export class AuditService {
  public static async log(data: {
    userId?: string;
    userEmail: string;
    userRole: string;
    action: string;
    entityType: string;
    entityId?: string;
    details?: any;
  }) {
    try {
      return await prisma.auditLog.create({
        data: {
          userId: data.userId || null,
          userEmail: data.userEmail,
          userRole: data.userRole,
          action: data.action,
          entityType: data.entityType,
          entityId: data.entityId || null,
          details: data.details ? JSON.stringify(data.details) : null,
        },
      });
    } catch (error) {
      console.error('AuditLog error:', error);
      return null;
    }
  }
}

