import { prisma } from '../config/db.js';

export class NotificationService {
  public static async createNotification(data: {
    userId: string;
    title: string;
    message: string;
    type?: 'APPLICATION' | 'INTERVIEW' | 'OFFER' | 'SYSTEM' | 'JOB';
    link?: string;
  }) {
    try {
      return await prisma.notification.create({
        data: {
          userId: data.userId,
          title: data.title,
          message: data.message,
          type: data.type || 'SYSTEM',
          link: data.link,
        },
      });
    } catch (error) {
      console.error('Error creating notification:', error);
      return null;
    }
  }

  public static async notifyAllStudents(data: {
    title: string;
    message: string;
    type?: 'JOB' | 'SYSTEM';
    link?: string;
  }) {
    try {
      const studentUsers = await prisma.user.findMany({
        where: { role: 'STUDENT' },
        select: { id: true },
      });

      if (studentUsers.length === 0) return;

      await prisma.notification.createMany({
        data: studentUsers.map(u => ({
          userId: u.id,
          title: data.title,
          message: data.message,
          type: data.type || 'JOB',
          link: data.link,
        })),
      });
    } catch (error) {
      console.error('Error broadcasting notification to students:', error);
    }
  }
}

