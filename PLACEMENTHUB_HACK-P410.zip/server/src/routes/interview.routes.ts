import { Router } from 'express';
import {
  scheduleInterview,
  updateInterview,
  getMyInterviews,
  getRecruiterInterviews,
} from '../controllers/interviewController.js';
import { authenticateToken, requireRole } from '../middleware/auth.js';

const router = Router();

router.use(authenticateToken);

router.post('/', requireRole(['RECRUITER', 'ADMIN']), scheduleInterview);
router.put('/:id', requireRole(['RECRUITER', 'ADMIN']), updateInterview);
router.get('/my', requireRole(['STUDENT']), getMyInterviews);
router.get('/recruiter', requireRole(['RECRUITER', 'ADMIN']), getRecruiterInterviews);

export default router;

