import { Router } from 'express';
import {
  getAdminStats,
  getStudentsList,
  getRecruitersList,
  getAuditLogs,
  exportReportCSV,
} from '../controllers/adminController.js';
import { authenticateToken, requireRole } from '../middleware/auth.js';

const router = Router();

router.use(authenticateToken);
router.use(requireRole(['ADMIN']));

router.get('/stats', getAdminStats);
router.get('/students', getStudentsList);
router.get('/recruiters', getRecruitersList);
router.get('/audit-logs', getAuditLogs);
router.get('/export/:type', exportReportCSV);

export default router;

