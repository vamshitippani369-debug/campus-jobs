import { Router } from 'express';
import {
  getAllJobs,
  getJobById,
  createJob,
  updateJob,
  approveJob,
  getJobApplicants,
} from '../controllers/jobController.js';
import { authenticateToken, requireRole } from '../middleware/auth.js';

const router = Router();

// Optional token middleware for public/student view
router.get('/', (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (authHeader) {
    return authenticateToken(req as any, res, next);
  }
  next();
}, getAllJobs as any);

router.get('/:id', (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (authHeader) {
    return authenticateToken(req as any, res, next);
  }
  next();
}, getJobById as any);

router.post('/', authenticateToken, requireRole(['RECRUITER', 'ADMIN']), createJob);
router.put('/:id', authenticateToken, requireRole(['RECRUITER', 'ADMIN']), updateJob);
router.patch('/:id/approve', authenticateToken, requireRole(['ADMIN']), approveJob);
router.get('/:id/applicants', authenticateToken, requireRole(['RECRUITER', 'ADMIN']), getJobApplicants);

export default router;

