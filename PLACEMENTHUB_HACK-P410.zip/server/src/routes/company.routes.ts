import { Router } from 'express';
import {
  getAllCompanies,
  getCompanyById,
  createCompany,
  updateCompany,
  verifyCompany,
} from '../controllers/companyController.js';
import { authenticateToken, requireRole } from '../middleware/auth.js';

const router = Router();

router.get('/', getAllCompanies);
router.get('/:id', getCompanyById);

router.post('/', authenticateToken, requireRole(['ADMIN', 'RECRUITER']), createCompany);
router.put('/:id', authenticateToken, requireRole(['ADMIN', 'RECRUITER']), updateCompany);
router.patch('/:id/verify', authenticateToken, requireRole(['ADMIN']), verifyCompany);

export default router;

