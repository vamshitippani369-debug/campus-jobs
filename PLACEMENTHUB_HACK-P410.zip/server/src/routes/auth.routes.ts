import { Router } from 'express';
import { login, registerStudent, registerRecruiter, getMe } from '../controllers/authController.js';
import { authenticateToken } from '../middleware/auth.js';

const router = Router();

router.post('/login', login);
router.post('/register/student', registerStudent);
router.post('/register/recruiter', registerRecruiter);
router.get('/me', authenticateToken, getMe);

export default router;

