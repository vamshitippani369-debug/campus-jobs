import { Router } from 'express';
import {
  createOffer,
  updateOfferStatus,
  getMyOffers,
  getAllOffers,
} from '../controllers/offerController.js';
import { authenticateToken, requireRole } from '../middleware/auth.js';

const router = Router();

router.use(authenticateToken);

router.post('/', requireRole(['RECRUITER', 'ADMIN']), createOffer);
router.patch('/:id/status', requireRole(['STUDENT', 'ADMIN']), updateOfferStatus);
router.get('/my', requireRole(['STUDENT']), getMyOffers);
router.get('/all', requireRole(['RECRUITER', 'ADMIN']), getAllOffers);

export default router;

