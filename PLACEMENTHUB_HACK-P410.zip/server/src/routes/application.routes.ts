import { Router } from 'express';
import {
  submitApplication,
  getMyApplications,
  updateApplicationStatus,
  withdrawApplication,
} from '../controllers/applicationController.js';
import { authenticateToken, requireRole } from '../middleware/auth.js';

const router = Router();

router.use(authenticateToken);

router.post('/', requireRole(['STUDENT']), submitApplication);
router.get('/my', requireRole(['STUDENT']), getMyApplications);
router.patch('/:id/status', requireRole(['RECRUITER', 'ADMIN']), updateApplicationStatus);
router.patch('/:id/withdraw', requireRole(['STUDENT']), withdrawApplication);

export default router;

