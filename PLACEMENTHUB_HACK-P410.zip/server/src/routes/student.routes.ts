import { Router } from 'express';
import {
  getProfile,
  updateProfile,
  uploadResume,
  getStudentDashboard,
} from '../controllers/studentController.js';
import { authenticateToken, requireRole } from '../middleware/auth.js';
import { resumeUpload } from '../middleware/upload.js';

const router = Router();

router.use(authenticateToken);
router.use(requireRole(['STUDENT', 'ADMIN']));

router.get('/profile', getProfile);
router.put('/profile', updateProfile);
router.post('/resume', resumeUpload.single('resume'), uploadResume);
router.get('/dashboard', getStudentDashboard);

export default router;

