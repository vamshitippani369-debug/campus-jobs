import { describe, it, expect } from 'vitest';
import { EligibilityService } from '../services/eligibilityService.js';

describe('Intelligent Eligibility Checker Engine', () => {
  const baseJob = {
    id: 'job-101',
    title: 'Senior Systems Engineer',
    status: 'PUBLISHED',
    minCgpa: 7.5,
    maxActiveBacklogs: 0,
    eligibleDepartments: ['CSE', 'IT', 'ECE'],
    eligibleGraduationYears: [2025, 2026],
    requiredSkills: ['Node.js', 'React', 'SQL'],
    applicationDeadline: '2027-12-31T23:59:59.000Z',
  };

  it('should mark student ELIGIBLE when all criteria pass', () => {
    const student = {
      id: 'student-1',
      fullName: 'Aarav Sharma',
      department: 'Computer Science & Engineering',
      graduationYear: 2025,
      cgpa: 8.5,
      activeBacklogs: 0,
      technicalSkills: ['Node.js', 'React', 'SQL', 'TypeScript'],
      resumeUrl: '/uploads/resumes/resume.pdf',
      profileCompletion: 90,
    };

    const report = EligibilityService.evaluate(student, baseJob);

    expect(report.isEligible).toBe(true);
    expect(report.canApply).toBe(true);
    expect(report.failedReasons.length).toBe(0);
    expect(report.passedReasons.length).toBe(4);
    expect(report.skillMatch.matchPercentage).toBe(100);
  });

  it('should mark student INELIGIBLE when CGPA is below cutoff and report reason', () => {
    const student = {
      id: 'student-2',
      fullName: 'Diya Sengupta',
      department: 'CSE',
      graduationYear: 2025,
      cgpa: 7.1, // below 7.5
      activeBacklogs: 0,
      technicalSkills: ['React'],
      resumeUrl: '/uploads/resumes/resume.pdf',
    };

    const report = EligibilityService.evaluate(student, baseJob);

    expect(report.isEligible).toBe(false);
    expect(report.canApply).toBe(false);
    expect(report.failedReasons.some(r => r.includes('CGPA'))).toBe(true);
  });

  it('should mark student INELIGIBLE when active backlogs exceed maximum allowed', () => {
    const student = {
      id: 'student-3',
      fullName: 'Nikhil Saxena',
      department: 'CSE',
      graduationYear: 2025,
      cgpa: 8.0,
      activeBacklogs: 1, // max allowed is 0
      technicalSkills: ['Node.js'],
      resumeUrl: '/uploads/resumes/resume.pdf',
    };

    const report = EligibilityService.evaluate(student, baseJob);

    expect(report.isEligible).toBe(false);
    expect(report.canApply).toBe(false);
    expect(report.failedReasons.some(r => r.includes('backlog'))).toBe(true);
  });

  it('should mark student INELIGIBLE when department is not allowed', () => {
    const student = {
      id: 'student-4',
      fullName: 'Ritu Deshmukh',
      department: 'Civil Engineering',
      graduationYear: 2025,
      cgpa: 8.2,
      activeBacklogs: 0,
      technicalSkills: ['AutoCAD'],
      resumeUrl: '/uploads/resumes/resume.pdf',
    };

    const report = EligibilityService.evaluate(student, baseJob);

    expect(report.isEligible).toBe(false);
    expect(report.canApply).toBe(false);
    expect(report.failedReasons.some(r => r.includes('department'))).toBe(true);
  });

  it('should mark student INELIGIBLE when graduation batch is not matched', () => {
    const student = {
      id: 'student-5',
      fullName: 'Junior Student',
      department: 'CSE',
      graduationYear: 2028, // Eligible: 2025, 2026
      cgpa: 9.0,
      activeBacklogs: 0,
      resumeUrl: '/uploads/resumes/resume.pdf',
    };

    const report = EligibilityService.evaluate(student, baseJob);

    expect(report.isEligible).toBe(false);
    expect(report.canApply).toBe(false);
    expect(report.failedReasons.some(r => r.includes('graduation'))).toBe(true);
  });

  it('should block application if resume is missing even if academically eligible', () => {
    const student = {
      id: 'student-6',
      fullName: 'No Resume Student',
      department: 'CSE',
      graduationYear: 2025,
      cgpa: 8.5,
      activeBacklogs: 0,
      resumeUrl: null,
    };

    const report = EligibilityService.evaluate(student, baseJob);

    expect(report.isEligible).toBe(true);
    expect(report.canApply).toBe(false);
    expect(report.blockReason).toContain('resume');
  });

  it('should accurately calculate skill match percentage and identify missing skills', () => {
    const student = {
      id: 'student-7',
      fullName: 'Skill Partial',
      department: 'CSE',
      graduationYear: 2025,
      cgpa: 8.5,
      activeBacklogs: 0,
      technicalSkills: ['React'], // has 1 of 3 (Node.js, React, SQL)
      resumeUrl: '/uploads/resumes/resume.pdf',
    };

    const report = EligibilityService.evaluate(student, baseJob);

    expect(report.skillMatch.matchPercentage).toBe(33);
    expect(report.skillMatch.matchedSkills).toEqual(['React']);
    expect(report.skillMatch.missingSkills).toEqual(['Node.js', 'SQL']);
  });
});

