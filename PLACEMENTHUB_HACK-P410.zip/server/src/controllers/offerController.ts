import { Response } from 'express';
import { prisma } from '../config/db.js';
import { AuthRequest } from '../middleware/auth.js';
import { AuditService } from '../services/auditService.js';
import { NotificationService } from '../services/notificationService.js';

export const createOffer = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const {
      applicationId,
      ctc,
      designation,
      location,
      joiningDate,
    } = req.body;

    if (!applicationId || !ctc || !designation || !location) {
      res.status(400).json({ success: false, message: 'Missing required offer details' });
      return;
    }

    const application = await prisma.application.findUnique({
      where: { id: String(applicationId) },
      include: {
        job: { include: { company: true } },
        student: { include: { user: true } },
      },
    });

    if (!application) {
      res.status(404).json({ success: false, message: 'Application not found' });
      return;
    }

    if (req.user?.role === 'RECRUITER' && req.user.companyId !== application.job.companyId) {
      res.status(403).json({ success: false, message: 'Unauthorized to make offer for this drive' });
      return;
    }

    // Check if offer already exists for this application
    const existingOffer = await prisma.offer.findUnique({
      where: { applicationId: String(applicationId) },
    });

    if (existingOffer) {
      res.status(400).json({ success: false, message: 'Offer already issued for this application' });
      return;
    }

    // Create Offer
    const offer = await prisma.offer.create({
      data: {
        applicationId: String(applicationId),
        studentId: application.studentId,
        jobId: application.jobId,
        companyId: application.job.companyId,
        ctc,
        designation,
        location,
        joiningDate: joiningDate || null,
        status: 'OFFERED',
      },
    });

    // Update Application Status to SELECTED
    await prisma.application.update({
      where: { id: String(applicationId) },
      data: { status: 'SELECTED' },
    });

    // Notify Student
    await NotificationService.createNotification({
      userId: application.student.userId,
      title: '🌟 Placement Offer Received!',
      message: `Congratulations! ${application.job.company.name} has extended an official placement offer for ${designation} with package ${ctc}.`,
      type: 'OFFER',
      link: '/offers',
    });

    // Audit log
    await AuditService.log({
      userId: req.user!.id,
      userEmail: req.user!.email,
      userRole: req.user!.role,
      action: 'OFFER_EXTENDED',
      entityType: 'Offer',
      entityId: offer.id,
      details: {
        candidate: application.student.fullName,
        company: application.job.company.name,
        designation,
        ctc,
      },
    });

    res.status(201).json({
      success: true,
      message: 'Placement offer generated and delivered to student successfully',
      offer,
    });
  } catch (error: any) {
    console.error('createOffer error:', error);
    res.status(500).json({ success: false, message: 'Failed to create offer' });
  }
};

export const updateOfferStatus = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const id = String(req.params.id);
    const { status } = req.body;

    if (!['ACCEPTED', 'DECLINED'].includes(status)) {
      res.status(400).json({ success: false, message: 'Invalid status. Must be ACCEPTED or DECLINED' });
      return;
    }

    const offer = await prisma.offer.findUnique({
      where: { id },
      include: {
        company: true,
        job: true,
        student: true,
      },
    });

    if (!offer) {
      res.status(404).json({ success: false, message: 'Offer not found' });
      return;
    }

    if (req.user?.role === 'STUDENT' && offer.studentId !== req.user.studentProfileId) {
      res.status(403).json({ success: false, message: 'Unauthorized' });
      return;
    }

    const updated = await prisma.offer.update({
      where: { id },
      data: { status },
      include: {
        company: true,
        job: true,
        student: true,
      },
    });

    await AuditService.log({
      userId: req.user!.id,
      userEmail: req.user!.email,
      userRole: req.user!.role,
      action: `OFFER_${status}`,
      entityType: 'Offer',
      entityId: offer.id,
      details: {
        candidate: offer.student.fullName,
        company: offer.company.name,
        status,
      },
    });

    res.json({
      success: true,
      message: `Offer ${status.toLowerCase()} successfully`,
      offer: updated,
    });
  } catch (error: any) {
    console.error('updateOfferStatus error:', error);
    res.status(500).json({ success: false, message: 'Failed to update offer status' });
  }
};

export const getMyOffers = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const student = await prisma.studentProfile.findFirst({
      where: { userId: req.user!.id },
    });

    if (!student) {
      res.status(404).json({ success: false, message: 'Student profile not found' });
      return;
    }

    const offers = await prisma.offer.findMany({
      where: { studentId: student.id },
      include: {
        company: true,
        job: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    res.json({ success: true, count: offers.length, offers });
  } catch (error: any) {
    console.error('getMyOffers error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch offers' });
  }
};

export const getAllOffers = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const where: any = {};
    if (req.user?.role === 'RECRUITER' && req.user.companyId) {
      where.companyId = req.user.companyId;
    }

    const offers = await prisma.offer.findMany({
      where,
      include: {
        student: true,
        job: true,
        company: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    res.json({ success: true, count: offers.length, offers });
  } catch (error: any) {
    console.error('getAllOffers error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch offers' });
  }
};
