import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { prisma } from '../config/db.js';
import { ENV } from '../config/env.js';
import { AuthRequest } from '../middleware/auth.js';
import { AuditService } from '../services/auditService.js';

export const login = async (req: Request, res: Response): Promise<void> => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      res.status(400).json({ success: false, message: 'Email and password are required' });
      return;
    }

    const user = await prisma.user.findUnique({
      where: { email: email.toLowerCase().trim() },
      include: {
        studentProfile: true,
        recruiterProfile: {
          include: { company: true },
        },
      },
    });

    if (!user) {
      res.status(401).json({ success: false, message: 'Invalid email or password' });
      return;
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      res.status(401).json({ success: false, message: 'Invalid email or password' });
      return;
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role },
      ENV.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({
      success: true,
      message: 'Login successful',
      token,
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        studentProfile: user.studentProfile,
        recruiterProfile: user.recruiterProfile,
      },
    });
  } catch (error: any) {
    console.error('Login error:', error);
    res.status(500).json({ success: false, message: 'Server error during login' });
  }
};

export const registerStudent = async (req: Request, res: Response): Promise<void> => {
  try {
    const {
      email,
      password,
      fullName,
      studentId,
      phone,
      department,
      course,
      graduationYear,
      cgpa,
      tenthPercentage,
      twelfthPercentage,
    } = req.body;

    if (!email || !password || !fullName || !studentId || !department || !graduationYear) {
      res.status(400).json({ success: false, message: 'Missing required registration fields' });
      return;
    }

    const existingUser = await prisma.user.findUnique({
      where: { email: email.toLowerCase().trim() },
    });

    if (existingUser) {
      res.status(400).json({ success: false, message: 'Email is already registered' });
      return;
    }

    const existingStudentId = await prisma.studentProfile.findUnique({
      where: { studentId },
    });

    if (existingStudentId) {
      res.status(400).json({ success: false, message: 'Student ID already exists' });
      return;
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = await prisma.user.create({
      data: {
        email: email.toLowerCase().trim(),
        password: hashedPassword,
        role: 'STUDENT',
        studentProfile: {
          create: {
            fullName,
            studentId,
            collegeEmail: email.toLowerCase().trim(),
            phone: phone || '',
            department,
            course: course || 'B.Tech',
            graduationYear: Number(graduationYear),
            cgpa: Number(cgpa) || 7.0,
            tenthPercentage: Number(tenthPercentage) || 80,
            twelfthPercentage: Number(twelfthPercentage) || 80,
            profileCompletion: 70,
          },
        },
      },
      include: {
        studentProfile: true,
      },
    });

    await AuditService.log({
      userId: user.id,
      userEmail: user.email,
      userRole: 'STUDENT',
      action: 'STUDENT_REGISTERED',
      entityType: 'StudentProfile',
      entityId: user.studentProfile?.id,
      details: { fullName, studentId, department, graduationYear },
    });

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role },
      ENV.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.status(201).json({
      success: true,
      message: 'Student account created successfully',
      token,
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        studentProfile: user.studentProfile,
      },
    });
  } catch (error: any) {
    console.error('Student registration error:', error);
    res.status(500).json({ success: false, message: 'Failed to create student account' });
  }
};

export const registerRecruiter = async (req: Request, res: Response): Promise<void> => {
  try {
    const {
      email,
      password,
      fullName,
      designation,
      phone,
      companyName,
      companyWebsite,
      industry,
    } = req.body;

    if (!email || !password || !fullName || !companyName) {
      res.status(400).json({ success: false, message: 'Missing required recruiter registration fields' });
      return;
    }

    const existingUser = await prisma.user.findUnique({
      where: { email: email.toLowerCase().trim() },
    });

    if (existingUser) {
      res.status(400).json({ success: false, message: 'Email is already registered' });
      return;
    }

    // Find or create company
    let company = await prisma.company.findUnique({
      where: { name: companyName.trim() },
    });

    if (!company) {
      company = await prisma.company.create({
        data: {
          name: companyName.trim(),
          industry: industry || 'Technology',
          website: companyWebsite || 'https://' + companyName.toLowerCase().replace(/\s+/g, '') + '.com',
          description: `${companyName} is an enterprise recruitment partner.`,
          headquarters: 'Bengaluru, India',
          companySize: '500-1000 employees',
          hrContactEmail: email.toLowerCase().trim(),
          hrContactPhone: phone || '+91 98765 43210',
          isVerified: false, // Requires admin verification
        },
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = await prisma.user.create({
      data: {
        email: email.toLowerCase().trim(),
        password: hashedPassword,
        role: 'RECRUITER',
        recruiterProfile: {
          create: {
            fullName,
            designation: designation || 'Talent Acquisition Specialist',
            phone: phone || '',
            companyId: company.id,
          },
        },
      },
      include: {
        recruiterProfile: {
          include: { company: true },
        },
      },
    });

    await AuditService.log({
      userId: user.id,
      userEmail: user.email,
      userRole: 'RECRUITER',
      action: 'RECRUITER_REGISTERED',
      entityType: 'RecruiterProfile',
      entityId: user.recruiterProfile?.id,
      details: { fullName, companyName },
    });

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role },
      ENV.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.status(201).json({
      success: true,
      message: 'Recruiter account registered successfully',
      token,
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        recruiterProfile: user.recruiterProfile,
      },
    });
  } catch (error: any) {
    console.error('Recruiter registration error:', error);
    res.status(500).json({ success: false, message: 'Failed to create recruiter account' });
  }
};

export const getMe = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, message: 'Not authenticated' });
      return;
    }

    const user = await prisma.user.findUnique({
      where: { id: req.user.id },
      include: {
        studentProfile: true,
        recruiterProfile: {
          include: { company: true },
        },
      },
    });

    if (!user) {
      res.status(404).json({ success: false, message: 'User not found' });
      return;
    }

    res.json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        studentProfile: user.studentProfile,
        recruiterProfile: user.recruiterProfile,
      },
    });
  } catch (error: any) {
    console.error('getMe error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch user data' });
  }
};
