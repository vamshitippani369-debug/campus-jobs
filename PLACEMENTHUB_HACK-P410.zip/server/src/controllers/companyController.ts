import { Response } from 'express';
import { prisma } from '../config/db.js';
import { AuthRequest } from '../middleware/auth.js';
import { AuditService } from '../services/auditService.js';

export const getAllCompanies = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { search, verified } = req.query;

    const where: any = {};
    if (search) {
      where.name = { contains: String(search) };
    }
    if (verified !== undefined) {
      where.isVerified = verified === 'true';
    }

    const companies = await prisma.company.findMany({
      where,
      include: {
        _count: {
          select: { jobs: true, offers: true },
        },
      },
      orderBy: { name: 'asc' },
    });

    res.json({ success: true, companies });
  } catch (error: any) {
    console.error('getAllCompanies error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch companies' });
  }
};

export const getCompanyById = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const id = String(req.params.id);

    const company = await prisma.company.findUnique({
      where: { id },
      include: {
        jobs: {
          orderBy: { createdAt: 'desc' },
        },
        _count: {
          select: { jobs: true, offers: true },
        },
      },
    });

    if (!company) {
      res.status(404).json({ success: false, message: 'Company not found' });
      return;
    }

    res.json({ success: true, company });
  } catch (error: any) {
    console.error('getCompanyById error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch company details' });
  }
};

export const createCompany = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const {
      name,
      logo,
      industry,
      website,
      description,
      headquarters,
      companySize,
      hrContactEmail,
      hrContactPhone,
    } = req.body;

    if (!name || !industry || !website) {
      res.status(400).json({ success: false, message: 'Missing required company fields' });
      return;
    }

    const existing = await prisma.company.findUnique({ where: { name } });
    if (existing) {
      res.status(400).json({ success: false, message: 'Company name already registered' });
      return;
    }

    const company = await prisma.company.create({
      data: {
        name,
        logo,
        industry,
        website,
        description: description || '',
        headquarters: headquarters || 'India',
        companySize: companySize || '100-500 employees',
        hrContactEmail: hrContactEmail || '',
        hrContactPhone: hrContactPhone || '',
        isVerified: req.user?.role === 'ADMIN', // auto-verify if admin created
      },
    });

    await AuditService.log({
      userId: req.user?.id,
      userEmail: req.user?.email || 'system',
      userRole: req.user?.role || 'UNKNOWN',
      action: 'COMPANY_CREATED',
      entityType: 'Company',
      entityId: company.id,
      details: { name },
    });

    res.status(201).json({ success: true, message: 'Company created successfully', company });
  } catch (error: any) {
    console.error('createCompany error:', error);
    res.status(500).json({ success: false, message: 'Failed to create company' });
  }
};

export const updateCompany = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const id = String(req.params.id);
    const data = req.body;

    // Check recruiter ownership or admin
    if (req.user?.role === 'RECRUITER' && req.user.companyId !== id) {
      res.status(403).json({ success: false, message: 'Unauthorized to update this company' });
      return;
    }

    const company = await prisma.company.update({
      where: { id },
      data,
    });

    res.json({ success: true, message: 'Company updated successfully', company });
  } catch (error: any) {
    console.error('updateCompany error:', error);
    res.status(500).json({ success: false, message: 'Failed to update company' });
  }
};

export const verifyCompany = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const id = String(req.params.id);
    const { isVerified } = req.body;

    const company = await prisma.company.update({
      where: { id },
      data: { isVerified: Boolean(isVerified) },
    });

    await AuditService.log({
      userId: req.user!.id,
      userEmail: req.user!.email,
      userRole: 'ADMIN',
      action: isVerified ? 'COMPANY_VERIFIED' : 'COMPANY_UNVERIFIED',
      entityType: 'Company',
      entityId: company.id,
      details: { isVerified },
    });

    res.json({
      success: true,
      message: `Company ${isVerified ? 'verified' : 'unverified'} successfully`,
      company,
    });
  } catch (error: any) {
    console.error('verifyCompany error:', error);
    res.status(500).json({ success: false, message: 'Failed to change company verification status' });
  }
};
