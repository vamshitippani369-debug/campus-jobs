import { Response } from 'express';
import { prisma } from '../config/db.js';
import { AuthRequest } from '../middleware/auth.js';
import { AuditService } from '../services/auditService.js';

const calculateProfileCompletion = (profile: any): number => {
  let score = 0;
  const checks = [
    Boolean(profile.fullName),
    Boolean(profile.studentId),
    Boolean(profile.collegeEmail),
    Boolean(profile.phone),
    Boolean(profile.department),
    Boolean(profile.course),
    Boolean(profile.graduationYear),
    typeof profile.cgpa === 'number' && profile.cgpa > 0,
    typeof profile.tenthPercentage === 'number' && profile.tenthPercentage > 0,
    typeof profile.twelfthPercentage === 'number' && profile.twelfthPercentage > 0,
    Boolean(profile.resumeUrl),
    Array.isArray(profile.technicalSkills) ? profile.technicalSkills.length > 0 : Boolean(profile.technicalSkills && profile.technicalSkills !== '[]'),
    Boolean(profile.linkedInUrl),
    Boolean(profile.gitHubUrl),
  ];

  const passed = checks.filter(Boolean).length;
  score = Math.round((passed / checks.length) * 100);
  return Math.min(100, Math.max(0, score));
};

export const getProfile = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const student = await prisma.studentProfile.findFirst({
      where: { userId: req.user!.id },
      include: {
        user: { select: { email: true, createdAt: true } },
      },
    });

    if (!student) {
      res.status(404).json({ success: false, message: 'Student profile not found' });
      return;
    }

    res.json({
      success: true,
      profile: {
        ...student,
        technicalSkills: JSON.parse(student.technicalSkills || '[]'),
        programmingLanguages: JSON.parse(student.programmingLanguages || '[]'),
        certifications: JSON.parse(student.certifications || '[]'),
        projects: JSON.parse(student.projects || '[]'),
        internshipExperience: JSON.parse(student.internshipExperience || '[]'),
      },
    });
  } catch (error: any) {
    console.error('getProfile error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch student profile' });
  }
};

export const updateProfile = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const {
      fullName,
      phone,
      department,
      course,
      graduationYear,
      cgpa,
      backlogs,
      activeBacklogs,
      tenthPercentage,
      twelfthPercentage,
      technicalSkills,
      programmingLanguages,
      certifications,
      projects,
      internshipExperience,
      linkedInUrl,
      gitHubUrl,
    } = req.body;

    const currentProfile = await prisma.studentProfile.findFirst({
      where: { userId: req.user!.id },
    });

    if (!currentProfile) {
      res.status(404).json({ success: false, message: 'Student profile not found' });
      return;
    }

    const updatedData: any = {};
    if (fullName !== undefined) updatedData.fullName = fullName;
    if (phone !== undefined) updatedData.phone = phone;
    if (department !== undefined) updatedData.department = department;
    if (course !== undefined) updatedData.course = course;
    if (graduationYear !== undefined) updatedData.graduationYear = Number(graduationYear);
    if (cgpa !== undefined) updatedData.cgpa = Number(cgpa);
    if (backlogs !== undefined) updatedData.backlogs = Number(backlogs);
    if (activeBacklogs !== undefined) updatedData.activeBacklogs = Number(activeBacklogs);
    if (tenthPercentage !== undefined) updatedData.tenthPercentage = Number(tenthPercentage);
    if (twelfthPercentage !== undefined) updatedData.twelfthPercentage = Number(twelfthPercentage);
    if (linkedInUrl !== undefined) updatedData.linkedInUrl = linkedInUrl;
    if (gitHubUrl !== undefined) updatedData.gitHubUrl = gitHubUrl;

    if (technicalSkills !== undefined) {
      updatedData.technicalSkills = JSON.stringify(technicalSkills);
    }
    if (programmingLanguages !== undefined) {
      updatedData.programmingLanguages = JSON.stringify(programmingLanguages);
    }
    if (certifications !== undefined) {
      updatedData.certifications = JSON.stringify(certifications);
    }
    if (projects !== undefined) {
      updatedData.projects = JSON.stringify(projects);
    }
    if (internshipExperience !== undefined) {
      updatedData.internshipExperience = JSON.stringify(internshipExperience);
    }

    const merged = { ...currentProfile, ...updatedData };
    const completion = calculateProfileCompletion(merged);
    updatedData.profileCompletion = completion;

    const updated = await prisma.studentProfile.update({
      where: { id: currentProfile.id },
      data: updatedData,
    });

    await AuditService.log({
      userId: req.user!.id,
      userEmail: req.user!.email,
      userRole: req.user!.role,
      action: 'STUDENT_PROFILE_UPDATED',
      entityType: 'StudentProfile',
      entityId: updated.id,
      details: { completion },
    });

    res.json({
      success: true,
      message: 'Profile updated successfully',
      profile: {
        ...updated,
        technicalSkills: JSON.parse(updated.technicalSkills || '[]'),
        programmingLanguages: JSON.parse(updated.programmingLanguages || '[]'),
        certifications: JSON.parse(updated.certifications || '[]'),
        projects: JSON.parse(updated.projects || '[]'),
        internshipExperience: JSON.parse(updated.internshipExperience || '[]'),
      },
    });
  } catch (error: any) {
    console.error('updateProfile error:', error);
    res.status(500).json({ success: false, message: 'Failed to update profile' });
  }
};

export const uploadResume = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.file) {
      res.status(400).json({ success: false, message: 'No file uploaded or file is not a valid PDF' });
      return;
    }

    const student = await prisma.studentProfile.findFirst({
      where: { userId: req.user!.id },
    });

    if (!student) {
      res.status(404).json({ success: false, message: 'Student profile not found' });
      return;
    }

    const resumeUrl = `/uploads/resumes/${req.file.filename}`;
    const resumeFilename = req.file.originalname;

    const updated = await prisma.studentProfile.update({
      where: { id: student.id },
      data: {
        resumeUrl,
        resumeFilename,
        resumeUpdatedAt: new Date(),
      },
    });

    // Recalculate completion
    const completion = calculateProfileCompletion(updated);
    await prisma.studentProfile.update({
      where: { id: student.id },
      data: { profileCompletion: completion },
    });

    await AuditService.log({
      userId: req.user!.id,
      userEmail: req.user!.email,
      userRole: req.user!.role,
      action: 'RESUME_UPLOADED',
      entityType: 'StudentProfile',
      entityId: student.id,
      details: { filename: resumeFilename },
    });

    res.json({
      success: true,
      message: 'Resume uploaded successfully',
      resumeUrl,
      resumeFilename,
      profileCompletion: completion,
    });
  } catch (error: any) {
    console.error('uploadResume error:', error);
    res.status(500).json({ success: false, message: 'Failed to upload resume' });
  }
};

export const getStudentDashboard = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const student = await prisma.studentProfile.findFirst({
      where: { userId: req.user!.id },
    });

    if (!student) {
      res.status(404).json({ success: false, message: 'Student profile not found' });
      return;
    }

    const applications = await prisma.application.findMany({
      where: { studentId: student.id },
      include: {
        job: {
          include: { company: true },
        },
        interviews: true,
        offer: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    const totalApplied = applications.length;
    const shortlistedCount = applications.filter(a => a.status === 'SHORTLISTED').length;
    const interviewCount = applications.filter(a => a.status === 'INTERVIEW_SCHEDULED').length;
    const selectedCount = applications.filter(a => a.status === 'SELECTED').length;
    const rejectedCount = applications.filter(a => a.status === 'REJECTED').length;

    const upcomingInterviews = await prisma.interview.findMany({
      where: {
        studentId: student.id,
        status: 'SCHEDULED',
      },
      include: {
        job: {
          include: { company: true },
        },
      },
      orderBy: { scheduledDate: 'asc' },
      take: 5,
    });

    res.json({
      success: true,
      stats: {
        totalApplied,
        shortlistedCount,
        interviewCount,
        selectedCount,
        rejectedCount,
        profileCompletion: student.profileCompletion,
      },
      recentApplications: applications.slice(0, 5),
      upcomingInterviews,
    });
  } catch (error: any) {
    console.error('getStudentDashboard error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch dashboard metrics' });
  }
};

