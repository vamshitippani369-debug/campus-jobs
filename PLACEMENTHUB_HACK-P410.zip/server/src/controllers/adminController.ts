import { Response } from 'express';
import { prisma } from '../config/db.js';
import { AuthRequest } from '../middleware/auth.js';

export const getAdminStats = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const totalStudents = await prisma.studentProfile.count();
    const totalCompanies = await prisma.company.count();
    const activeDrives = await prisma.job.count({ where: { status: 'PUBLISHED' } });
    const totalApplications = await prisma.application.count();
    const totalShortlisted = await prisma.application.count({ where: { status: 'SHORTLISTED' } });
    const totalInterviews = await prisma.interview.count();
    const totalOffers = await prisma.offer.count();

    // Distinct placed students
    const placedStudentsRaw = await prisma.offer.findMany({
      select: { studentId: true },
      distinct: ['studentId'],
    });
    const totalPlacedStudents = placedStudentsRaw.length;

    const overallPlacementRate = totalStudents > 0
      ? Number(((totalPlacedStudents / totalStudents) * 100).toFixed(1))
      : 0;

    // Highest and average package
    const offers = await prisma.offer.findMany({
      select: { ctc: true },
    });

    // Parse CTC numbers (e.g., "14 LPA" -> 14, "12 - 16 LPA" -> 14)
    const ctcValues: number[] = [];
    offers.forEach(o => {
      const match = o.ctc.match(/(\d+(\.\d+)?)/);
      if (match) {
        ctcValues.push(parseFloat(match[1]));
      }
    });

    const highestPackage = ctcValues.length > 0 ? Math.max(...ctcValues) : 0;
    const avgPackage = ctcValues.length > 0
      ? Number((ctcValues.reduce((a, b) => a + b, 0) / ctcValues.length).toFixed(2))
      : 0;

    // Application status breakdown
    const applications = await prisma.application.findMany({
      select: { status: true },
    });

    const statusCounts: Record<string, number> = {
      SUBMITTED: 0,
      SHORTLISTED: 0,
      INTERVIEW_SCHEDULED: 0,
      SELECTED: 0,
      REJECTED: 0,
      WITHDRAWN: 0,
    };

    applications.forEach(a => {
      statusCounts[a.status] = (statusCounts[a.status] || 0) + 1;
    });

    const statusDistribution = Object.entries(statusCounts).map(([status, count]) => ({
      status: status.replace('_', ' '),
      count,
    }));

    // Department-wise statistics
    const allStudents = await prisma.studentProfile.findMany({
      include: {
        offers: true,
      },
    });

    const deptMap: Record<string, { total: number; placed: number; offers: number; ctcSum: number }> = {};
    allStudents.forEach(st => {
      const dept = st.department || 'Other';
      if (!deptMap[dept]) {
        deptMap[dept] = { total: 0, placed: 0, offers: 0, ctcSum: 0 };
      }
      deptMap[dept].total += 1;
      if (st.offers.length > 0) {
        deptMap[dept].placed += 1;
        deptMap[dept].offers += st.offers.length;
        st.offers.forEach(o => {
          const match = o.ctc.match(/(\d+(\.\d+)?)/);
          if (match) {
            deptMap[dept].ctcSum += parseFloat(match[1]);
          }
        });
      }
    });

    const departmentStats = Object.entries(deptMap).map(([department, data]) => ({
      department,
      totalStudents: data.total,
      placedStudents: data.placed,
      totalOffers: data.offers,
      placementRate: data.total > 0 ? Number(((data.placed / data.total) * 100).toFixed(1)) : 0,
      avgPackage: data.offers > 0 ? Number((data.ctcSum / data.offers).toFixed(2)) : 0,
    }));

    // Company-wise selection statistics
    const companies = await prisma.company.findMany({
      include: {
        _count: {
          select: { jobs: true, offers: true },
        },
        jobs: {
          include: {
            _count: { select: { applications: true } },
          },
        },
      },
    });

    const companyStats = companies.map(c => {
      const totalCompanyApplicants = c.jobs.reduce((acc, j) => acc + j._count.applications, 0);
      return {
        id: c.id,
        name: c.name,
        industry: c.industry,
        isVerified: c.isVerified,
        totalJobs: c._count.jobs,
        totalApplicants: totalCompanyApplicants,
        totalOffers: c._count.offers,
      };
    });

    res.json({
      success: true,
      metrics: {
        totalStudents,
        totalCompanies,
        activeDrives,
        totalApplications,
        totalShortlisted,
        totalInterviews,
        totalPlacedStudents,
        totalOffers,
        overallPlacementRate,
        highestPackage: highestPackage ? `${highestPackage} LPA` : '0 LPA',
        avgPackage: avgPackage ? `${avgPackage} LPA` : '0 LPA',
      },
      statusDistribution,
      departmentStats,
      companyStats,
    });
  } catch (error: any) {
    console.error('getAdminStats error:', error);
    res.status(500).json({ success: false, message: 'Failed to compute admin statistics' });
  }
};

export const getStudentsList = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { department, graduationYear, minCgpa, search } = req.query;

    const where: any = {};
    if (department) where.department = String(department);
    if (graduationYear) where.graduationYear = Number(graduationYear);
    if (minCgpa) where.cgpa = { gte: Number(minCgpa) };
    if (search) {
      where.OR = [
        { fullName: { contains: String(search) } },
        { studentId: { contains: String(search) } },
        { collegeEmail: { contains: String(search) } },
      ];
    }

    const students = await prisma.studentProfile.findMany({
      where,
      include: {
        user: { select: { email: true, createdAt: true } },
        _count: {
          select: { applications: true, interviews: true, offers: true },
        },
      },
      orderBy: { fullName: 'asc' },
    });

    const parsed = students.map(s => ({
      ...s,
      technicalSkills: JSON.parse(s.technicalSkills || '[]'),
    }));

    res.json({ success: true, count: parsed.length, students: parsed });
  } catch (error: any) {
    console.error('getStudentsList error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch students list' });
  }
};

export const getRecruitersList = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const recruiters = await prisma.recruiterProfile.findMany({
      include: {
        user: { select: { email: true, createdAt: true, isApproved: true } },
        company: true,
      },
      orderBy: { fullName: 'asc' },
    });

    res.json({ success: true, count: recruiters.length, recruiters });
  } catch (error: any) {
    console.error('getRecruitersList error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch recruiters list' });
  }
};

export const getAuditLogs = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { page = '1', limit = '50', action } = req.query;
    const skip = (Number(page) - 1) * Number(limit);

    const where: any = {};
    if (action) where.action = String(action);

    const [logs, total] = await Promise.all([
      prisma.auditLog.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: Number(limit),
      }),
      prisma.auditLog.count({ where }),
    ]);

    const parsedLogs = logs.map(l => ({
      ...l,
      details: l.details ? JSON.parse(l.details) : null,
    }));

    res.json({
      success: true,
      total,
      page: Number(page),
      totalPages: Math.ceil(total / Number(limit)),
      logs: parsedLogs,
    });
  } catch (error: any) {
    console.error('getAuditLogs error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch audit logs' });
  }
};

export const exportReportCSV = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { type } = req.params; // 'students' | 'applications' | 'offers' | 'companies'

    if (type === 'students') {
      const students = await prisma.studentProfile.findMany({
        include: { offers: true },
        orderBy: { studentId: 'asc' },
      });

      let csv = 'Student ID,Full Name,College Email,Phone,Department,Course,Graduation Year,CGPA,Active Backlogs,10th %,12th %,Placed,Offers Count\n';
      students.forEach(s => {
        const isPlaced = s.offers.length > 0 ? 'YES' : 'NO';
        csv += `"${s.studentId}","${s.fullName}","${s.collegeEmail}","${s.phone}","${s.department}","${s.course}",${s.graduationYear},${s.cgpa},${s.activeBacklogs},${s.tenthPercentage},${s.twelfthPercentage},"${isPlaced}",${s.offers.length}\n`;
      });

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename="students_report.csv"');
      res.send(csv);
      return;
    }

    if (type === 'applications') {
      const apps = await prisma.application.findMany({
        include: {
          student: true,
          job: { include: { company: true } },
        },
        orderBy: { createdAt: 'desc' },
      });

      let csv = 'Application ID,Student Name,Student ID,Department,Company,Job Title,Status,Applied At\n';
      apps.forEach(a => {
        csv += `"${a.id}","${a.student.fullName}","${a.student.studentId}","${a.student.department}","${a.job.company.name}","${a.job.title}","${a.status}","${a.createdAt.toISOString()}"\n`;
      });

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename="applications_report.csv"');
      res.send(csv);
      return;
    }

    if (type === 'offers') {
      const offers = await prisma.offer.findMany({
        include: {
          student: true,
          company: true,
          job: true,
        },
        orderBy: { createdAt: 'desc' },
      });

      let csv = 'Offer ID,Student Name,Student ID,Department,Company,Job Title,Package (CTC),Designation,Location,Status,Offered At\n';
      offers.forEach(o => {
        csv += `"${o.id}","${o.student.fullName}","${o.student.studentId}","${o.student.department}","${o.company.name}","${o.job.title}","${o.ctc}","${o.designation}","${o.location}","${o.status}","${o.createdAt.toISOString()}"\n`;
      });

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename="placement_offers_report.csv"');
      res.send(csv);
      return;
    }

    res.status(400).json({ success: false, message: 'Invalid report type' });
  } catch (error: any) {
    console.error('exportReportCSV error:', error);
    res.status(500).json({ success: false, message: 'Failed to generate CSV export' });
  }
};

