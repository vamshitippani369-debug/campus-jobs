import { Response } from 'express';
import { prisma } from '../config/db.js';
import { AuthRequest } from '../middleware/auth.js';
import { EligibilityService } from '../services/eligibilityService.js';
import { AuditService } from '../services/auditService.js';
import { NotificationService } from '../services/notificationService.js';

export const getAllJobs = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const {
      search,
      companyId,
      department,
      graduationYear,
      minSalary,
      status,
      eligibleOnly,
    } = req.query;

    const where: any = {};

    // By default for students or public, only show PUBLISHED jobs
    if (req.user?.role === 'STUDENT' || !req.user) {
      where.status = 'PUBLISHED';
    } else if (status) {
      where.status = String(status);
    } else if (req.user?.role === 'RECRUITER' && req.user.companyId) {
      where.companyId = req.user.companyId;
    }

    if (companyId) {
      where.companyId = String(companyId);
    }

    if (search) {
      where.OR = [
        { title: { contains: String(search) } },
        { description: { contains: String(search) } },
        { company: { name: { contains: String(search) } } },
      ];
    }

    if (minSalary) {
      where.minSalary = { gte: Number(minSalary) };
    }

    const jobs = await prisma.job.findMany({
      where,
      include: {
        company: true,
        _count: {
          select: { applications: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    // If user is a student, evaluate student's eligibility for each job!
    let studentData: any = null;
    let appliedJobIds = new Set<string>();

    if (req.user?.role === 'STUDENT' && req.user.studentProfileId) {
      studentData = await prisma.studentProfile.findUnique({
        where: { id: req.user.studentProfileId },
      });

      const studentApplications = await prisma.application.findMany({
        where: { studentId: req.user.studentProfileId },
        select: { jobId: true, status: true },
      });

      appliedJobIds = new Set(studentApplications.map(a => a.jobId));
    }

    const formattedJobs = jobs.map(job => {
      const eligibleDepts = JSON.parse(job.eligibleDepartments || '[]');
      const eligibleYears = JSON.parse(job.eligibleGraduationYears || '[]');
      const requiredSkills = JSON.parse(job.requiredSkills || '[]');

      let eligibility: any = null;
      if (studentData) {
        const studentSkills = JSON.parse(studentData.technicalSkills || '[]');
        eligibility = EligibilityService.evaluate(
          {
            id: studentData.id,
            fullName: studentData.fullName,
            department: studentData.department,
            graduationYear: studentData.graduationYear,
            cgpa: studentData.cgpa,
            activeBacklogs: studentData.activeBacklogs,
            technicalSkills: studentSkills,
            resumeUrl: studentData.resumeUrl,
            profileCompletion: studentData.profileCompletion,
          },
          {
            id: job.id,
            title: job.title,
            status: job.status,
            minCgpa: job.minCgpa,
            maxActiveBacklogs: job.maxActiveBacklogs,
            eligibleDepartments: eligibleDepts,
            eligibleGraduationYears: eligibleYears,
            requiredSkills,
            applicationDeadline: job.applicationDeadline,
          }
        );
      }

      return {
        ...job,
        eligibleDepartments: eligibleDepts,
        eligibleGraduationYears: eligibleYears,
        requiredSkills,
        hasApplied: appliedJobIds.has(job.id),
        eligibility,
      };
    });

    // Optional filter by eligible only
    const resultJobs = (eligibleOnly === 'true' && studentData)
      ? formattedJobs.filter(j => j.eligibility?.isEligible)
      : formattedJobs;

    res.json({ success: true, count: resultJobs.length, jobs: resultJobs });
  } catch (error: any) {
    console.error('getAllJobs error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch jobs' });
  }
};

export const getJobById = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const id = String(req.params.id);

    const job = await prisma.job.findUnique({
      where: { id },
      include: {
        company: true,
        _count: {
          select: { applications: true },
        },
      },
    });

    if (!job) {
      res.status(404).json({ success: false, message: 'Job not found' });
      return;
    }

    const eligibleDepts = JSON.parse(job.eligibleDepartments || '[]');
    const eligibleYears = JSON.parse(job.eligibleGraduationYears || '[]');
    const requiredSkills = JSON.parse(job.requiredSkills || '[]');

    let eligibility: any = null;
    let application: any = null;

    if (req.user?.role === 'STUDENT' && req.user.studentProfileId) {
      const studentData = await prisma.studentProfile.findUnique({
        where: { id: req.user.studentProfileId },
      });

      if (studentData) {
        const studentSkills = JSON.parse(studentData.technicalSkills || '[]');
        eligibility = EligibilityService.evaluate(
          {
            id: studentData.id,
            fullName: studentData.fullName,
            department: studentData.department,
            graduationYear: studentData.graduationYear,
            cgpa: studentData.cgpa,
            activeBacklogs: studentData.activeBacklogs,
            technicalSkills: studentSkills,
            resumeUrl: studentData.resumeUrl,
            profileCompletion: studentData.profileCompletion,
          },
          {
            id: job.id,
            title: job.title,
            status: job.status,
            minCgpa: job.minCgpa,
            maxActiveBacklogs: job.maxActiveBacklogs,
            eligibleDepartments: eligibleDepts,
            eligibleGraduationYears: eligibleYears,
            requiredSkills,
            applicationDeadline: job.applicationDeadline,
          }
        );

        application = await prisma.application.findUnique({
          where: {
            studentId_jobId: {
              studentId: req.user.studentProfileId,
              jobId: job.id,
            },
          },
          include: {
            interviews: true,
            offer: true,
          },
        });
      }
    }

    res.json({
      success: true,
      job: {
        ...job,
        eligibleDepartments: eligibleDepts,
        eligibleGraduationYears: eligibleYears,
        requiredSkills,
      },
      eligibility,
      application,
    });
  } catch (error: any) {
    console.error('getJobById error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch job details' });
  }
};

export const createJob = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const {
      title,
      description,
      location,
      employmentType,
      salaryRange,
      minSalary,
      maxSalary,
      vacancies,
      selectionProcess,
      applicationDeadline,
      minCgpa,
      maxActiveBacklogs,
      eligibleDepartments,
      eligibleGraduationYears,
      requiredSkills,
      status,
      companyId: explicitCompanyId,
    } = req.body;

    const companyId = req.user?.role === 'ADMIN' ? explicitCompanyId : req.user?.companyId;

    if (!companyId) {
      res.status(400).json({ success: false, message: 'Recruiter must be linked to a company' });
      return;
    }

    // Check company verification
    const company = await prisma.company.findUnique({ where: { id: String(companyId) } });
    if (!company) {
      res.status(404).json({ success: false, message: 'Company not found' });
      return;
    }

    if (!company.isVerified && req.user?.role !== 'ADMIN') {
      res.status(403).json({
        success: false,
        message: 'Your company profile is pending university administrator verification before you can publish recruitment drives.',
      });
      return;
    }

    const job = await prisma.job.create({
      data: {
        companyId: String(companyId),
        title,
        description,
        location,
        employmentType: employmentType || 'FULL_TIME',
        salaryRange,
        minSalary: minSalary ? Number(minSalary) : null,
        maxSalary: maxSalary ? Number(maxSalary) : null,
        vacancies: Number(vacancies) || 1,
        selectionProcess,
        status: req.user?.role === 'ADMIN' ? (status || 'PUBLISHED') : 'PENDING_APPROVAL',
        applicationDeadline: new Date(applicationDeadline),
        minCgpa: Number(minCgpa) || 6.0,
        maxActiveBacklogs: Number(maxActiveBacklogs) || 0,
        eligibleDepartments: JSON.stringify(eligibleDepartments || []),
        eligibleGraduationYears: JSON.stringify(eligibleGraduationYears || []),
        requiredSkills: JSON.stringify(requiredSkills || []),
      },
    });

    await AuditService.log({
      userId: req.user?.id,
      userEmail: req.user?.email || 'system',
      userRole: req.user?.role || 'RECRUITER',
      action: 'JOB_CREATED',
      entityType: 'Job',
      entityId: job.id,
      details: { title, company: company.name, status: job.status },
    });

    res.status(201).json({
      success: true,
      message: job.status === 'PUBLISHED'
        ? 'Job recruitment drive published successfully'
        : 'Job submitted for university administrator approval',
      job,
    });
  } catch (error: any) {
    console.error('createJob error:', error);
    res.status(500).json({ success: false, message: 'Failed to create job' });
  }
};

export const updateJob = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const id = String(req.params.id);
    const updateData: any = { ...req.body };

    const job = await prisma.job.findUnique({ where: { id } });
    if (!job) {
      res.status(404).json({ success: false, message: 'Job not found' });
      return;
    }

    if (req.user?.role === 'RECRUITER' && req.user.companyId !== job.companyId) {
      res.status(403).json({ success: false, message: 'Unauthorized to edit this job' });
      return;
    }

    if (updateData.eligibleDepartments && Array.isArray(updateData.eligibleDepartments)) {
      updateData.eligibleDepartments = JSON.stringify(updateData.eligibleDepartments);
    }
    if (updateData.eligibleGraduationYears && Array.isArray(updateData.eligibleGraduationYears)) {
      updateData.eligibleGraduationYears = JSON.stringify(updateData.eligibleGraduationYears);
    }
    if (updateData.requiredSkills && Array.isArray(updateData.requiredSkills)) {
      updateData.requiredSkills = JSON.stringify(updateData.requiredSkills);
    }
    if (updateData.applicationDeadline) {
      updateData.applicationDeadline = new Date(updateData.applicationDeadline);
    }

    const updated = await prisma.job.update({
      where: { id },
      data: updateData,
    });

    res.json({ success: true, message: 'Job updated successfully', job: updated });
  } catch (error: any) {
    console.error('updateJob error:', error);
    res.status(500).json({ success: false, message: 'Failed to update job' });
  }
};

export const approveJob = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const id = String(req.params.id);
    const { status } = req.body;

    const job = await prisma.job.update({
      where: { id },
      data: { status: status || 'PUBLISHED' },
      include: { company: true },
    });

    await AuditService.log({
      userId: req.user!.id,
      userEmail: req.user!.email,
      userRole: 'ADMIN',
      action: status === 'PUBLISHED' ? 'JOB_APPROVED' : 'JOB_STATUS_CHANGED',
      entityType: 'Job',
      entityId: job.id,
      details: { status: job.status, title: job.title },
    });

    if (status === 'PUBLISHED') {
      await NotificationService.notifyAllStudents({
        title: `New Drive: ${job.company.name} - ${job.title}`,
        message: `${job.company.name} has opened applications for ${job.title} (${job.salaryRange}). Check your eligibility and apply before the deadline!`,
        type: 'JOB',
        link: `/opportunities/${job.id}`,
      });
    }

    res.json({ success: true, message: `Job ${job.status} successfully`, job });
  } catch (error: any) {
    console.error('approveJob error:', error);
    res.status(500).json({ success: false, message: 'Failed to update job approval status' });
  }
};

export const getJobApplicants = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const id = String(req.params.id);

    const job = await prisma.job.findUnique({
      where: { id },
      include: { company: true },
    });

    if (!job) {
      res.status(404).json({ success: false, message: 'Job not found' });
      return;
    }

    if (req.user?.role === 'RECRUITER' && req.user.companyId !== job.companyId) {
      res.status(403).json({ success: false, message: 'Access denied: not your recruitment drive' });
      return;
    }

    const applications = await prisma.application.findMany({
      where: { jobId: id },
      include: {
        student: true,
        interviews: true,
        offer: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    const parsedApplications = applications.map(app => ({
      ...app,
      eligibilityReport: app.eligibilityReport ? JSON.parse(app.eligibilityReport) : null,
      student: {
        ...app.student,
        technicalSkills: JSON.parse(app.student.technicalSkills || '[]'),
        programmingLanguages: JSON.parse(app.student.programmingLanguages || '[]'),
      },
    }));

    res.json({ success: true, count: parsedApplications.length, applications: parsedApplications, job });
  } catch (error: any) {
    console.error('getJobApplicants error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch applicants' });
  }
};
