import { Response } from 'express';
import { prisma } from '../config/db.js';
import { AuthRequest } from '../middleware/auth.js';
import { EligibilityService } from '../services/eligibilityService.js';
import { AuditService } from '../services/auditService.js';
import { NotificationService } from '../services/notificationService.js';

export const submitApplication = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { jobId, notes } = req.body;

    if (!jobId) {
      res.status(400).json({ success: false, message: 'Job ID is required' });
      return;
    }

    const student = await prisma.studentProfile.findFirst({
      where: { userId: req.user!.id },
    });

    if (!student) {
      res.status(404).json({ success: false, message: 'Student profile not found. Please complete your profile.' });
      return;
    }

    // Check if resume is uploaded
    if (!student.resumeUrl) {
      res.status(400).json({
        success: false,
        message: 'A PDF resume is mandatory to apply. Please upload your resume in Profile settings.',
      });
      return;
    }

    // Check if already applied
    const existing = await prisma.application.findUnique({
      where: {
        studentId_jobId: {
          studentId: student.id,
          jobId: String(jobId),
        },
      },
    });

    if (existing) {
      res.status(400).json({
        success: false,
        message: `You have already applied for this job drive (Status: ${existing.status})`,
      });
      return;
    }

    // Fetch Job and check eligibility
    const job = await prisma.job.findUnique({
      where: { id: String(jobId) },
      include: { company: true },
    });

    if (!job) {
      res.status(404).json({ success: false, message: 'Job not found' });
      return;
    }

    const eligibleDepts = JSON.parse(job.eligibleDepartments || '[]');
    const eligibleYears = JSON.parse(job.eligibleGraduationYears || '[]');
    const requiredSkills = JSON.parse(job.requiredSkills || '[]');
    const studentSkills = JSON.parse(student.technicalSkills || '[]');

    // Run backend deterministic eligibility check
    const report = EligibilityService.evaluate(
      {
        id: student.id,
        fullName: student.fullName,
        department: student.department,
        graduationYear: student.graduationYear,
        cgpa: student.cgpa,
        activeBacklogs: student.activeBacklogs,
        technicalSkills: studentSkills,
        resumeUrl: student.resumeUrl,
        profileCompletion: student.profileCompletion,
      },
      {
        id: job.id,
        title: job.title,
        status: job.status,
        minCgpa: job.minCgpa,
        maxActiveBacklogs: job.maxActiveBacklogs,
        eligibleDepartments: eligibleDepts,
        eligibleGraduationYears: eligibleYears,
        requiredSkills,
        applicationDeadline: job.applicationDeadline,
      }
    );

    if (!report.canApply) {
      res.status(400).json({
        success: false,
        message: report.blockReason || 'You do not meet the mandatory eligibility criteria for this job drive.',
        eligibilityReport: report,
      });
      return;
    }

    // Create Application
    const application = await prisma.application.create({
      data: {
        studentId: student.id,
        jobId: job.id,
        status: 'SUBMITTED',
        eligibilityReport: JSON.stringify(report),
        resumeUrl: student.resumeUrl,
        notes: notes || null,
      },
      include: {
        job: { include: { company: true } },
      },
    });

    // Notify student
    await NotificationService.createNotification({
      userId: req.user!.id,
      title: 'Application Submitted',
      message: `Your application for ${job.title} at ${job.company.name} has been received successfully.`,
      type: 'APPLICATION',
      link: `/applications`,
    });

    // Audit log
    await AuditService.log({
      userId: req.user!.id,
      userEmail: req.user!.email,
      userRole: 'STUDENT',
      action: 'APPLICATION_SUBMITTED',
      entityType: 'Application',
      entityId: application.id,
      details: { jobId: job.id, jobTitle: job.title, company: job.company.name },
    });

    res.status(201).json({
      success: true,
      message: 'Application submitted successfully!',
      application: {
        ...application,
        eligibilityReport: report,
      },
    });
  } catch (error: any) {
    console.error('submitApplication error:', error);
    res.status(500).json({ success: false, message: 'Failed to submit application' });
  }
};

export const getMyApplications = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const student = await prisma.studentProfile.findFirst({
      where: { userId: req.user!.id },
    });

    if (!student) {
      res.status(404).json({ success: false, message: 'Student profile not found' });
      return;
    }

    const applications = await prisma.application.findMany({
      where: { studentId: student.id },
      include: {
        job: {
          include: { company: true },
        },
        interviews: {
          orderBy: { scheduledDate: 'desc' },
        },
        offer: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    const parsed = applications.map(app => ({
      ...app,
      eligibilityReport: app.eligibilityReport ? JSON.parse(app.eligibilityReport) : null,
      job: {
        ...app.job,
        eligibleDepartments: JSON.parse(app.job.eligibleDepartments || '[]'),
        requiredSkills: JSON.parse(app.job.requiredSkills || '[]'),
      },
    }));

    res.json({ success: true, count: parsed.length, applications: parsed });
  } catch (error: any) {
    console.error('getMyApplications error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch applications' });
  }
};

export const updateApplicationStatus = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const id = String(req.params.id);
    const { status, notes } = req.body;

    const validStatuses = ['SUBMITTED', 'SHORTLISTED', 'INTERVIEW_SCHEDULED', 'SELECTED', 'REJECTED', 'WITHDRAWN'];
    if (!validStatuses.includes(status)) {
      res.status(400).json({ success: false, message: `Invalid status. Must be one of: ${validStatuses.join(', ')}` });
      return;
    }

    const application = await prisma.application.findUnique({
      where: { id },
      include: {
        job: { include: { company: true } },
        student: { include: { user: true } },
      },
    });

    if (!application) {
      res.status(404).json({ success: false, message: 'Application not found' });
      return;
    }

    // Role check: recruiter can only update for their company
    if (req.user?.role === 'RECRUITER' && req.user.companyId !== application.job.companyId) {
      res.status(403).json({ success: false, message: 'Unauthorized to manage this application' });
      return;
    }

    const updated = await prisma.application.update({
      where: { id },
      data: {
        status,
        notes: notes !== undefined ? notes : application.notes,
      },
      include: {
        job: { include: { company: true } },
        student: true,
      },
    });

    // Notify Student
    let notificationTitle = 'Application Status Updated';
    let notificationMsg = `Your application for ${application.job.title} at ${application.job.company.name} is now ${status}.`;

    if (status === 'SHORTLISTED') {
      notificationTitle = '🎉 You are Shortlisted!';
      notificationMsg = `Congratulations! You have been shortlisted by ${application.job.company.name} for ${application.job.title}. Prepare for upcoming interview rounds!`;
    } else if (status === 'SELECTED') {
      notificationTitle = '🏆 Congratulations! You have been Selected!';
      notificationMsg = `Incredible news! ${application.job.company.name} has selected you for the role of ${application.job.title}. Check your offers tab!`;
    } else if (status === 'REJECTED') {
      notificationTitle = 'Application Update';
      notificationMsg = `Thank you for your interest in ${application.job.company.name}. Unfortunately, you were not selected for ${application.job.title} at this time.`;
    }

    await NotificationService.createNotification({
      userId: application.student.userId,
      title: notificationTitle,
      message: notificationMsg,
      type: status === 'SELECTED' ? 'OFFER' : 'APPLICATION',
      link: '/applications',
    });

    // Audit log
    await AuditService.log({
      userId: req.user!.id,
      userEmail: req.user!.email,
      userRole: req.user!.role,
      action: `APPLICATION_${status}`,
      entityType: 'Application',
      entityId: application.id,
      details: {
        jobTitle: application.job.title,
        company: application.job.company.name,
        studentName: application.student.fullName,
        previousStatus: application.status,
        newStatus: status,
      },
    });

    res.json({
      success: true,
      message: `Candidate status updated to ${status}`,
      application: updated,
    });
  } catch (error: any) {
    console.error('updateApplicationStatus error:', error);
    res.status(500).json({ success: false, message: 'Failed to update application status' });
  }
};

export const withdrawApplication = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const id = String(req.params.id);

    const student = await prisma.studentProfile.findFirst({
      where: { userId: req.user!.id },
    });

    if (!student) {
      res.status(404).json({ success: false, message: 'Student profile not found' });
      return;
    }

    const application = await prisma.application.findUnique({
      where: { id },
      include: { job: { include: { company: true } } },
    });

    if (!application || application.studentId !== student.id) {
      res.status(404).json({ success: false, message: 'Application not found or unauthorized' });
      return;
    }

    if (application.status === 'SELECTED') {
      res.status(400).json({ success: false, message: 'Cannot withdraw an accepted or selected placement' });
      return;
    }

    const updated = await prisma.application.update({
      where: { id },
      data: { status: 'WITHDRAWN' },
    });

    await AuditService.log({
      userId: req.user!.id,
      userEmail: req.user!.email,
      userRole: 'STUDENT',
      action: 'APPLICATION_WITHDRAWN',
      entityType: 'Application',
      entityId: application.id,
      details: { jobTitle: application.job.title, company: application.job.company.name },
    });

    res.json({ success: true, message: 'Application withdrawn successfully', application: updated });
  } catch (error: any) {
    console.error('withdrawApplication error:', error);
    res.status(500).json({ success: false, message: 'Failed to withdraw application' });
  }
};
