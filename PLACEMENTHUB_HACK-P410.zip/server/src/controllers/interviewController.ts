import { Response } from 'express';
import { prisma } from '../config/db.js';
import { AuthRequest } from '../middleware/auth.js';
import { AuditService } from '../services/auditService.js';
import { NotificationService } from '../services/notificationService.js';

export const scheduleInterview = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const {
      applicationId,
      round,
      scheduledDate,
      scheduledTime,
      durationMinutes,
      mode,
      meetingLink,
      venue,
      instructions,
    } = req.body;

    if (!applicationId || !round || !scheduledDate || !scheduledTime) {
      res.status(400).json({ success: false, message: 'Missing required interview fields' });
      return;
    }

    const application = await prisma.application.findUnique({
      where: { id: String(applicationId) },
      include: {
        job: { include: { company: true } },
        student: { include: { user: true } },
      },
    });

    if (!application) {
      res.status(404).json({ success: false, message: 'Application not found' });
      return;
    }

    if (req.user?.role === 'RECRUITER' && req.user.companyId !== application.job.companyId) {
      res.status(403).json({ success: false, message: 'Unauthorized to schedule interviews for this applicant' });
      return;
    }

    const interview = await prisma.interview.create({
      data: {
        applicationId: String(applicationId),
        studentId: application.studentId,
        jobId: application.jobId,
        round,
        scheduledDate,
        scheduledTime,
        durationMinutes: Number(durationMinutes) || 45,
        mode: mode || 'ONLINE',
        meetingLink: meetingLink || null,
        venue: venue || null,
        instructions: instructions || null,
        status: 'SCHEDULED',
      },
    });

    // Update application status to INTERVIEW_SCHEDULED
    await prisma.application.update({
      where: { id: String(applicationId) },
      data: { status: 'INTERVIEW_SCHEDULED' },
    });

    // Notify Student
    await NotificationService.createNotification({
      userId: application.student.userId,
      title: `📅 Interview Scheduled: ${round} Round`,
      message: `${application.job.company.name} has scheduled your ${round} interview on ${scheduledDate} at ${scheduledTime} (${mode}). Check details in your calendar!`,
      type: 'INTERVIEW',
      link: '/interviews',
    });

    // Audit log
    await AuditService.log({
      userId: req.user!.id,
      userEmail: req.user!.email,
      userRole: req.user!.role,
      action: 'INTERVIEW_SCHEDULED',
      entityType: 'Interview',
      entityId: interview.id,
      details: {
        candidate: application.student.fullName,
        company: application.job.company.name,
        round,
        scheduledDate,
        scheduledTime,
      },
    });

    res.status(201).json({
      success: true,
      message: 'Interview scheduled successfully',
      interview,
    });
  } catch (error: any) {
    console.error('scheduleInterview error:', error);
    res.status(500).json({ success: false, message: 'Failed to schedule interview' });
  }
};

export const updateInterview = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const id = String(req.params.id);
    const { status, feedback, result, meetingLink, venue, instructions, scheduledDate, scheduledTime } = req.body;

    const interview = await prisma.interview.findUnique({
      where: { id },
      include: {
        job: { include: { company: true } },
        student: { include: { user: true } },
      },
    });

    if (!interview) {
      res.status(404).json({ success: false, message: 'Interview not found' });
      return;
    }

    if (req.user?.role === 'RECRUITER' && req.user.companyId !== interview.job.companyId) {
      res.status(403).json({ success: false, message: 'Unauthorized to update this interview' });
      return;
    }

    const updatedData: any = {};
    if (status !== undefined) updatedData.status = status;
    if (feedback !== undefined) updatedData.feedback = feedback;
    if (result !== undefined) updatedData.result = result;
    if (meetingLink !== undefined) updatedData.meetingLink = meetingLink;
    if (venue !== undefined) updatedData.venue = venue;
    if (instructions !== undefined) updatedData.instructions = instructions;
    if (scheduledDate !== undefined) updatedData.scheduledDate = scheduledDate;
    if (scheduledTime !== undefined) updatedData.scheduledTime = scheduledTime;

    const updated = await prisma.interview.update({
      where: { id },
      data: updatedData,
    });

    if (result === 'PASSED') {
      await NotificationService.createNotification({
        userId: interview.student.userId,
        title: `Interview Round Cleared!`,
        message: `Congratulations! You have successfully cleared the ${interview.round} round with ${interview.job.company.name}.`,
        type: 'INTERVIEW',
        link: '/interviews',
      });
    }

    res.json({ success: true, message: 'Interview updated successfully', interview: updated });
  } catch (error: any) {
    console.error('updateInterview error:', error);
    res.status(500).json({ success: false, message: 'Failed to update interview' });
  }
};

export const getMyInterviews = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const student = await prisma.studentProfile.findFirst({
      where: { userId: req.user!.id },
    });

    if (!student) {
      res.status(404).json({ success: false, message: 'Student profile not found' });
      return;
    }

    const interviews = await prisma.interview.findMany({
      where: { studentId: student.id },
      include: {
        job: {
          include: { company: true },
        },
      },
      orderBy: { scheduledDate: 'asc' },
    });

    res.json({ success: true, count: interviews.length, interviews });
  } catch (error: any) {
    console.error('getMyInterviews error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch interviews' });
  }
};

export const getRecruiterInterviews = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user?.companyId && req.user?.role !== 'ADMIN') {
      res.status(403).json({ success: false, message: 'Unauthorized' });
      return;
    }

    const where: any = {};
    if (req.user.companyId && req.user.role !== 'ADMIN') {
      where.job = { companyId: req.user.companyId };
    }

    const interviews = await prisma.interview.findMany({
      where,
      include: {
        student: true,
        job: { include: { company: true } },
      },
      orderBy: { scheduledDate: 'asc' },
    });

    res.json({ success: true, count: interviews.length, interviews });
  } catch (error: any) {
    console.error('getRecruiterInterviews error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch interviews' });
  }
};
