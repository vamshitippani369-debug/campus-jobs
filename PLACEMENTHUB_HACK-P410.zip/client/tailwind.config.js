/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#172554', // Deep Navy
          light: '#1e3a8a',
          dark: '#0f172a',
        },
        accent: {
          DEFAULT: '#2563EB', // Blue
          light: '#3b82f6',
          dark: '#1d4ed8',
        },
        slate: {
          DEFAULT: '#475569',
        },
        background: '#F8FAFC',
        surface: '#FFFFFF',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
      },
    },
  },
  plugins: [],
}

