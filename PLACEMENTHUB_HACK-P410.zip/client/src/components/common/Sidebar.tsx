import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  Briefcase,
  FileText,
  Calendar,
  Award,
  UserCheck,
  Building,
  PlusCircle,
  BarChart3,
  Users,
  CheckSquare,
  History,
  Sparkles,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const Sidebar: React.FC = () => {
  const { user } = useAuth();

  const studentLinks = [
    { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/opportunities', label: 'Browse Drives', icon: Briefcase },
    { to: '/applications', label: 'My Applications', icon: FileText },
    { to: '/interviews', label: 'Interview Calendar', icon: Calendar },
    { to: '/offers', label: 'Offers & Selections', icon: Award },
    { to: '/profile', label: 'Profile & Resume', icon: UserCheck },
  ];

  const recruiterLinks = [
    { to: '/recruiter/dashboard', label: 'Recruiter Dashboard', icon: LayoutDashboard },
    { to: '/recruiter/jobs', label: 'Recruitment Drives', icon: Briefcase },
    { to: '/recruiter/jobs/create', label: 'Post New Drive', icon: PlusCircle },
    { to: '/recruiter/company', label: 'Company Profile', icon: Building },
  ];

  const adminLinks = [
    { to: '/admin/dashboard', label: 'Placement Analytics', icon: BarChart3 },
    { to: '/admin/students', label: 'Student Directory', icon: Users },
    { to: '/admin/companies', label: 'Companies & Recruiters', icon: Building },
    { to: '/admin/jobs', label: 'Drive Approvals', icon: CheckSquare },
    { to: '/admin/audit-logs', label: 'Audit Trail', icon: History },
  ];

  const links =
    user?.role === 'ADMIN'
      ? adminLinks
      : user?.role === 'RECRUITER'
      ? recruiterLinks
      : studentLinks;

  return (
    <aside className="w-64 bg-white border-r border-slate-200/80 min-h-[calc(100vh-4rem)] p-4 flex flex-col justify-between shrink-0 hidden md:flex">
      <div className="space-y-6">
        {/* Navigation list */}
        <div className="space-y-1">
          <div className="px-3 pb-2 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
            Navigation
          </div>
          {links.map((link) => {
            const Icon = link.icon;
            return (
              <NavLink
                key={link.to}
                to={link.to}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-all ${
                    isActive
                      ? 'bg-blue-50 text-blue-700 font-semibold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`
                }
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{link.label}</span>
              </NavLink>
            );
          })}
        </div>
      </div>

      {/* University Brand Footnote */}
      <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/60 text-[11px] text-slate-500">
        <div className="flex items-center gap-1.5 font-semibold text-slate-700">
          <Sparkles className="w-3.5 h-3.5 text-blue-600" />
          PLACEMENTHUB Core
        </div>
        <p className="mt-1 text-[10px] leading-relaxed text-slate-500">
          Deterministic university placement engine v2.4 (HACK-P410)
        </p>
      </div>
    </aside>
  );
};

