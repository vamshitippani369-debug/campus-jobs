import React from 'react';
import { CheckCircle2, XCircle, AlertCircle, ShieldCheck, Sparkles } from 'lucide-react';
import { EligibilityReport } from '../../types';

interface Props {
  report: EligibilityReport | null | undefined;
  compact?: boolean;
}

export const EligibilityReportCard: React.FC<Props> = ({ report, compact = false }) => {
  if (!report) return null;

  if (compact) {
    return (
      <div className={`p-3 rounded-lg border ${
        report.isEligible ? 'bg-emerald-50/60 border-emerald-200' : 'bg-rose-50/60 border-rose-200'
      }`}>
        <div className="flex items-center gap-2">
          {report.isEligible ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          ) : (
            <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
          )}
          <span className={`text-xs font-semibold ${
            report.isEligible ? 'text-emerald-900' : 'text-rose-900'
          }`}>
            {report.isEligible ? 'Eligible for Drive' : 'Criteria Not Met'}
          </span>
          <span className="text-xs text-slate-500 ml-auto">
            {report.skillMatch.matchPercentage}% Skill Match
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
      {/* Header */}
      <div className={`px-5 py-4 border-b flex items-center justify-between ${
        report.isEligible ? 'bg-emerald-50/40 border-emerald-100' : 'bg-rose-50/40 border-rose-100'
      }`}>
        <div className="flex items-center gap-2.5">
          <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
            report.isEligible ? 'bg-emerald-600 text-white' : 'bg-rose-600 text-white'
          }`}>
            {report.isEligible ? <ShieldCheck className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
          </div>
          <div>
            <h4 className="text-sm font-semibold text-slate-900">Deterministic Eligibility Verification</h4>
            <p className="text-xs text-slate-500">Evaluated server-side using strict institutional placement rules</p>
          </div>
        </div>

        <div className={`px-3 py-1 rounded-full text-xs font-semibold ${
          report.isEligible
            ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
            : 'bg-rose-100 text-rose-800 border border-rose-200'
        }`}>
          {report.isEligible ? 'VERIFIED ELIGIBLE' : 'INELIGIBLE'}
        </div>
      </div>

      {/* Criteria Breakdown Grid */}
      <div className="p-5 space-y-4">
        <div>
          <h5 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2.5">
            Academic Criteria Breakdown
          </h5>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
            {report.criteriaBreakdown.map((criterion, idx) => (
              <div
                key={idx}
                className={`p-3 rounded-lg border text-xs flex items-start gap-2.5 ${
                  criterion.status === 'PASS'
                    ? 'bg-slate-50/70 border-slate-200/80 text-slate-700'
                    : 'bg-rose-50/50 border-rose-200 text-rose-800'
                }`}
              >
                {criterion.status === 'PASS' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                ) : (
                  <XCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                )}
                <div>
                  <div className="font-semibold">{criterion.name}</div>
                  <div className="text-slate-600 mt-0.5">{criterion.message}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Skills Match Indicator */}
        <div className="pt-3 border-t border-slate-100">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              Technical Skills Alignment ({report.skillMatch.matchPercentage}%)
            </span>
            <span className="text-xs text-slate-500">
              {report.skillMatch.matchedSkills.length} of {report.skillMatch.matchedSkills.length + report.skillMatch.missingSkills.length} skills matched
            </span>
          </div>

          {/* Progress bar */}
          <div className="w-full bg-slate-100 rounded-full h-2 mb-3">
            <div
              className={`h-2 rounded-full transition-all duration-500 ${
                report.skillMatch.matchPercentage >= 70
                  ? 'bg-emerald-500'
                  : report.skillMatch.matchPercentage >= 40
                  ? 'bg-blue-500'
                  : 'bg-amber-500'
              }`}
              style={{ width: `${report.skillMatch.matchPercentage}%` }}
            />
          </div>

          {/* Skill tags */}
          <div className="flex flex-wrap gap-1.5">
            {report.skillMatch.matchedSkills.map((skill, i) => (
              <span
                key={i}
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200"
              >
                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                {skill}
              </span>
            ))}
            {report.skillMatch.missingSkills.map((skill, i) => (
              <span
                key={i}
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-600 border border-slate-200"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-slate-400" />
                {skill}
              </span>
            ))}
          </div>
        </div>

        {/* Ineligibility or Blocker Notice */}
        {!report.canApply && report.blockReason && (
          <div className="p-3 bg-amber-50 rounded-lg border border-amber-200 text-xs text-amber-900 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold">Application Requirement: </span>
              {report.blockReason}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

