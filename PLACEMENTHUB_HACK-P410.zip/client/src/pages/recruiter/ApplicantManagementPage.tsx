import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  ArrowLeft,
  Users,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Calendar,
  Award,
  FileText,
  Clock,
  Sparkles,
  ExternalLink,
  ChevronDown,
  ShieldCheck,
} from 'lucide-react';
import { api } from '../../services/api';
import { Application, Job } from '../../types';
import { Badge } from '../../components/common/Badge';

export const ApplicantManagementPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();

  const [job, setJob] = useState<Job | null>(null);
  const [applications, setApplications] = useState<Application[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Filters
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [minCgpaFilter, setMinCgpaFilter] = useState('');
  const [deptFilter, setDeptFilter] = useState('');

  // Modals
  const [interviewModalApp, setInterviewModalApp] = useState<Application | null>(null);
  const [offerModalApp, setOfferModalApp] = useState<Application | null>(null);
  const [auditModalApp, setAuditModalApp] = useState<Application | null>(null);

  // Interview Form state
  const [interviewForm, setInterviewForm] = useState({
    round: 'TECHNICAL',
    scheduledDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    scheduledTime: '10:00 AM',
    durationMinutes: 45,
    mode: 'ONLINE',
    meetingLink: 'https://meet.google.com/hck-p410-demo',
    venue: '',
    instructions: 'Please be ready 5 minutes before scheduled time with coding IDE open.',
  });

  // Offer Form state
  const [offerForm, setOfferForm] = useState({
    ctc: '15.0 LPA',
    designation: 'Software Development Engineer',
    location: 'Bengaluru, India',
    joiningDate: '2026-07-01',
  });

  const [isActionLoading, setIsActionLoading] = useState(false);

  useEffect(() => {
    fetchApplicants();
  }, [id]);

  const fetchApplicants = async () => {
    try {
      const res = await api.get(`/jobs/${id}/applicants`);
      if (res.data.success) {
        setJob(res.data.job);
        setApplications(res.data.applications);
        if (res.data.job) {
          setOfferForm(prev => ({
            ...prev,
            ctc: res.data.job.salaryRange || '15.0 LPA',
            designation: res.data.job.title,
            location: res.data.job.location || 'Bengaluru, India',
          }));
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateStatus = async (appId: string, status: string) => {
    try {
      const res = await api.patch(`/applications/${appId}/status`, { status });
      if (res.data.success) {
        setApplications(prev =>
          prev.map(a => (a.id === appId ? { ...a, status: status as any } : a))
        );
      }
    } catch (err: any) {
      alert(err.response?.data?.message || 'Failed to update status');
    }
  };

  const handleScheduleInterviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!interviewModalApp) return;

    setIsActionLoading(true);
    try {
      const res = await api.post('/interviews', {
        applicationId: interviewModalApp.id,
        ...interviewForm,
      });

      if (res.data.success) {
        setApplications(prev =>
          prev.map(a => (a.id === interviewModalApp.id ? { ...a, status: 'INTERVIEW_SCHEDULED' } : a))
        );
        setInterviewModalApp(null);
      }
    } catch (err: any) {
      alert(err.response?.data?.message || 'Failed to schedule interview');
    } finally {
      setIsActionLoading(false);
    }
  };

  const handleCreateOfferSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!offerModalApp) return;

    setIsActionLoading(true);
    try {
      const res = await api.post('/offers', {
        applicationId: offerModalApp.id,
        ...offerForm,
      });

      if (res.data.success) {
        setApplications(prev =>
          prev.map(a => (a.id === offerModalApp.id ? { ...a, status: 'SELECTED' } : a))
        );
        setOfferModalApp(null);
      }
    } catch (err: any) {
      alert(err.response?.data?.message || 'Failed to issue offer');
    } finally {
      setIsActionLoading(false);
    }
  };

  const filteredApplications = applications.filter(app => {
    if (statusFilter !== 'ALL' && app.status !== statusFilter) return false;
    if (deptFilter && !app.student.department.toLowerCase().includes(deptFilter.toLowerCase())) return false;
    if (minCgpaFilter && app.student.cgpa < Number(minCgpaFilter)) return false;
    if (search) {
      const q = search.toLowerCase();
      const matchName = app.student.fullName.toLowerCase().includes(q);
      const matchRoll = app.student.studentId.toLowerCase().includes(q);
      if (!matchName && !matchRoll) return false;
    }
    return true;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'SELECTED':
        return <Badge variant="success">Placed / Selected</Badge>;
      case 'SHORTLISTED':
        return <Badge variant="primary">Shortlisted</Badge>;
      case 'INTERVIEW_SCHEDULED':
        return <Badge variant="info">Interview Scheduled</Badge>;
      case 'REJECTED':
        return <Badge variant="danger">Rejected</Badge>;
      case 'WITHDRAWN':
        return <Badge variant="slate">Withdrawn</Badge>;
      default:
        return <Badge variant="warning">Submitted</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div>
        <Link
          to="/recruiter/jobs"
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors mb-3"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          Back to Recruitment Drives
        </Link>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              Candidate Pipeline: {job?.title || 'Drive'}
            </h1>
            <p className="text-xs text-slate-500 mt-0.5">
              Review verified applicants, inspect resumes, schedule interviews, and issue placement offers
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="px-3 py-1.5 rounded-lg bg-blue-50 border border-blue-200 text-xs font-bold text-blue-800">
              {applications.length} Total Verified Submissions
            </span>
          </div>
        </div>
      </div>

      {/* Filter Cockpit */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3 text-xs">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">Search Candidate</label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by name or roll..."
                className="w-full pl-8 pr-2.5 py-1.5 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">Filter by Stage</label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs bg-white focus:outline-none"
            >
              <option value="ALL">All Stages ({applications.length})</option>
              <option value="SUBMITTED">Submitted</option>
              <option value="SHORTLISTED">Shortlisted</option>
              <option value="INTERVIEW_SCHEDULED">Interview Scheduled</option>
              <option value="SELECTED">Selected / Offered</option>
              <option value="REJECTED">Rejected</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">Min CGPA Filter</label>
            <input
              type="number"
              step="0.1"
              value={minCgpaFilter}
              onChange={(e) => setMinCgpaFilter(e.target.value)}
              placeholder="e.g. 8.0"
              className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">Department Filter</label>
            <select
              value={deptFilter}
              onChange={(e) => setDeptFilter(e.target.value)}
              className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs bg-white focus:outline-none"
            >
              <option value="">All Departments</option>
              <option value="CSE">CSE</option>
              <option value="IT">IT</option>
              <option value="ECE">ECE</option>
              <option value="EEE">EEE</option>
              <option value="Mechanical">Mechanical</option>
            </select>
          </div>
        </div>
      </div>

      {/* Applicant Table */}
      {isLoading ? (
        <div className="h-64 flex items-center justify-center">
          <div className="w-7 h-7 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : filteredApplications.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <Users className="w-10 h-10 text-slate-300 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-slate-800">No applicants match filter</h3>
          <p className="text-xs text-slate-500 mt-1">Try resetting the stage or CGPA filter</p>
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold">
                  <th className="py-3 px-4">Candidate</th>
                  <th className="py-3 px-4">Dept / Batch</th>
                  <th className="py-3 px-4">Academic Record</th>
                  <th className="py-3 px-4">Eligibility Snapshot</th>
                  <th className="py-3 px-4">Stage</th>
                  <th className="py-3 px-4">Resume</th>
                  <th className="py-3 px-4 text-right">Recruiter Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredApplications.map((app) => (
                  <tr key={app.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900">{app.student.fullName}</div>
                      <div className="text-[11px] text-slate-500">{app.student.studentId} • {app.student.collegeEmail}</div>
                    </td>

                    <td className="py-3.5 px-4 text-slate-700">
                      <div>{app.student.department}</div>
                      <div className="text-[11px] text-slate-400">Class of {app.student.graduationYear}</div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900">CGPA: {app.student.cgpa.toFixed(2)}</div>
                      <div className="text-[11px] text-slate-500">Backlogs: {app.student.activeBacklogs}</div>
                    </td>

                    <td className="py-3.5 px-4">
                      <button
                        onClick={() => setAuditModalApp(app)}
                        className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200 hover:bg-emerald-100 transition-colors"
                      >
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Verified 100% Pass</span>
                      </button>
                    </td>

                    <td className="py-3.5 px-4">{getStatusBadge(app.status)}</td>

                    <td className="py-3.5 px-4">
                      {app.student.resumeUrl ? (
                        <a
                          href={app.student.resumeUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-xs text-blue-600 hover:underline font-medium"
                        >
                          <FileText className="w-3.5 h-3.5" />
                          <span>PDF Resume</span>
                        </a>
                      ) : (
                        <span className="text-slate-400">No Resume</span>
                      )}
                    </td>

                    <td className="py-3.5 px-4 text-right space-x-1.5">
                      {app.status === 'SUBMITTED' && (
                        <button
                          onClick={() => handleUpdateStatus(app.id, 'SHORTLISTED')}
                          className="px-2.5 py-1 bg-purple-50 text-purple-700 border border-purple-200 hover:bg-purple-100 rounded text-xs font-semibold transition-colors"
                        >
                          Shortlist
                        </button>
                      )}

                      {['SHORTLISTED', 'INTERVIEW_SCHEDULED'].includes(app.status) && (
                        <button
                          onClick={() => setInterviewModalApp(app)}
                          className="px-2.5 py-1 bg-blue-50 text-blue-700 border border-blue-200 hover:bg-blue-100 rounded text-xs font-semibold transition-colors"
                        >
                          Schedule Interview
                        </button>
                      )}

                      {['SHORTLISTED', 'INTERVIEW_SCHEDULED'].includes(app.status) && (
                        <button
                          onClick={() => setOfferModalApp(app)}
                          className="px-2.5 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100 rounded text-xs font-semibold transition-colors"
                        >
                          Issue Offer
                        </button>
                      )}

                      {app.status !== 'REJECTED' && app.status !== 'SELECTED' && (
                        <button
                          onClick={() => handleUpdateStatus(app.id, 'REJECTED')}
                          className="px-2.5 py-1 bg-slate-50 text-rose-700 hover:bg-rose-50 border border-slate-200 rounded text-xs font-medium transition-colors"
                        >
                          Reject
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Schedule Interview Modal */}
      {interviewModalApp && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Schedule Interview Round</h3>
                <p className="text-xs text-slate-500">Candidate: {interviewModalApp.student.fullName} ({interviewModalApp.student.studentId})</p>
              </div>
              <button onClick={() => setInterviewModalApp(null)} className="text-slate-400 hover:text-slate-600 font-bold">
                ✕
              </button>
            </div>

            <form onSubmit={handleScheduleInterviewSubmit} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Interview Round</label>
                  <select
                    value={interviewForm.round}
                    onChange={(e) => setInterviewForm({ ...interviewForm, round: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="TECHNICAL">Technical Round</option>
                    <option value="HR">HR Culture Round</option>
                    <option value="ONLINE_ASSESSMENT">Online Assessment</option>
                    <option value="GROUP_DISCUSSION">Group Discussion</option>
                    <option value="FINAL">Final Leadership Round</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Interview Mode</label>
                  <select
                    value={interviewForm.mode}
                    onChange={(e) => setInterviewForm({ ...interviewForm, mode: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="ONLINE">Online Video</option>
                    <option value="OFFLINE">Offline On-Campus</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Interview Date</label>
                  <input
                    type="date"
                    required
                    value={interviewForm.scheduledDate}
                    onChange={(e) => setInterviewForm({ ...interviewForm, scheduledDate: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Interview Time</label>
                  <input
                    type="text"
                    required
                    value={interviewForm.scheduledTime}
                    onChange={(e) => setInterviewForm({ ...interviewForm, scheduledTime: e.target.value })}
                    placeholder="e.g. 11:00 AM"
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              {interviewForm.mode === 'ONLINE' ? (
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Meeting Link (Google Meet / Zoom)</label>
                  <input
                    type="url"
                    value={interviewForm.meetingLink}
                    onChange={(e) => setInterviewForm({ ...interviewForm, meetingLink: e.target.value })}
                    placeholder="https://meet.google.com/xyz"
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>
              ) : (
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">On-Campus Venue / Room</label>
                  <input
                    type="text"
                    value={interviewForm.venue}
                    onChange={(e) => setInterviewForm({ ...interviewForm, venue: e.target.value })}
                    placeholder="e.g. Placement Cell Conference Room B"
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>
              )}

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Instructions for Student</label>
                <textarea
                  rows={2}
                  value={interviewForm.instructions}
                  onChange={(e) => setInterviewForm({ ...interviewForm, instructions: e.target.value })}
                  className="w-full p-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setInterviewModalApp(null)}
                  className="px-3 py-1.5 border border-slate-300 rounded-lg font-semibold text-slate-600 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isActionLoading}
                  className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold transition-colors disabled:opacity-50"
                >
                  {isActionLoading ? 'Scheduling...' : 'Confirm Schedule & Notify Student'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Issue Placement Offer Modal */}
      {offerModalApp && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Issue Official Placement Offer</h3>
                <p className="text-xs text-slate-500">Candidate: {offerModalApp.student.fullName} ({offerModalApp.student.studentId})</p>
              </div>
              <button onClick={() => setOfferModalApp(null)} className="text-slate-400 hover:text-slate-600 font-bold">
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateOfferSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Annual CTC Package</label>
                <input
                  type="text"
                  required
                  value={offerForm.ctc}
                  onChange={(e) => setOfferForm({ ...offerForm, ctc: e.target.value })}
                  placeholder="e.g. 16.5 LPA"
                  className="w-full p-2 border border-slate-300 rounded-lg font-bold text-emerald-700"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Job Designation</label>
                <input
                  type="text"
                  required
                  value={offerForm.designation}
                  onChange={(e) => setOfferForm({ ...offerForm, designation: e.target.value })}
                  className="w-full p-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Posting Location</label>
                  <input
                    type="text"
                    required
                    value={offerForm.location}
                    onChange={(e) => setOfferForm({ ...offerForm, location: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Tentative Joining Date</label>
                  <input
                    type="date"
                    value={offerForm.joiningDate}
                    onChange={(e) => setOfferForm({ ...offerForm, joiningDate: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setOfferModalApp(null)}
                  className="px-3 py-1.5 border border-slate-300 rounded-lg font-semibold text-slate-600 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isActionLoading}
                  className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold transition-colors disabled:opacity-50"
                >
                  {isActionLoading ? 'Issuing...' : 'Extend Offer & Notify Student'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Eligibility Audit Snapshot Modal */}
      {auditModalApp && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Deterministic Eligibility Snapshot</h3>
                <p className="text-xs text-slate-500">{auditModalApp.student.fullName} ({auditModalApp.student.studentId})</p>
              </div>
              <button onClick={() => setAuditModalApp(null)} className="text-slate-400 hover:text-slate-600 font-bold">
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              {auditModalApp.eligibilityReport?.criteriaBreakdown?.map((c: any, i: number) => (
                <div key={i} className="p-2.5 rounded-lg border bg-slate-50 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <div>
                    <div className="font-bold text-slate-800">{c.name}</div>
                    <div className="text-slate-600">{c.message}</div>
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={() => setAuditModalApp(null)}
              className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs rounded-lg transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

