import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Briefcase,
  Users,
  CheckCircle2,
  Calendar,
  Award,
  PlusCircle,
  Building2,
  ArrowRight,
  ShieldCheck,
  AlertCircle,
} from 'lucide-react';
import { api } from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import { Badge } from '../../components/common/Badge';

export const RecruiterDashboard: React.FC = () => {
  const { user } = useAuth();
  const [jobs, setJobs] = useState<any[]>([]);
  const [company, setCompany] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchRecruiterData();
  }, []);

  const fetchRecruiterData = async () => {
    try {
      const [jobsRes, compRes] = await Promise.all([
        api.get('/jobs'),
        user?.recruiterProfile?.companyId
          ? api.get(`/companies/${user.recruiterProfile.companyId}`)
          : Promise.resolve({ data: { company: null } }),
      ]);

      if (jobsRes.data.success) {
        setJobs(jobsRes.data.jobs);
      }
      if (compRes.data.company) {
        setCompany(compRes.data.company);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const totalDrives = jobs.length;
  const activeDrives = jobs.filter(j => j.status === 'PUBLISHED').length;
  const totalApplicants = jobs.reduce((sum, j) => sum + (j._count?.applications || 0), 0);

  return (
    <div className="space-y-6">
      {/* Company Verification Banner */}
      {company && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xs">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-center font-bold text-xl text-blue-800 shrink-0">
              {company.name.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold text-slate-900">{company.name}</h1>
                {company.isVerified ? (
                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded-full">
                    <ShieldCheck className="w-3.5 h-3.5" /> University Verified Partner
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold bg-amber-50 text-amber-700 border border-amber-200 px-2 py-0.5 rounded-full">
                    <AlertCircle className="w-3.5 h-3.5" /> Verification Pending
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Representative: {user?.recruiterProfile?.fullName} ({user?.recruiterProfile?.designation})
              </p>
            </div>
          </div>

          <Link
            to="/recruiter/jobs/create"
            className="px-4 py-2.5 rounded-lg bg-[#172554] hover:bg-blue-900 text-white font-semibold text-xs shadow-xs transition-colors flex items-center gap-2 shrink-0 self-start md:self-auto"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Post New Drive</span>
          </Link>
        </div>
      )}

      {/* Metrics Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Total Drives</span>
            <div className="p-2 rounded-lg bg-blue-50 text-blue-600">
              <Briefcase className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-2xl font-bold text-slate-900">{totalDrives}</div>
          <div className="mt-1 text-[11px] text-slate-400">{activeDrives} active & published</div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Total Applicants</span>
            <div className="p-2 rounded-lg bg-purple-50 text-purple-600">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-2xl font-bold text-purple-700">{totalApplicants}</div>
          <div className="mt-1 text-[11px] text-slate-400">Verified student submissions</div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Partner Status</span>
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600">
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-sm font-bold text-emerald-700">
            {company?.isVerified ? 'Accredited' : 'Reviewing'}
          </div>
          <div className="mt-1 text-[11px] text-slate-400">Institutional placement wing</div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Active Roles</span>
            <div className="p-2 rounded-lg bg-sky-50 text-sky-600">
              <Award className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-2xl font-bold text-slate-900">{activeDrives}</div>
          <div className="mt-1 text-[11px] text-slate-400">Open for applications</div>
        </div>
      </div>

      {/* Recruitment Drives Overview */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Your Recruitment Drives</h3>
            <p className="text-xs text-slate-500 mt-0.5">Manage positions and review verified candidate pipelines</p>
          </div>
          <Link
            to="/recruiter/jobs"
            className="text-xs font-semibold text-blue-600 hover:text-blue-800"
          >
            View all drives →
          </Link>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-3 px-4">Drive Title</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Package</th>
                <th className="py-3 px-4">Applicants</th>
                <th className="py-3 px-4">Min CGPA</th>
                <th className="py-3 px-4">Deadline</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {jobs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-8 text-xs text-slate-400">
                    No drives posted yet. Create your first drive to start accepting applications!
                  </td>
                </tr>
              ) : (
                jobs.map((job) => (
                  <tr key={job.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="py-3 px-4 font-semibold text-slate-900">{job.title}</td>
                    <td className="py-3 px-4">
                      <Badge variant={job.status === 'PUBLISHED' ? 'success' : 'warning'}>
                        {job.status}
                      </Badge>
                    </td>
                    <td className="py-3 px-4 font-medium text-slate-800">{job.salaryRange}</td>
                    <td className="py-3 px-4">
                      <span className="font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-100">
                        {job._count?.applications || 0} candidates
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-600">{job.minCgpa.toFixed(1)}</td>
                    <td className="py-3 px-4 text-slate-500">
                      {new Date(job.applicationDeadline).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <Link
                        to={`/recruiter/jobs/${job.id}/applicants`}
                        className="px-3 py-1 bg-[#172554] hover:bg-blue-900 text-white rounded text-xs font-semibold inline-block transition-colors"
                      >
                        Manage Applicants
                      </Link>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

