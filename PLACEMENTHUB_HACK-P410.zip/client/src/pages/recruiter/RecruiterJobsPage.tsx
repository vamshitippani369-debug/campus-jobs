import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Briefcase,
  PlusCircle,
  Users,
  MapPin,
  Calendar,
  Clock,
  ArrowRight,
  CheckCircle2,
} from 'lucide-react';
import { api } from '../../services/api';
import { Job } from '../../types';
import { Badge } from '../../components/common/Badge';

export const RecruiterJobsPage: React.FC = () => {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchJobs();
  }, []);

  const fetchJobs = async () => {
    try {
      const res = await api.get('/jobs');
      if (res.data.success) {
        setJobs(res.data.jobs);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Company Recruitment Drives
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Create, configure eligibility criteria, and manage candidate pipelines
          </p>
        </div>

        <Link
          to="/recruiter/jobs/create"
          className="px-4 py-2.5 rounded-lg bg-[#172554] hover:bg-blue-900 text-white font-semibold text-xs shadow-xs transition-colors flex items-center gap-2 self-start sm:self-auto"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Post New Drive</span>
        </Link>
      </div>

      {isLoading ? (
        <div className="h-64 flex items-center justify-center">
          <div className="w-7 h-7 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : jobs.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <Briefcase className="w-10 h-10 text-slate-300 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-slate-800">No recruitment drives posted yet</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            Get started by posting your first drive with tailored academic eligibility cutoffs.
          </p>
          <Link
            to="/recruiter/jobs/create"
            className="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-[#172554] hover:bg-blue-900 text-white rounded-lg text-xs font-semibold"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Create Drive</span>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {jobs.map((job) => (
            <div
              key={job.id}
              className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <Badge variant={job.status === 'PUBLISHED' ? 'success' : 'warning'}>
                    {job.status}
                  </Badge>

                  <span className="text-xs font-bold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-md border border-blue-100">
                    {job._count?.applications || 0} Applicants
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900">{job.title}</h3>

                <div className="flex flex-wrap items-center gap-3 mt-2 text-xs text-slate-600">
                  <span className="font-semibold text-slate-800">💰 {job.salaryRange}</span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" /> {job.location}
                  </span>
                  <span>•</span>
                  <span>{job.vacancies} vacancies</span>
                </div>

                <div className="mt-4 p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 space-y-1.5 text-xs">
                  <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                    Deterministic Eligibility Rules
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Min CGPA:</span>
                    <span className="font-semibold text-slate-800">{job.minCgpa.toFixed(1)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Max Active Backlogs:</span>
                    <span className="font-semibold text-slate-800">{job.maxActiveBacklogs}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Eligible Depts:</span>
                    <span className="font-semibold text-slate-800 truncate max-w-[200px]">
                      {job.eligibleDepartments.join(', ')}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Deadline:</span>
                    <span className="font-semibold text-rose-600">
                      {new Date(job.applicationDeadline).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between">
                <Link
                  to={`/recruiter/jobs/${job.id}/applicants`}
                  className="w-full py-2 px-3 rounded-lg bg-[#172554] hover:bg-blue-900 text-white text-xs font-semibold flex items-center justify-center gap-2 transition-colors shadow-xs"
                >
                  <Users className="w-3.5 h-3.5" />
                  <span>Manage Applicants & Pipeline ({job._count?.applications || 0})</span>
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

