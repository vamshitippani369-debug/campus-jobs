import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  ArrowLeft,
  Briefcase,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Plus,
  Save,
} from 'lucide-react';
import { api } from '../../services/api';

export const CreateJobPage: React.FC = () => {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    location: 'Bengaluru / Hybrid',
    employmentType: 'FULL_TIME',
    salaryRange: '12 - 16 LPA',
    minSalary: 12.0,
    maxSalary: 16.0,
    vacancies: 5,
    selectionProcess: 'Online Assessment -> Technical Interview -> HR Round',
    applicationDeadline: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    minCgpa: 7.0,
    maxActiveBacklogs: 0,
    eligibleDepartments: ['CSE', 'IT', 'ECE'],
    eligibleGraduationYears: [2025, 2026],
    requiredSkills: ['Node.js', 'React', 'SQL', 'TypeScript'],
  });

  const [newSkill, setNewSkill] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const availableDepts = ['CSE', 'IT', 'ECE', 'EEE', 'Mechanical Engineering', 'Civil Engineering', 'AI & DS'];
  const availableYears = [2025, 2026, 2027];

  const toggleDept = (dept: string) => {
    setFormData(prev => ({
      ...prev,
      eligibleDepartments: prev.eligibleDepartments.includes(dept)
        ? prev.eligibleDepartments.filter(d => d !== dept)
        : [...prev.eligibleDepartments, dept],
    }));
  };

  const toggleYear = (year: number) => {
    setFormData(prev => ({
      ...prev,
      eligibleGraduationYears: prev.eligibleGraduationYears.includes(year)
        ? prev.eligibleGraduationYears.filter(y => y !== year)
        : [...prev.eligibleGraduationYears, year],
    }));
  };

  const addSkill = () => {
    if (!newSkill.trim()) return;
    if (!formData.requiredSkills.includes(newSkill.trim())) {
      setFormData(prev => ({
        ...prev,
        requiredSkills: [...prev.requiredSkills, newSkill.trim()],
      }));
    }
    setNewSkill('');
  };

  const removeSkill = (skill: string) => {
    setFormData(prev => ({
      ...prev,
      requiredSkills: prev.requiredSkills.filter(s => s !== skill),
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsSubmitting(true);

    try {
      const res = await api.post('/jobs', formData);
      if (res.data.success) {
        navigate('/recruiter/jobs');
      }
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to publish recruitment drive');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <Link
        to="/recruiter/jobs"
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors"
      >
        <ArrowLeft className="w-3.5 h-3.5" />
        Back to Recruitment Drives
      </Link>

      <div className="bg-white rounded-2xl border border-slate-200 p-6 lg:p-8 shadow-xs">
        <div className="pb-6 border-b border-slate-100 mb-6">
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Post New Recruitment Drive
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Define role parameters and strict institutional eligibility rules for automated student pre-qualification
          </p>
        </div>

        {error && (
          <div className="mb-6 p-3 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-700 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Job Details */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
              Role Position Overview
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">Job Role Title</label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="e.g. Associate Software Development Engineer"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Employment Type</label>
                <select
                  value={formData.employmentType}
                  onChange={(e) => setFormData({ ...formData, employmentType: e.target.value as any })}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 bg-white"
                >
                  <option value="FULL_TIME">Full Time Employment</option>
                  <option value="INTERNSHIP">Internship</option>
                  <option value="INTERN_TO_FTE">Internship + PPO to Full Time</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Job Location</label>
                <input
                  type="text"
                  required
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  placeholder="e.g. Bengaluru / Hybrid"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Salary Range Display (CTC)</label>
                <input
                  type="text"
                  required
                  value={formData.salaryRange}
                  onChange={(e) => setFormData({ ...formData, salaryRange: e.target.value })}
                  placeholder="e.g. 14 - 18 LPA"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Number of Vacancies</label>
                <input
                  type="number"
                  min="1"
                  required
                  value={formData.vacancies}
                  onChange={(e) => setFormData({ ...formData, vacancies: Number(e.target.value) })}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Application Deadline</label>
                <input
                  type="date"
                  required
                  value={formData.applicationDeadline}
                  onChange={(e) => setFormData({ ...formData, applicationDeadline: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Selection Workflow Description</label>
                <input
                  type="text"
                  value={formData.selectionProcess}
                  onChange={(e) => setFormData({ ...formData, selectionProcess: e.target.value })}
                  placeholder="e.g. Resume Shortlisting -> OA -> Technical Round -> HR Round"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">Role Description & Requirements</label>
                <textarea
                  rows={4}
                  required
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Provide comprehensive responsibilities, team context, and technical expectations..."
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>
            </div>
          </div>

          {/* Intelligent Deterministic Eligibility Rules Builder */}
          <div className="pt-6 border-t border-slate-100">
            <div className="flex items-center gap-2 mb-3">
              <ShieldCheck className="w-4 h-4 text-blue-600" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                Institutional Eligibility Rules
              </h3>
            </div>
            <p className="text-xs text-slate-500 mb-4">
              The deterministic rule engine evaluates these fields against verified student profiles. Applications violating criteria are blocked automatically.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Minimum CGPA Cutoff</label>
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  max="10"
                  required
                  value={formData.minCgpa}
                  onChange={(e) => setFormData({ ...formData, minCgpa: Number(e.target.value) })}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
                <span className="text-[11px] text-slate-400">Students with CGPA below this cannot apply</span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Max Allowed Active Backlogs</label>
                <input
                  type="number"
                  min="0"
                  required
                  value={formData.maxActiveBacklogs}
                  onChange={(e) => setFormData({ ...formData, maxActiveBacklogs: Number(e.target.value) })}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
                <span className="text-[11px] text-slate-400">Set to 0 for strict zero-backlog policy</span>
              </div>

              {/* Eligible Departments Selection */}
              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-2">Eligible Academic Departments</label>
                <div className="flex flex-wrap gap-2">
                  {availableDepts.map((dept) => (
                    <button
                      type="button"
                      key={dept}
                      onClick={() => toggleDept(dept)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                        formData.eligibleDepartments.includes(dept)
                          ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                          : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                      }`}
                    >
                      {dept}
                    </button>
                  ))}
                </div>
              </div>

              {/* Eligible Batches */}
              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-2">Eligible Passing Batches</label>
                <div className="flex gap-2">
                  {availableYears.map((year) => (
                    <button
                      type="button"
                      key={year}
                      onClick={() => toggleYear(year)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                        formData.eligibleGraduationYears.includes(year)
                          ? 'bg-[#172554] text-white border-[#172554] shadow-xs'
                          : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                      }`}
                    >
                      {year} Passing Out
                    </button>
                  ))}
                </div>
              </div>

              {/* Required Skills tags */}
              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">Required Technical Skills</label>
                <div className="flex gap-2 mb-2">
                  <input
                    type="text"
                    value={newSkill}
                    onChange={(e) => setNewSkill(e.target.value)}
                    onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addSkill(); } }}
                    placeholder="Add required skill (e.g. React, Node.js, AWS)..."
                    className="flex-1 px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                  <button
                    type="button"
                    onClick={addSkill}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Skill</span>
                  </button>
                </div>

                <div className="flex flex-wrap gap-1.5">
                  {formData.requiredSkills.map((skill, index) => (
                    <span
                      key={index}
                      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium bg-slate-100 text-slate-700 border border-slate-200"
                    >
                      <span>{skill}</span>
                      <button
                        type="button"
                        onClick={() => removeSkill(skill)}
                        className="text-slate-400 hover:text-slate-700"
                      >
                        ✕
                      </button>
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-100 flex justify-end gap-3">
            <Link
              to="/recruiter/jobs"
              className="px-4 py-2 rounded-lg border border-slate-300 hover:bg-slate-50 text-xs font-semibold text-slate-700 transition-colors"
            >
              Cancel
            </Link>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2 rounded-lg bg-[#172554] hover:bg-blue-900 text-white text-xs font-semibold shadow-xs transition-colors disabled:opacity-50 flex items-center gap-2"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{isSubmitting ? 'Submitting Drive...' : 'Publish Recruitment Drive'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

