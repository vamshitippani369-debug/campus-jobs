import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Briefcase,
  FileText,
  Calendar,
  Award,
  ArrowRight,
  CheckCircle2,
  Clock,
  Video,
  MapPin,
  Sparkles,
} from 'lucide-react';
import { api } from '../../services/api';
import { Badge } from '../../components/common/Badge';

export const StudentDashboard: React.FC = () => {
  const [data, setData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchDashboard();
  }, []);

  const fetchDashboard = async () => {
    try {
      const res = await api.get('/student/dashboard');
      if (res.data.success) {
        setData(res.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="h-64 flex items-center justify-center">
        <div className="w-7 h-7 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const stats = data?.stats || {
    totalApplied: 0,
    shortlistedCount: 0,
    interviewCount: 0,
    selectedCount: 0,
    rejectedCount: 0,
    profileCompletion: 85,
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'SELECTED':
        return <Badge variant="success">Placed / Selected</Badge>;
      case 'SHORTLISTED':
        return <Badge variant="primary">Shortlisted</Badge>;
      case 'INTERVIEW_SCHEDULED':
        return <Badge variant="info">Interview Scheduled</Badge>;
      case 'REJECTED':
        return <Badge variant="danger">Not Selected</Badge>;
      case 'WITHDRAWN':
        return <Badge variant="slate">Withdrawn</Badge>;
      default:
        return <Badge variant="warning">Submitted</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner / Welcome */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xs">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-blue-50 text-blue-700 border border-blue-200 mb-2">
            <Sparkles className="w-3 h-3" /> Campus Placement Season 2025-26
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Student Placement Portal
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Discover opportunities, verify eligibility before applying, and track your interview rounds.
          </p>
        </div>

        {/* Profile Completion indicator */}
        <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80 min-w-[240px]">
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="font-semibold text-slate-700">Profile Completion</span>
            <span className="font-bold text-blue-700">{stats.profileCompletion}%</span>
          </div>
          <div className="w-full bg-slate-200 rounded-full h-2">
            <div
              className="bg-blue-600 h-2 rounded-full transition-all duration-500"
              style={{ width: `${stats.profileCompletion}%` }}
            />
          </div>
          <Link
            to="/profile"
            className="text-[11px] text-blue-600 hover:text-blue-800 font-medium mt-2 inline-block"
          >
            Update resume & skills →
          </Link>
        </div>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Applied Drives</span>
            <div className="p-2 rounded-lg bg-blue-50 text-blue-600">
              <FileText className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-2xl font-bold text-slate-900">{stats.totalApplied}</div>
          <div className="mt-1 text-[11px] text-slate-400">Total submitted applications</div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Shortlisted</span>
            <div className="p-2 rounded-lg bg-purple-50 text-purple-600">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-2xl font-bold text-purple-700">{stats.shortlistedCount}</div>
          <div className="mt-1 text-[11px] text-slate-400">Applications approved for review</div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Active Interviews</span>
            <div className="p-2 rounded-lg bg-sky-50 text-sky-600">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-2xl font-bold text-sky-700">{stats.interviewCount}</div>
          <div className="mt-1 text-[11px] text-slate-400">Scheduled rounds</div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Offers Extended</span>
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600">
              <Award className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-2xl font-bold text-emerald-700">{stats.selectedCount}</div>
          <div className="mt-1 text-[11px] text-emerald-600 font-medium">Official placements</div>
        </div>
      </div>

      {/* Upcoming Interviews Section */}
      {data?.upcomingInterviews && data.upcomingInterviews.length > 0 && (
        <div className="bg-gradient-to-r from-blue-900 to-[#172554] text-white rounded-2xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-blue-300" />
              <h3 className="text-sm font-bold tracking-tight">Upcoming Scheduled Interviews</h3>
            </div>
            <Link
              to="/interviews"
              className="text-xs text-blue-200 hover:text-white font-medium flex items-center gap-1"
            >
              Calendar view <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {data.upcomingInterviews.map((interview: any) => (
              <div
                key={interview.id}
                className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/15 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-blue-200">{interview.job?.company?.name}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-blue-500/30 text-blue-100 border border-blue-400/30">
                      {interview.round} Round
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-white mt-1">{interview.job?.title}</h4>
                  <div className="flex items-center gap-3 mt-2 text-xs text-slate-300">
                    <span>📅 {interview.scheduledDate}</span>
                    <span>⏰ {interview.scheduledTime}</span>
                  </div>
                </div>

                <div className="mt-3 pt-3 border-t border-white/10 flex items-center justify-between">
                  <span className="text-[11px] text-blue-200 flex items-center gap-1">
                    {interview.mode === 'ONLINE' ? <Video className="w-3.5 h-3.5" /> : <MapPin className="w-3.5 h-3.5" />}
                    {interview.mode}
                  </span>
                  {interview.meetingLink && (
                    <a
                      href={interview.meetingLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-2.5 py-1 rounded bg-white text-slate-900 text-xs font-semibold hover:bg-slate-100 transition-colors"
                    >
                      Join Meeting
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recent Applications Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Recent Applications</h3>
            <p className="text-xs text-slate-500 mt-0.5">Track real-time candidate progression</p>
          </div>
          <Link
            to="/opportunities"
            className="px-3 py-1.5 rounded-lg bg-[#172554] hover:bg-blue-900 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Briefcase className="w-3.5 h-3.5" />
            <span>Browse Opportunities</span>
          </Link>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-3 px-4">Company</th>
                <th className="py-3 px-4">Role Position</th>
                <th className="py-3 px-4">Salary Package</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Applied On</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {(!data?.recentApplications || data.recentApplications.length === 0) ? (
                <tr>
                  <td colSpan={6} className="text-center py-8 text-xs text-slate-400">
                    No applications submitted yet. Browse open drives to apply!
                  </td>
                </tr>
              ) : (
                data.recentApplications.map((app: any) => (
                  <tr key={app.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="py-3 px-4 font-semibold text-slate-900">
                      {app.job?.company?.name}
                    </td>
                    <td className="py-3 px-4 text-slate-700">{app.job?.title}</td>
                    <td className="py-3 px-4 font-medium text-slate-800">{app.job?.salaryRange}</td>
                    <td className="py-3 px-4">{getStatusBadge(app.status)}</td>
                    <td className="py-3 px-4 text-slate-500">
                      {new Date(app.createdAt).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <Link
                        to={`/opportunities/${app.jobId}`}
                        className="text-xs font-semibold text-blue-600 hover:text-blue-800"
                      >
                        View Drive →
                      </Link>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

