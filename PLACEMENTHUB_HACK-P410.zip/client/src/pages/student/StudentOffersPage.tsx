import React, { useState, useEffect } from 'react';
import {
  Award,
  Building2,
  MapPin,
  Calendar,
  CheckCircle2,
  XCircle,
  Sparkles,
} from 'lucide-react';
import { api } from '../../services/api';
import { Offer } from '../../types';
import { Badge } from '../../components/common/Badge';

export const StudentOffersPage: React.FC = () => {
  const [offers, setOffers] = useState<Offer[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchOffers();
  }, []);

  const fetchOffers = async () => {
    try {
      const res = await api.get('/offers/my');
      if (res.data.success) {
        setOffers(res.data.offers);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateStatus = async (offerId: string, status: 'ACCEPTED' | 'DECLINED') => {
    try {
      const res = await api.patch(`/offers/${offerId}/status`, { status });
      if (res.data.success) {
        setOffers(prev =>
          prev.map(o => (o.id === offerId ? { ...o, status } : o))
        );
      }
    } catch (err: any) {
      alert(err.response?.data?.message || 'Failed to update offer status');
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
          Offers & Placement Selections
        </h1>
        <p className="text-xs text-slate-500 mt-0.5">
          Official letters of intent and job offers extended by partner recruiters
        </p>
      </div>

      {isLoading ? (
        <div className="h-64 flex items-center justify-center">
          <div className="w-7 h-7 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : offers.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <Award className="w-10 h-10 text-slate-300 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-slate-800">No placement offers yet</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            Once you clear final rounds with a recruiter, official employment offers will be issued directly to your portal.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {offers.map((offer) => (
            <div
              key={offer.id}
              className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-3 mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-blue-50 border border-blue-200 text-blue-700 flex items-center justify-center font-bold text-lg">
                      {offer.company?.name.charAt(0) || 'C'}
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-slate-900">{offer.company?.name}</h3>
                      <p className="text-xs text-slate-500">{offer.designation}</p>
                    </div>
                  </div>

                  <Badge
                    variant={
                      offer.status === 'ACCEPTED'
                        ? 'success'
                        : offer.status === 'DECLINED'
                        ? 'danger'
                        : 'primary'
                    }
                  >
                    {offer.status}
                  </Badge>
                </div>

                {/* Compensation Banner */}
                <div className="p-4 bg-gradient-to-r from-emerald-500/10 to-teal-500/10 border border-emerald-200 rounded-xl mb-4">
                  <div className="text-[11px] font-bold uppercase tracking-wider text-emerald-800">
                    Annual Compensation (CTC)
                  </div>
                  <div className="text-2xl font-black text-emerald-700 mt-0.5">
                    {offer.ctc}
                  </div>
                </div>

                <div className="space-y-2 text-xs text-slate-600">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Location:</span>
                    <span className="font-semibold text-slate-800">{offer.location}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Tentative Joining Date:</span>
                    <span className="font-semibold text-slate-800">{offer.joiningDate || 'TBD'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Offer Issued On:</span>
                    <span className="text-slate-600">{new Date(offer.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>

              {/* Accept / Decline actions */}
              {offer.status === 'OFFERED' ? (
                <div className="mt-6 pt-4 border-t border-slate-100 flex items-center gap-3">
                  <button
                    onClick={() => handleUpdateStatus(offer.id, 'ACCEPTED')}
                    className="flex-1 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs shadow-xs transition-colors flex items-center justify-center gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Accept Offer</span>
                  </button>

                  <button
                    onClick={() => handleUpdateStatus(offer.id, 'DECLINED')}
                    className="py-2 px-4 rounded-lg bg-slate-100 hover:bg-rose-50 hover:text-rose-700 text-slate-700 font-semibold text-xs transition-colors"
                  >
                    Decline
                  </button>
                </div>
              ) : (
                <div className="mt-6 pt-4 border-t border-slate-100 text-center text-xs font-semibold text-slate-600">
                  Offer {offer.status.toLowerCase()} by student
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

