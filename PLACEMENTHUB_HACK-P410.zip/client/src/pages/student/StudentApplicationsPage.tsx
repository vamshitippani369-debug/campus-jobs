import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  FileText,
  Clock,
  CheckCircle2,
  XCircle,
  Calendar,
  Award,
  AlertCircle,
  ExternalLink,
} from 'lucide-react';
import { api } from '../../services/api';
import { Application } from '../../types';
import { Badge } from '../../components/common/Badge';

export const StudentApplicationsPage: React.FC = () => {
  const [applications, setApplications] = useState<Application[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedApp, setSelectedApp] = useState<Application | null>(null);

  useEffect(() => {
    fetchApplications();
  }, []);

  const fetchApplications = async () => {
    try {
      const res = await api.get('/applications/my');
      if (res.data.success) {
        setApplications(res.data.applications);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleWithdraw = async (id: string) => {
    if (!confirm('Are you sure you want to withdraw this application? This action cannot be reversed.')) {
      return;
    }

    try {
      const res = await api.patch(`/applications/${id}/withdraw`);
      if (res.data.success) {
        setApplications(prev =>
          prev.map(a => (a.id === id ? { ...a, status: 'WITHDRAWN' } : a))
        );
      }
    } catch (err: any) {
      alert(err.response?.data?.message || 'Failed to withdraw application');
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'SELECTED':
        return <Badge variant="success">Placed / Selected</Badge>;
      case 'SHORTLISTED':
        return <Badge variant="primary">Shortlisted</Badge>;
      case 'INTERVIEW_SCHEDULED':
        return <Badge variant="info">Interview Scheduled</Badge>;
      case 'REJECTED':
        return <Badge variant="danger">Not Selected</Badge>;
      case 'WITHDRAWN':
        return <Badge variant="slate">Withdrawn</Badge>;
      default:
        return <Badge variant="warning">Submitted</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
          My Applications
        </h1>
        <p className="text-xs text-slate-500 mt-0.5">
          Track real-time selection workflow stages across all submitted campus recruitment drives
        </p>
      </div>

      {isLoading ? (
        <div className="h-64 flex items-center justify-center">
          <div className="w-7 h-7 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : applications.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <FileText className="w-10 h-10 text-slate-300 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-slate-800">No applications submitted yet</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            You haven't applied to any drives yet. Check open opportunities to find matching roles!
          </p>
          <Link
            to="/opportunities"
            className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 bg-[#172554] hover:bg-blue-900 text-white rounded-lg text-xs font-semibold"
          >
            Browse Opportunities
          </Link>
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold">
                  <th className="py-3 px-4">Company</th>
                  <th className="py-3 px-4">Role Title</th>
                  <th className="py-3 px-4">Package</th>
                  <th className="py-3 px-4">Current Stage</th>
                  <th className="py-3 px-4">Interviews</th>
                  <th className="py-3 px-4">Applied Date</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {applications.map((app) => (
                  <tr key={app.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="py-3.5 px-4 font-semibold text-slate-900">
                      {app.job.company.name}
                    </td>
                    <td className="py-3.5 px-4 text-slate-700">{app.job.title}</td>
                    <td className="py-3.5 px-4 font-medium text-slate-800">{app.job.salaryRange}</td>
                    <td className="py-3.5 px-4">{getStatusBadge(app.status)}</td>
                    <td className="py-3.5 px-4 text-slate-600">
                      {app.interviews && app.interviews.length > 0 ? (
                        <Link
                          to="/interviews"
                          className="inline-flex items-center gap-1 text-blue-600 hover:underline font-medium"
                        >
                          <Calendar className="w-3.5 h-3.5" />
                          <span>{app.interviews.length} Round(s)</span>
                        </Link>
                      ) : (
                        <span className="text-slate-400">None scheduled</span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-slate-500">
                      {new Date(app.createdAt).toLocaleDateString()}
                    </td>
                    <td className="py-3.5 px-4 text-right space-x-2">
                      <button
                        onClick={() => setSelectedApp(app)}
                        className="text-xs font-semibold text-blue-600 hover:text-blue-800"
                      >
                        Audit Details
                      </button>

                      {['SUBMITTED', 'SHORTLISTED'].includes(app.status) && (
                        <button
                          onClick={() => handleWithdraw(app.id)}
                          className="text-xs font-medium text-rose-600 hover:text-rose-800"
                        >
                          Withdraw
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Audit & Report Modal */}
      {selectedApp && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Application Audit Snapshot</h3>
                <p className="text-xs text-slate-500">{selectedApp.job.title} • {selectedApp.job.company.name}</p>
              </div>
              <button
                onClick={() => setSelectedApp(null)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-lg space-y-1.5 border border-slate-200">
                <div className="flex justify-between">
                  <span className="text-slate-500">Status:</span>
                  <span className="font-bold text-slate-800">{selectedApp.status}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Application ID:</span>
                  <span className="font-mono text-[11px] text-slate-700">{selectedApp.id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Applied Timestamp:</span>
                  <span className="text-slate-700">{new Date(selectedApp.createdAt).toLocaleString()}</span>
                </div>
              </div>

              {selectedApp.eligibilityReport && (
                <div>
                  <h4 className="font-bold text-slate-800 mb-2">Verified Eligibility Criteria</h4>
                  <div className="space-y-1.5">
                    {selectedApp.eligibilityReport.criteriaBreakdown?.map((c: any, i: number) => (
                      <div key={i} className="flex items-center gap-2 p-2 bg-slate-50 rounded border border-slate-100">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span className="text-slate-700">{c.message}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <button
              onClick={() => setSelectedApp(null)}
              className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs rounded-lg transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

