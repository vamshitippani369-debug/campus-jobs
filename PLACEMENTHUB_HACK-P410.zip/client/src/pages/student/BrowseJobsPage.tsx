import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Building2,
  MapPin,
  Calendar,
  Sparkles,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';
import { api } from '../../services/api';
import { Job } from '../../types';
import { Badge } from '../../components/common/Badge';

export const BrowseJobsPage: React.FC = () => {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Filters
  const [search, setSearch] = useState('');
  const [department, setDepartment] = useState('');
  const [minSalary, setMinSalary] = useState('');
  const [eligibleOnly, setEligibleOnly] = useState(false);

  useEffect(() => {
    fetchJobs();
  }, [department, minSalary, eligibleOnly]);

  const fetchJobs = async () => {
    setIsLoading(true);
    try {
      const params: any = {};
      if (department) params.department = department;
      if (minSalary) params.minSalary = minSalary;
      if (eligibleOnly) params.eligibleOnly = 'true';
      if (search) params.search = search;

      const res = await api.get('/jobs', { params });
      if (res.data.success) {
        setJobs(res.data.jobs);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchJobs();
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Browse Recruitment Drives
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Discover approved company opportunities with live eligibility calculation
          </p>
        </div>

        {/* Eligibility quick count */}
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-800">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span>
            <strong>{jobs.filter((j) => j.eligibility?.isEligible).length}</strong> of {jobs.length} drives eligible for you
          </span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3">
        <form onSubmit={handleSearchSubmit} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by company name, job title, skills..."
              className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
          </div>
          <button
            type="submit"
            className="px-4 py-2 bg-[#172554] hover:bg-blue-900 text-white rounded-lg text-xs font-semibold transition-colors"
          >
            Search
          </button>
        </form>

        <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-slate-100 text-xs">
          <div className="flex items-center gap-1.5 text-slate-500">
            <Filter className="w-3.5 h-3.5" />
            <span className="font-medium">Filters:</span>
          </div>

          <label className="flex items-center gap-1.5 text-xs text-slate-700 cursor-pointer font-medium bg-slate-50 px-2.5 py-1 rounded-md border border-slate-200">
            <input
              type="checkbox"
              checked={eligibleOnly}
              onChange={(e) => setEligibleOnly(e.target.checked)}
              className="rounded text-blue-600 focus:ring-0"
            />
            <span>Show Eligible Only</span>
          </label>

          <select
            value={minSalary}
            onChange={(e) => setMinSalary(e.target.value)}
            className="px-2.5 py-1 text-xs border border-slate-200 rounded-md bg-white focus:outline-none"
          >
            <option value="">All CTC Ranges</option>
            <option value="6">Min 6 LPA</option>
            <option value="10">Min 10 LPA</option>
            <option value="15">Min 15 LPA</option>
          </select>
        </div>
      </div>

      {/* Drives Grid */}
      {isLoading ? (
        <div className="h-64 flex items-center justify-center">
          <div className="w-7 h-7 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : jobs.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <Building2 className="w-10 h-10 text-slate-300 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-slate-800">No recruitment drives found</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            Try adjusting your search criteria or clearing filters to discover opportunities.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {jobs.map((job) => {
            const isEligible = job.eligibility?.isEligible;
            const skillMatch = job.eligibility?.skillMatch?.matchPercentage || 0;

            return (
              <div
                key={job.id}
                className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between hover:border-slate-300 hover:shadow-sm transition-all"
              >
                <div>
                  {/* Top Bar: Company & Status */}
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-10 h-10 rounded-lg bg-slate-100 border border-slate-200 flex items-center justify-center font-bold text-sm text-slate-700 overflow-hidden">
                        {job.company.logo ? (
                          <img src={job.company.logo} alt={job.company.name} className="w-full h-full object-cover" />
                        ) : (
                          job.company.name.charAt(0)
                        )}
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-900 line-clamp-1">{job.company.name}</div>
                        <div className="text-[11px] text-slate-500 line-clamp-1">{job.company.industry}</div>
                      </div>
                    </div>

                    {job.hasApplied ? (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200">
                        APPLIED
                      </span>
                    ) : isEligible ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                        ELIGIBLE
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200">
                        <XCircle className="w-3 h-3 text-rose-600" />
                        INELIGIBLE
                      </span>
                    )}
                  </div>

                  {/* Title & CTC */}
                  <h3 className="text-sm font-bold text-slate-900 line-clamp-2 leading-snug">
                    {job.title}
                  </h3>

                  <div className="mt-2.5 flex flex-wrap items-center gap-2 text-xs">
                    <span className="font-bold text-blue-700 bg-blue-50/80 px-2 py-0.5 rounded border border-blue-100">
                      💰 {job.salaryRange}
                    </span>
                    <span className="text-slate-500 flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5" />
                      {job.location}
                    </span>
                  </div>

                  {/* Criteria Checklist Preview */}
                  <div className="mt-3.5 pt-3 border-t border-slate-100 space-y-1 text-[11px] text-slate-600">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Min CGPA:</span>
                      <span className="font-semibold text-slate-800">{job.minCgpa.toFixed(1)}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Max Backlogs:</span>
                      <span className="font-semibold text-slate-800">{job.maxActiveBacklogs}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Depts:</span>
                      <span className="font-semibold text-slate-800 truncate max-w-[140px]">
                        {job.eligibleDepartments.join(', ')}
                      </span>
                    </div>
                  </div>

                  {/* Skill Match Indicator */}
                  {job.eligibility && (
                    <div className="mt-3 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                      <div className="flex items-center justify-between text-[11px] mb-1">
                        <span className="text-slate-600 font-medium">Skill Alignment</span>
                        <span className="font-bold text-slate-800">{skillMatch}%</span>
                      </div>
                      <div className="w-full bg-slate-200 rounded-full h-1.5">
                        <div
                          className={`h-1.5 rounded-full ${
                            skillMatch >= 70 ? 'bg-emerald-500' : skillMatch >= 40 ? 'bg-blue-500' : 'bg-amber-500'
                          }`}
                          style={{ width: `${skillMatch}%` }}
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* Footer Action */}
                <div className="mt-4 pt-3 border-t border-slate-100">
                  <Link
                    to={`/opportunities/${job.id}`}
                    className="w-full py-2 px-3 rounded-lg bg-slate-50 hover:bg-blue-50 hover:text-blue-700 border border-slate-200 text-xs font-semibold text-slate-800 flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <span>Inspect Eligibility & Details</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Link>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

