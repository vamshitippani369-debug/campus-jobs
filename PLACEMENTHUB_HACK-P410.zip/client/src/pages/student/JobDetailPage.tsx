import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  Building2,
  MapPin,
  Calendar,
  Clock,
  Users,
  CheckCircle2,
  XCircle,
  AlertCircle,
  FileText,
  Send,
  ExternalLink,
} from 'lucide-react';
import { api } from '../../services/api';
import { Job, EligibilityReport } from '../../types';
import { EligibilityReportCard } from '../../components/common/EligibilityReportCard';

export const JobDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [job, setJob] = useState<Job | null>(null);
  const [eligibility, setEligibility] = useState<EligibilityReport | null>(null);
  const [application, setApplication] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Application submission state
  const [notes, setNotes] = useState('');
  const [isApplying, setIsApplying] = useState(false);
  const [applyError, setApplyError] = useState<string | null>(null);
  const [applySuccess, setApplySuccess] = useState(false);

  useEffect(() => {
    fetchJobDetails();
  }, [id]);

  const fetchJobDetails = async () => {
    try {
      const res = await api.get(`/jobs/${id}`);
      if (res.data.success) {
        setJob(res.data.job);
        setEligibility(res.data.eligibility);
        setApplication(res.data.application);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleApply = async () => {
    setApplyError(null);
    setIsApplying(true);

    try {
      const res = await api.post('/applications', {
        jobId: id,
        notes,
      });

      if (res.data.success) {
        setApplySuccess(true);
        setApplication(res.data.application);
      }
    } catch (err: any) {
      setApplyError(err.response?.data?.message || 'Failed to submit application');
    } finally {
      setIsApplying(false);
    }
  };

  if (isLoading) {
    return (
      <div className="h-64 flex items-center justify-center">
        <div className="w-7 h-7 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!job) {
    return (
      <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
        <AlertCircle className="w-8 h-8 text-rose-500 mx-auto mb-2" />
        <h3 className="text-sm font-bold text-slate-800">Recruitment drive not found</h3>
        <Link to="/opportunities" className="text-xs text-blue-600 hover:underline mt-2 inline-block">
          ← Back to all opportunities
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Back button */}
      <Link
        to="/opportunities"
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors"
      >
        <ArrowLeft className="w-3.5 h-3.5" />
        Back to Opportunities
      </Link>

      {/* Main Header Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 lg:p-8 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-6 pb-6 border-b border-slate-100">
          <div className="flex items-start gap-4">
            <div className="w-14 h-14 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center font-bold text-xl text-slate-700 overflow-hidden shrink-0">
              {job.company.logo ? (
                <img src={job.company.logo} alt={job.company.name} className="w-full h-full object-cover" />
              ) : (
                job.company.name.charAt(0)
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-blue-600">{job.company.name}</span>
                {job.company.isVerified && (
                  <span className="text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-200 px-1.5 py-0.5 rounded font-semibold">
                    Verified Partner
                  </span>
                )}
              </div>
              <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">{job.title}</h1>
              <div className="flex flex-wrap items-center gap-3 mt-2 text-xs text-slate-500">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5" /> {job.location}
                </span>
                <span>•</span>
                <span className="font-semibold text-slate-700">💰 {job.salaryRange}</span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Users className="w-3.5 h-3.5" /> {job.vacancies} Vacancies
                </span>
              </div>
            </div>
          </div>

          <div className="text-right">
            <div className="text-xs text-slate-400">Application Deadline</div>
            <div className="text-xs font-bold text-rose-600 mt-0.5">
              📅 {new Date(job.applicationDeadline).toLocaleDateString()}
            </div>
          </div>
        </div>

        {/* Action Bar / Status */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            {application ? (
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-slate-700">Your Application Status:</span>
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-blue-100 text-blue-800 border border-blue-200">
                  {application.status}
                </span>
              </div>
            ) : eligibility?.isEligible ? (
              <div className="flex items-center gap-2 text-xs text-emerald-800 font-semibold">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                You are verified eligible to apply for this campus drive.
              </div>
            ) : (
              <div className="flex items-center gap-2 text-xs text-rose-700 font-semibold">
                <XCircle className="w-4 h-4 text-rose-600" />
                You do not meet the minimum eligibility requirements.
              </div>
            )}
          </div>

          {!application && eligibility?.canApply && (
            <button
              onClick={() => {
                const el = document.getElementById('apply-section');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              className="px-5 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-xs transition-colors flex items-center gap-2"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Apply for Drive</span>
            </button>
          )}
        </div>
      </div>

      {/* Intelligent Eligibility Checker Showcase Card */}
      <div>
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
          Eligibility Verification Report
        </h3>
        <EligibilityReportCard report={eligibility} />
      </div>

      {/* Job Description & Requirements */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 mb-3">Role Overview & Responsibilities</h3>
            <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-line">
              {job.description}
            </p>

            {job.selectionProcess && (
              <div className="mt-6 pt-5 border-t border-slate-100">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                  Selection Workflow
                </h4>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs font-medium text-slate-700">
                  {job.selectionProcess}
                </div>
              </div>
            )}
          </div>

          {/* Interactive Apply Form Section */}
          {!application && eligibility?.canApply && (
            <div id="apply-section" className="bg-white rounded-xl border border-blue-200 p-6 shadow-sm">
              <h3 className="text-sm font-bold text-slate-900 mb-1">Submit Application</h3>
              <p className="text-xs text-slate-500 mb-4">
                Your uploaded resume and academic records will be verified and forwarded to the recruiter.
              </p>

              {applyError && (
                <div className="mb-4 p-3 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-700">
                  {applyError}
                </div>
              )}

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Optional Candidate Statement or Pitch
                  </label>
                  <textarea
                    rows={3}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Briefly state your relevant project experience or enthusiasm for this role..."
                    className="w-full p-2.5 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>

                <button
                  onClick={handleApply}
                  disabled={isApplying}
                  className="w-full py-2.5 px-4 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-xs transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isApplying ? 'Verifying & Submitting...' : 'Confirm & Submit Application'}</span>
                </button>
              </div>
            </div>
          )}

          {applySuccess && (
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <div>
                <span className="font-bold">Application Received! </span>
                Your application has been logged in the university database. You can track updates in your Applications dashboard.
              </div>
            </div>
          )}
        </div>

        {/* Sidebar: Company & Criteria Overview */}
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Company Snapshot
            </h3>
            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Industry:</span>
                <span className="font-semibold text-slate-800">{job.company.industry}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">HQ:</span>
                <span className="font-semibold text-slate-800">{job.company.headquarters}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Company Size:</span>
                <span className="font-semibold text-slate-800">{job.company.companySize}</span>
              </div>
              {job.company.website && (
                <div className="pt-2">
                  <a
                    href={job.company.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-blue-600 hover:underline flex items-center gap-1 font-medium"
                  >
                    <span>Visit corporate website</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

