import React, { useState, useEffect } from 'react';
import {
  Calendar as CalendarIcon,
  Clock,
  Video,
  MapPin,
  CheckCircle2,
  AlertCircle,
  FileText,
  ExternalLink,
} from 'lucide-react';
import { api } from '../../services/api';
import { Interview } from '../../types';
import { Badge } from '../../components/common/Badge';

export const StudentInterviewsPage: React.FC = () => {
  const [interviews, setInterviews] = useState<Interview[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchInterviews();
  }, []);

  const fetchInterviews = async () => {
    try {
      const res = await api.get('/interviews/my');
      if (res.data.success) {
        setInterviews(res.data.interviews);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
          Interview Calendar
        </h1>
        <p className="text-xs text-slate-500 mt-0.5">
          View your scheduled recruitment assessments, technical rounds, and meeting details
        </p>
      </div>

      {isLoading ? (
        <div className="h-64 flex items-center justify-center">
          <div className="w-7 h-7 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : interviews.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <CalendarIcon className="w-10 h-10 text-slate-300 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-slate-800">No interviews scheduled yet</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            When recruiters shortlist your application and schedule an interview round, it will appear here with calendar reminders and video links.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {interviews.map((item) => (
            <div
              key={item.id}
              className={`bg-white rounded-xl border p-5 shadow-xs flex flex-col justify-between ${
                item.status === 'SCHEDULED' ? 'border-blue-200 bg-blue-50/20' : 'border-slate-200'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-blue-600">
                    {item.job?.company?.name}
                  </span>
                  <Badge variant={item.status === 'SCHEDULED' ? 'info' : 'slate'}>
                    {item.status}
                  </Badge>
                </div>

                <h3 className="text-sm font-bold text-slate-900">{item.job?.title}</h3>
                <div className="text-xs font-semibold text-slate-700 mt-0.5">
                  Round: {item.round}
                </div>

                <div className="mt-4 p-3 bg-white rounded-lg border border-slate-200 space-y-2 text-xs">
                  <div className="flex items-center gap-2 text-slate-700">
                    <CalendarIcon className="w-4 h-4 text-slate-400 shrink-0" />
                    <span className="font-semibold">{item.scheduledDate}</span>
                    <span className="text-slate-400">•</span>
                    <Clock className="w-4 h-4 text-slate-400 shrink-0" />
                    <span className="font-semibold">{item.scheduledTime}</span>
                    <span className="text-slate-500">({item.durationMinutes} mins)</span>
                  </div>

                  <div className="flex items-center gap-2 text-slate-600">
                    {item.mode === 'ONLINE' ? (
                      <Video className="w-4 h-4 text-blue-600 shrink-0" />
                    ) : (
                      <MapPin className="w-4 h-4 text-amber-600 shrink-0" />
                    )}
                    <span>
                      <strong>Mode: </strong> {item.mode}
                      {item.venue ? ` • Venue: ${item.venue}` : ''}
                    </span>
                  </div>
                </div>

                {item.instructions && (
                  <div className="mt-3 p-3 bg-slate-50 rounded-lg text-xs text-slate-600 border border-slate-200/80">
                    <span className="font-semibold text-slate-800">Recruiter Instructions: </span>
                    {item.instructions}
                  </div>
                )}

                {item.feedback && (
                  <div className="mt-3 p-3 bg-emerald-50 rounded-lg text-xs text-emerald-800 border border-emerald-200">
                    <span className="font-semibold">Interviewer Feedback: </span>
                    {item.feedback}
                  </div>
                )}
              </div>

              {item.meetingLink && item.status === 'SCHEDULED' && (
                <div className="mt-4 pt-3 border-t border-slate-100">
                  <a
                    href={item.meetingLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2 px-3 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs flex items-center justify-center gap-2 transition-colors shadow-xs"
                  >
                    <Video className="w-3.5 h-3.5" />
                    <span>Join Online Interview</span>
                    <ExternalLink className="w-3 h-3 ml-1" />
                  </a>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

