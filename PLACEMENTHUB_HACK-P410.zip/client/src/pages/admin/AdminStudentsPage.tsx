import React, { useState, useEffect } from 'react';
import { Users, Search, Filter, ShieldCheck, Award, FileText } from 'lucide-react';
import { api } from '../../services/api';
import { StudentProfile } from '../../types';

export const AdminStudentsPage: React.FC = () => {
  const [students, setStudents] = useState<StudentProfile[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Filters
  const [search, setSearch] = useState('');
  const [deptFilter, setDeptFilter] = useState('');
  const [minCgpa, setMinCgpa] = useState('');

  useEffect(() => {
    fetchStudents();
  }, [deptFilter, minCgpa]);

  const fetchStudents = async () => {
    setIsLoading(true);
    try {
      const params: any = {};
      if (deptFilter) params.department = deptFilter;
      if (minCgpa) params.minCgpa = minCgpa;
      if (search) params.search = search;

      const res = await api.get('/admin/students', { params });
      if (res.data.success) {
        setStudents(res.data.students);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchStudents();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Student Placement Registry
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Verified university academic records, CGPA cutoffs, and individual placement outcomes
          </p>
        </div>

        <span className="px-3 py-1.5 rounded-lg bg-blue-50 border border-blue-200 text-xs font-bold text-blue-800 self-start sm:self-auto">
          {students.length} Registered Students
        </span>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3">
        <form onSubmit={handleSearchSubmit} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by student name, roll number, or email..."
              className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
          </div>
          <button
            type="submit"
            className="px-4 py-2 bg-[#172554] hover:bg-blue-900 text-white rounded-lg text-xs font-semibold"
          >
            Search
          </button>
        </form>

        <div className="flex flex-wrap items-center gap-3 text-xs pt-2 border-t border-slate-100">
          <div className="flex items-center gap-1.5 text-slate-500">
            <Filter className="w-3.5 h-3.5" />
            <span>Filter:</span>
          </div>

          <select
            value={deptFilter}
            onChange={(e) => setDeptFilter(e.target.value)}
            className="px-2.5 py-1 text-xs border border-slate-200 rounded-md bg-white focus:outline-none"
          >
            <option value="">All Departments</option>
            <option value="CSE">CSE</option>
            <option value="IT">IT</option>
            <option value="ECE">ECE</option>
            <option value="EEE">EEE</option>
            <option value="Mechanical">Mechanical</option>
          </select>

          <select
            value={minCgpa}
            onChange={(e) => setMinCgpa(e.target.value)}
            className="px-2.5 py-1 text-xs border border-slate-200 rounded-md bg-white focus:outline-none"
          >
            <option value="">All CGPAs</option>
            <option value="7.0">CGPA ≥ 7.0</option>
            <option value="8.0">CGPA ≥ 8.0</option>
            <option value="8.5">CGPA ≥ 8.5</option>
          </select>
        </div>
      </div>

      {/* Students Table */}
      {isLoading ? (
        <div className="h-64 flex items-center justify-center">
          <div className="w-7 h-7 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold">
                  <th className="py-3 px-4">Student Name</th>
                  <th className="py-3 px-4">Roll Number</th>
                  <th className="py-3 px-4">Department</th>
                  <th className="py-3 px-4">Class</th>
                  <th className="py-3 px-4">CGPA</th>
                  <th className="py-3 px-4">Active Backlogs</th>
                  <th className="py-3 px-4">Applications</th>
                  <th className="py-3 px-4 text-right">Placement Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {students.map((student: any) => {
                  const hasOffers = student._count?.offers > 0;
                  return (
                    <tr key={student.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900">{student.fullName}</div>
                        <div className="text-[11px] text-slate-500">{student.collegeEmail}</div>
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-700">{student.studentId}</td>
                      <td className="py-3 px-4 text-slate-700 font-medium">{student.department}</td>
                      <td className="py-3 px-4 text-slate-500">{student.graduationYear}</td>
                      <td className="py-3 px-4 font-bold text-slate-900">{student.cgpa.toFixed(2)}</td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                          student.activeBacklogs === 0 ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
                        }`}>
                          {student.activeBacklogs} Backlogs
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-600 font-medium">
                        {student._count?.applications || 0} applied
                      </td>
                      <td className="py-3 px-4 text-right">
                        {hasOffers ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                            <Award className="w-3 h-3 text-emerald-600" />
                            Placed ({student._count.offers})
                          </span>
                        ) : (
                          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-slate-100 text-slate-600">
                            In Pipeline
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

