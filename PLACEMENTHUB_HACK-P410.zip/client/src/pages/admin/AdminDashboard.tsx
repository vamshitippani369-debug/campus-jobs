import React, { useState, useEffect } from 'react';
import {
  Users,
  Building2,
  Briefcase,
  Award,
  Download,
  TrendingUp,
  BarChart3,
  PieChart as PieChartIcon,
  Sparkles,
  FileSpreadsheet,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { api } from '../../services/api';

export const AdminDashboard: React.FC = () => {
  const [data, setData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const res = await api.get('/admin/stats');
      if (res.data.success) {
        setData(res.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleExportCSV = async (type: string) => {
    try {
      const res = await api.get(`/admin/export/${type}`, {
        responseType: 'blob',
      });
      const url = window.URL.createObjectURL(new Blob([res.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `${type}_report_${Date.now()}.csv`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (err) {
      alert('Failed to download CSV report');
    }
  };

  if (isLoading) {
    return (
      <div className="h-64 flex items-center justify-center">
        <div className="w-7 h-7 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const metrics = data?.metrics || {};
  const departmentStats = data?.departmentStats || [];
  const statusDistribution = data?.statusDistribution || [];
  const companyStats = data?.companyStats || [];

  const COLORS = ['#2563EB', '#16A34A', '#D97706', '#9333EA', '#DC2626', '#64748B'];

  return (
    <div className="space-y-6">
      {/* Top Banner & CSV Export Actions */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-purple-50 text-purple-700 border border-purple-200 mb-1.5">
            <Sparkles className="w-3 h-3" /> University Placement Cell Intelligence
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Institutional Placement Analytics
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Metrics aggregated dynamically from verified student records and corporate recruitment drives
          </p>
        </div>

        {/* CSV Export Dropdown / Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => handleExportCSV('students')}
            className="px-3 py-2 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-300 text-xs font-semibold text-slate-700 flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <Download className="w-3.5 h-3.5 text-blue-600" />
            <span>Students CSV</span>
          </button>

          <button
            onClick={() => handleExportCSV('applications')}
            className="px-3 py-2 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-300 text-xs font-semibold text-slate-700 flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <Download className="w-3.5 h-3.5 text-purple-600" />
            <span>Applications CSV</span>
          </button>

          <button
            onClick={() => handleExportCSV('offers')}
            className="px-3 py-2 rounded-lg bg-[#172554] hover:bg-blue-900 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export Placement Report</span>
          </button>
        </div>
      </div>

      {/* Primary KPI Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-semibold">
            <span>Overall Placement</span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-2 text-3xl font-extrabold text-emerald-600">
            {metrics.overallPlacementRate}%
          </div>
          <div className="mt-1 text-[11px] text-slate-500 font-medium">
            <strong>{metrics.totalPlacedStudents}</strong> students placed of {metrics.totalStudents} total
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-semibold">
            <span>Total Offers Extended</span>
            <Award className="w-4 h-4 text-blue-600" />
          </div>
          <div className="mt-2 text-3xl font-extrabold text-blue-700">
            {metrics.totalOffers}
          </div>
          <div className="mt-1 text-[11px] text-slate-500">
            Includes multiple offers per candidate
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-semibold">
            <span>Average Package</span>
            <span className="text-[10px] font-bold text-slate-400">CTC</span>
          </div>
          <div className="mt-2 text-3xl font-extrabold text-slate-900">
            {metrics.avgPackage}
          </div>
          <div className="mt-1 text-[11px] text-slate-500">
            Highest: <strong className="text-emerald-700">{metrics.highestPackage}</strong>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-semibold">
            <span>Active Campus Drives</span>
            <Briefcase className="w-4 h-4 text-purple-600" />
          </div>
          <div className="mt-2 text-3xl font-extrabold text-purple-700">
            {metrics.activeDrives}
          </div>
          <div className="mt-1 text-[11px] text-slate-500">
            Across {metrics.totalCompanies} corporate partners
          </div>
        </div>
      </div>

      {/* Interactive Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Department Placement Bar Chart */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Department-wise Placement Rates (%)</h3>
              <p className="text-xs text-slate-500">Percentage of registered students placed by branch</p>
            </div>
            <BarChart3 className="w-4 h-4 text-slate-400" />
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={departmentStats} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                <XAxis dataKey="department" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} domain={[0, 100]} />
                <Tooltip
                  formatter={(value: any) => [`${value}%`, 'Placement Rate']}
                  contentStyle={{ backgroundColor: '#fff', borderRadius: '8px', fontSize: '12px' }}
                />
                <Bar dataKey="placementRate" fill="#2563EB" radius={[4, 4, 0, 0]} name="Placement %" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Application Status Distribution Pie Chart */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Application Status Distribution</h3>
              <p className="text-xs text-slate-500">Real-time candidate transition status breakdown</p>
            </div>
            <PieChartIcon className="w-4 h-4 text-slate-400" />
          </div>

          <div className="h-64 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={statusDistribution}
                  dataKey="count"
                  nameKey="status"
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  label={({ status, percent }) => `${status}: ${(percent * 100).toFixed(0)}%`}
                  labelLine={false}
                >
                  {statusDistribution.map((entry: any, index: number) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: '#fff', borderRadius: '8px', fontSize: '12px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Corporate Partners & Selection Performance */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Corporate Partners Performance</h3>
            <p className="text-xs text-slate-500 mt-0.5">Applicant flow and offer yield across verified companies</p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold">
                <th className="py-3 px-4">Company Name</th>
                <th className="py-3 px-4">Industry Sector</th>
                <th className="py-3 px-4">Verification</th>
                <th className="py-3 px-4">Active Drives</th>
                <th className="py-3 px-4">Total Applicants</th>
                <th className="py-3 px-4 text-right">Offers Extended</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {companyStats.map((c: any) => (
                <tr key={c.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="py-3 px-4 font-bold text-slate-900">{c.name}</td>
                  <td className="py-3 px-4 text-slate-600">{c.industry}</td>
                  <td className="py-3 px-4">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                      c.isVerified ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-amber-50 text-amber-700'
                    }`}>
                      {c.isVerified ? 'Verified' : 'Pending'}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-medium text-slate-700">{c.totalJobs} drives</td>
                  <td className="py-3 px-4 font-bold text-blue-700">{c.totalApplicants}</td>
                  <td className="py-3 px-4 text-right font-black text-emerald-700 text-sm">
                    {c.totalOffers}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

