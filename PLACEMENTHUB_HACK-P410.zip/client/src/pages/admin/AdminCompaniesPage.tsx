import React, { useState, useEffect } from 'react';
import { Building2, ShieldCheck, CheckCircle2, XCircle, ExternalLink, Plus } from 'lucide-react';
import { api } from '../../services/api';
import { Company } from '../../types';

export const AdminCompaniesPage: React.FC = () => {
  const [companies, setCompanies] = useState<Company[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchCompanies();
  }, []);

  const fetchCompanies = async () => {
    try {
      const res = await api.get('/companies');
      if (res.data.success) {
        setCompanies(res.data.companies);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleToggleVerify = async (companyId: string, currentStatus: boolean) => {
    try {
      const res = await api.patch(`/companies/${companyId}/verify`, {
        isVerified: !currentStatus,
      });
      if (res.data.success) {
        setCompanies(prev =>
          prev.map(c => (c.id === companyId ? { ...c, isVerified: !currentStatus } : c))
        );
      }
    } catch (err) {
      alert('Failed to update company verification status');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Corporate Partners & Verification
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Authenticate enterprise recruiters and govern campus recruitment privileges
          </p>
        </div>

        <span className="px-3 py-1.5 rounded-lg bg-blue-50 border border-blue-200 text-xs font-bold text-blue-800 self-start sm:self-auto">
          {companies.length} Registered Companies
        </span>
      </div>

      {isLoading ? (
        <div className="h-64 flex items-center justify-center">
          <div className="w-7 h-7 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {companies.map((c) => (
            <div
              key={c.id}
              className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="w-12 h-12 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center font-bold text-lg text-slate-800 overflow-hidden">
                    {c.logo ? (
                      <img src={c.logo} alt={c.name} className="w-full h-full object-cover" />
                    ) : (
                      c.name.charAt(0)
                    )}
                  </div>

                  <span
                    className={`inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full border ${
                      c.isVerified
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                        : 'bg-amber-50 text-amber-800 border-amber-200'
                    }`}
                  >
                    {c.isVerified ? (
                      <>
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" /> Verified
                      </>
                    ) : (
                      'Pending Review'
                    )}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-slate-900">{c.name}</h3>
                <p className="text-xs text-slate-500 mt-0.5 line-clamp-1">{c.industry}</p>

                <div className="mt-3.5 p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-1.5 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Headquarters:</span>
                    <span className="font-semibold text-slate-700">{c.headquarters}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Company Size:</span>
                    <span className="text-slate-700">{c.companySize}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Campus Drives:</span>
                    <span className="font-bold text-blue-700">{c._count?.jobs || 0} posted</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                {c.website && (
                  <a
                    href={c.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-blue-600 hover:underline flex items-center gap-1 font-medium"
                  >
                    <span>Website</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}

                <button
                  onClick={() => handleToggleVerify(c.id, c.isVerified)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                    c.isVerified
                      ? 'bg-slate-100 hover:bg-rose-50 text-slate-700 hover:text-rose-700'
                      : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs'
                  }`}
                >
                  {c.isVerified ? 'Revoke Status' : 'Verify Partner'}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

