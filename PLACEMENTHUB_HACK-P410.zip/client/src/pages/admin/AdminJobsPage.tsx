import React, { useState, useEffect } from 'react';
import { Briefcase, CheckCircle2, XCircle, Users, Clock, ShieldCheck } from 'lucide-react';
import { api } from '../../services/api';
import { Job } from '../../types';
import { Badge } from '../../components/common/Badge';

export const AdminJobsPage: React.FC = () => {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchJobs();
  }, []);

  const fetchJobs = async () => {
    try {
      const res = await api.get('/jobs');
      if (res.data.success) {
        setJobs(res.data.jobs);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleApprove = async (jobId: string, status: 'PUBLISHED' | 'CANCELLED' | 'CLOSED') => {
    try {
      const res = await api.patch(`/jobs/${jobId}/approve`, { status });
      if (res.data.success) {
        setJobs(prev =>
          prev.map(j => (j.id === jobId ? { ...j, status } : j))
        );
      }
    } catch (err: any) {
      alert(err.response?.data?.message || 'Failed to update job approval status');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Recruitment Drive Governance
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Approve corporate job postings, verify academic criteria, and publish drives to eligible students
          </p>
        </div>

        <span className="px-3 py-1.5 rounded-lg bg-blue-50 border border-blue-200 text-xs font-bold text-blue-800 self-start sm:self-auto">
          {jobs.filter(j => j.status === 'PENDING_APPROVAL').length} Pending Approvals
        </span>
      </div>

      {isLoading ? (
        <div className="h-64 flex items-center justify-center">
          <div className="w-7 h-7 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold">
                  <th className="py-3 px-4">Drive Title</th>
                  <th className="py-3 px-4">Corporate Partner</th>
                  <th className="py-3 px-4">Compensation</th>
                  <th className="py-3 px-4">Eligibility Cutoffs</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Deadline</th>
                  <th className="py-3 px-4 text-right">Admin Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {jobs.map((job) => (
                  <tr key={job.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900">{job.title}</div>
                      <div className="text-[11px] text-slate-500">{job.location} • {job.vacancies} vacancies</div>
                    </td>
                    <td className="py-3.5 px-4 font-semibold text-slate-800">{job.company.name}</td>
                    <td className="py-3.5 px-4 font-bold text-emerald-700">{job.salaryRange}</td>
                    <td className="py-3.5 px-4 text-slate-600">
                      <div>Min CGPA: <strong>{job.minCgpa.toFixed(1)}</strong></div>
                      <div className="text-[11px] text-slate-500">Backlogs ≤ {job.maxActiveBacklogs} • {job.eligibleDepartments.join(', ')}</div>
                    </td>
                    <td className="py-3.5 px-4">
                      <Badge variant={job.status === 'PUBLISHED' ? 'success' : job.status === 'PENDING_APPROVAL' ? 'warning' : 'slate'}>
                        {job.status}
                      </Badge>
                    </td>
                    <td className="py-3.5 px-4 text-slate-500">
                      {new Date(job.applicationDeadline).toLocaleDateString()}
                    </td>
                    <td className="py-3.5 px-4 text-right space-x-1.5">
                      {job.status === 'PENDING_APPROVAL' && (
                        <button
                          onClick={() => handleApprove(job.id, 'PUBLISHED')}
                          className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-xs font-semibold shadow-xs transition-colors"
                        >
                          Approve & Publish
                        </button>
                      )}

                      {job.status === 'PUBLISHED' && (
                        <button
                          onClick={() => handleApprove(job.id, 'CLOSED')}
                          className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-xs font-medium transition-colors"
                        >
                          Close Drive
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
