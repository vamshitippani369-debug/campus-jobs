import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShieldCheck, Building2, User, KeyRound, AlertCircle, ArrowRight } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Role } from '../../types';

export const LoginPage: React.FC = () => {
  const { login, quickLogin } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsSubmitting(true);

    try {
      const user = await login(email, password);
      if (user.role === 'ADMIN') navigate('/admin/dashboard');
      else if (user.role === 'RECRUITER') navigate('/recruiter/dashboard');
      else navigate('/dashboard');
    } catch (err: any) {
      setError(err.response?.data?.message || 'Invalid email or password');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDemoSelect = async (role: Role) => {
    setError(null);
    setIsSubmitting(true);
    try {
      const user = await quickLogin(role);
      if (user.role === 'ADMIN') navigate('/admin/dashboard');
      else if (user.role === 'RECRUITER') navigate('/recruiter/dashboard');
      else navigate('/dashboard');
    } catch (err: any) {
      setError('Failed to log in with demo account');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col justify-center py-12 px-6 lg:px-8 font-sans">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <Link to="/" className="inline-flex items-center gap-2.5 mb-4 group">
          <div className="w-10 h-10 rounded-xl bg-[#172554] flex items-center justify-center text-white font-extrabold text-lg shadow-sm group-hover:bg-blue-900 transition-colors">
            P
          </div>
          <span className="text-xl font-bold tracking-tight text-[#172554]">
            PLACEMENT<span className="text-blue-600">HUB</span>
          </span>
        </Link>
        <h2 className="text-2xl font-bold tracking-tight text-slate-900">
          Sign in to your account
        </h2>
        <p className="mt-1.5 text-xs text-slate-500">
          Enter your university credentials or select a 1-click demo persona
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-6 shadow-sm border border-slate-200 rounded-2xl sm:px-10">
          {error && (
            <div className="mb-5 p-3 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-700 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Email Address
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@university.edu"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent transition-all"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-semibold text-slate-700">
                  Password
                </label>
              </div>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent transition-all"
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-2.5 px-4 rounded-lg bg-[#172554] hover:bg-blue-900 text-white font-semibold text-xs shadow-xs transition-colors disabled:opacity-50"
            >
              {isSubmitting ? 'Authenticating...' : 'Sign In'}
            </button>
          </form>

          {/* Quick Demo Switchers (as required by prompt) */}
          <div className="mt-6 pt-6 border-t border-slate-100">
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-3 text-center">
              1-Click Instant Demo Portals
            </div>

            <div className="space-y-2">
              <button
                type="button"
                onClick={() => handleDemoSelect('STUDENT')}
                className="w-full p-2.5 rounded-lg border border-emerald-200 bg-emerald-50/50 hover:bg-emerald-50 text-emerald-900 flex items-center justify-between transition-colors text-left"
              >
                <div className="flex items-center gap-2.5">
                  <User className="w-4 h-4 text-emerald-600 shrink-0" />
                  <div>
                    <div className="text-xs font-bold">Student Persona</div>
                    <div className="text-[10px] text-emerald-700">student@placementhub.demo</div>
                  </div>
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-emerald-600" />
              </button>

              <button
                type="button"
                onClick={() => handleDemoSelect('RECRUITER')}
                className="w-full p-2.5 rounded-lg border border-blue-200 bg-blue-50/50 hover:bg-blue-50 text-blue-900 flex items-center justify-between transition-colors text-left"
              >
                <div className="flex items-center gap-2.5">
                  <Building2 className="w-4 h-4 text-blue-600 shrink-0" />
                  <div>
                    <div className="text-xs font-bold">Recruiter Persona (Nexora Tech)</div>
                    <div className="text-[10px] text-blue-700">recruiter@placementhub.demo</div>
                  </div>
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-blue-600" />
              </button>

              <button
                type="button"
                onClick={() => handleDemoSelect('ADMIN')}
                className="w-full p-2.5 rounded-lg border border-purple-200 bg-purple-50/50 hover:bg-purple-50 text-purple-900 flex items-center justify-between transition-colors text-left"
              >
                <div className="flex items-center gap-2.5">
                  <ShieldCheck className="w-4 h-4 text-purple-600 shrink-0" />
                  <div>
                    <div className="text-xs font-bold">University Administrator</div>
                    <div className="text-[10px] text-purple-700">admin@placementhub.demo</div>
                  </div>
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-purple-600" />
              </button>
            </div>

            <div className="mt-3 text-center text-[10px] text-slate-400">
              Password for all demo accounts: <span className="font-mono text-slate-600">DemoPass123!</span>
            </div>
          </div>
        </div>

        <div className="mt-6 text-center text-xs text-slate-500 space-x-4">
          <span>New student? <Link to="/register/student" className="font-semibold text-blue-600 hover:underline">Register</Link></span>
          <span>•</span>
          <span>Company partner? <Link to="/register/recruiter" className="font-semibold text-blue-600 hover:underline">Register</Link></span>
        </div>
      </div>
    </div>
  );
};

