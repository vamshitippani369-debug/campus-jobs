import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ShieldCheck,
  Briefcase,
  Users,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  BarChart3,
  Calendar,
  Building2,
  FileCheck,
  Award,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const LandingPage: React.FC = () => {
  const { quickLogin } = useAuth();
  const navigate = useNavigate();

  const handleQuickDemo = async (role: 'STUDENT' | 'RECRUITER' | 'ADMIN') => {
    try {
      await quickLogin(role);
      if (role === 'ADMIN') navigate('/admin/dashboard');
      else if (role === 'RECRUITER') navigate('/recruiter/dashboard');
      else navigate('/dashboard');
    } catch (err) {
      navigate('/login');
    }
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900 flex flex-col font-sans">
      {/* Top Navbar */}
      <nav className="h-20 bg-white/80 backdrop-blur-md border-b border-slate-200/80 sticky top-0 z-40 px-6 lg:px-12 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#172554] flex items-center justify-center text-white font-black text-lg shadow-sm">
            P
          </div>
          <div>
            <div className="text-base font-extrabold tracking-tight text-[#172554]">
              PLACEMENT<span className="text-blue-600">HUB</span>
            </div>
            <div className="text-[11px] text-slate-500 font-medium -mt-0.5">
              One Platform. Every Opportunity.
            </div>
          </div>
        </div>

        <div className="hidden md:flex items-center gap-8 text-xs font-semibold text-slate-600">
          <a href="#features" className="hover:text-blue-600 transition-colors">Core Features</a>
          <a href="#engine" className="hover:text-blue-600 transition-colors">Eligibility Engine</a>
          <a href="#stakeholders" className="hover:text-blue-600 transition-colors">Stakeholders</a>
          <a href="#demo" className="hover:text-blue-600 transition-colors">Live Demo</a>
        </div>

        <div className="flex items-center gap-3">
          <Link
            to="/login"
            className="px-4 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 transition-colors"
          >
            Sign In
          </Link>
          <Link
            to="/register/student"
            className="px-4 py-2 text-xs font-semibold text-white bg-[#172554] hover:bg-blue-900 rounded-lg shadow-xs transition-colors"
          >
            Get Started
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-20 pb-16 px-6 lg:px-12 max-w-7xl mx-auto w-full text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-xs font-semibold mb-6">
          <Sparkles className="w-3.5 h-3.5" />
          Production-Grade Campus Placement SaaS Platform (HACK-P410)
        </div>

        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-[#172554] tracking-tight max-w-4xl mx-auto leading-[1.15]">
          Centralize University Placements with Deterministic Intelligence.
        </h1>

        <p className="mt-6 text-base sm:text-lg text-slate-600 max-w-2xl mx-auto leading-relaxed">
          Eliminate error-prone spreadsheets. Connect students, recruiters, and placement officers in a unified workflow with deterministic eligibility verification, real-time interview coordination, and transparent placement reports.
        </p>

        {/* Action Buttons */}
        <div className="mt-10 flex flex-wrap items-center justify-center gap-3.5">
          <button
            onClick={() => handleQuickDemo('STUDENT')}
            className="px-5 py-3 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-sm flex items-center gap-2 transition-all"
          >
            <span>Launch Student Demo</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={() => handleQuickDemo('RECRUITER')}
            className="px-5 py-3 rounded-lg bg-[#172554] hover:bg-slate-900 text-white font-semibold text-xs shadow-sm flex items-center gap-2 transition-all"
          >
            <Building2 className="w-4 h-4 text-blue-400" />
            <span>Launch Recruiter Demo</span>
          </button>

          <button
            onClick={() => handleQuickDemo('ADMIN')}
            className="px-5 py-3 rounded-lg bg-white border border-slate-300 hover:bg-slate-50 text-slate-800 font-semibold text-xs shadow-xs flex items-center gap-2 transition-all"
          >
            <ShieldCheck className="w-4 h-4 text-purple-600" />
            <span>Launch Admin Portal</span>
          </button>
        </div>

        {/* Live Interactive Preview Card */}
        <div className="mt-14 max-w-5xl mx-auto bg-white rounded-2xl border border-slate-200 shadow-xl overflow-hidden text-left">
          <div className="p-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-rose-500 inline-block" />
              <span className="w-3 h-3 rounded-full bg-amber-500 inline-block" />
              <span className="w-3 h-3 rounded-full bg-emerald-500 inline-block" />
              <span className="ml-3 text-xs font-mono text-slate-400">
                https://portal.univ.edu/opportunities/nexora-sde-drive
              </span>
            </div>
            <span className="text-[11px] font-mono bg-blue-900/60 text-blue-300 px-2.5 py-0.5 rounded border border-blue-700">
              Deterministic Verification Active
            </span>
          </div>

          <div className="p-6 lg:p-8 space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-100">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-blue-600">Nexora Technologies</span>
                <h3 className="text-xl font-bold text-slate-900 mt-0.5">Graduate Software Development Engineer (SDE-1)</h3>
                <div className="flex flex-wrap items-center gap-3 mt-2 text-xs text-slate-500">
                  <span>📍 Bengaluru / Hybrid</span>
                  <span>•</span>
                  <span>💰 14 - 18 LPA</span>
                  <span>•</span>
                  <span>🎓 CSE, IT, ECE (2025, 2026 Batch)</span>
                </div>
              </div>
              <div className="text-right">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Criteria Passed (Eligible to Apply)
                </span>
              </div>
            </div>

            {/* Smart Eligibility Breakdown Highlight */}
            <div className="bg-slate-50 rounded-xl p-5 border border-slate-200">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
                Intelligent Rule Engine Breakdown
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                <div className="p-3 bg-white rounded-lg border border-slate-200 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <div>
                    <div className="font-semibold text-slate-800">CGPA: 8.85 ≥ 7.50</div>
                    <div className="text-[11px] text-slate-500">Requirement satisfied</div>
                  </div>
                </div>
                <div className="p-3 bg-white rounded-lg border border-slate-200 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <div>
                    <div className="font-semibold text-slate-800">Active Backlogs: 0 ≤ 0</div>
                    <div className="text-[11px] text-slate-500">Zero backlogs verified</div>
                  </div>
                </div>
                <div className="p-3 bg-white rounded-lg border border-slate-200 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <div>
                    <div className="font-semibold text-slate-800">Department: CSE</div>
                    <div className="text-[11px] text-slate-500">Matches eligible list</div>
                  </div>
                </div>
                <div className="p-3 bg-white rounded-lg border border-slate-200 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <div>
                    <div className="font-semibold text-slate-800">Graduation: 2025</div>
                    <div className="text-[11px] text-slate-500">Batch verified</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Highlights */}
      <section id="features" className="py-20 bg-white border-y border-slate-200/80 px-6 lg:px-12">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-xs font-bold uppercase tracking-wider text-blue-600 mb-2">Designed for Enterprise Scale</h2>
            <h3 className="text-3xl font-extrabold text-[#172554] tracking-tight">Complete Placement Lifecycle Control</h3>
            <p className="mt-3 text-sm text-slate-600">
              Engineered to replace fragmented emails and spreadsheets with an audit-compliant workflow.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 rounded-xl border border-slate-200 bg-slate-50/50 hover:shadow-md transition-shadow">
              <div className="w-10 h-10 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center mb-4">
                <FileCheck className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-slate-900">Deterministic Eligibility Engine</h4>
              <p className="mt-2 text-xs text-slate-600 leading-relaxed">
                Backend logic strictly evaluates CGPA, backlogs, department, batch, and resume presence. No hallucinations, full transparency, and detailed failure rationale.
              </p>
            </div>

            <div className="p-6 rounded-xl border border-slate-200 bg-slate-50/50 hover:shadow-md transition-shadow">
              <div className="w-10 h-10 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center mb-4">
                <Calendar className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-slate-900">End-to-End Interview Scheduler</h4>
              <p className="mt-2 text-xs text-slate-600 leading-relaxed">
                Recruiters schedule Technical, HR, and GD rounds with date, time, venue, or online links. Students receive immediate in-app notifications and calendar alerts.
              </p>
            </div>

            <div className="p-6 rounded-xl border border-slate-200 bg-slate-50/50 hover:shadow-md transition-shadow">
              <div className="w-10 h-10 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center mb-4">
                <BarChart3 className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-slate-900">Real Placement Analytics & Audit Trail</h4>
              <p className="mt-2 text-xs text-slate-600 leading-relaxed">
                Live metrics derived from actual database records: placed students vs total offers, department statistics, average packages, and one-click CSV export reports.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Stakeholders Section */}
      <section id="stakeholders" className="py-20 px-6 lg:px-12 max-w-7xl mx-auto w-full">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-xs font-bold uppercase tracking-wider text-blue-600 mb-2">Role-Based Architecture</h2>
          <h3 className="text-3xl font-extrabold text-[#172554] tracking-tight">Dedicated Dashboards for Every Stakeholder</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white rounded-xl border border-slate-200 p-6 flex flex-col justify-between">
            <div>
              <div className="inline-flex p-2 rounded-lg bg-emerald-50 text-emerald-700 mb-4">
                <Users className="w-5 h-5" />
              </div>
              <h4 className="text-lg font-bold text-slate-900">For Students</h4>
              <ul className="mt-4 space-y-2.5 text-xs text-slate-600">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  Pre-check eligibility before applying
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  PDF resume upload and management
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  Track interview rounds & official offers
                </li>
              </ul>
            </div>
            <button
              onClick={() => handleQuickDemo('STUDENT')}
              className="mt-6 w-full py-2.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-800 transition-colors"
            >
              Sign In as Student
            </button>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 p-6 flex flex-col justify-between">
            <div>
              <div className="inline-flex p-2 rounded-lg bg-blue-50 text-blue-700 mb-4">
                <Building2 className="w-5 h-5" />
              </div>
              <h4 className="text-lg font-bold text-slate-900">For Recruiters</h4>
              <ul className="mt-4 space-y-2.5 text-xs text-slate-600">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                  Post custom recruitment drives & criteria
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                  Filter verified applicants & inspect resumes
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                  Shortlist, schedule interviews, issue offers
                </li>
              </ul>
            </div>
            <button
              onClick={() => handleQuickDemo('RECRUITER')}
              className="mt-6 w-full py-2.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-800 transition-colors"
            >
              Sign In as Recruiter
            </button>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 p-6 flex flex-col justify-between">
            <div>
              <div className="inline-flex p-2 rounded-lg bg-purple-50 text-purple-700 mb-4">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h4 className="text-lg font-bold text-slate-900">For Placement Admins</h4>
              <ul className="mt-4 space-y-2.5 text-xs text-slate-600">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-purple-600 shrink-0" />
                  Approve/reject drives & verify companies
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-purple-600 shrink-0" />
                  Institutional placement statistics & charts
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-purple-600 shrink-0" />
                  Export downloadable CSV reports & audit logs
                </li>
              </ul>
            </div>
            <button
              onClick={() => handleQuickDemo('ADMIN')}
              className="mt-6 w-full py-2.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-800 transition-colors"
            >
              Sign In as Admin
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-200 bg-white py-10 px-6 lg:px-12 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-800">PLACEMENTHUB</span>
            <span>—</span>
            <span>One Platform. Every Opportunity.</span>
          </div>
          <div className="text-slate-400">
            HACK-P410 Master Campus Recruitment Architecture • Antigravity 2.0
          </div>
        </div>
      </footer>
    </div>
  );
};

