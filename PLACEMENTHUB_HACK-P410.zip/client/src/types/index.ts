export type Role = 'STUDENT' | 'RECRUITER' | 'ADMIN';

export interface User {
  id: string;
  email: string;
  role: Role;
  studentProfile?: StudentProfile;
  recruiterProfile?: RecruiterProfile;
}

export interface StudentProfile {
  id: string;
  userId: string;
  fullName: string;
  studentId: string;
  collegeEmail: string;
  phone: string;
  department: string;
  course: string;
  graduationYear: number;
  cgpa: number;
  backlogs: number;
  activeBacklogs: number;
  tenthPercentage: number;
  twelfthPercentage: number;
  graduationStatus: string;
  technicalSkills: string[];
  programmingLanguages?: string[];
  certifications?: Array<{ title: string; issuer: string; year: string }>;
  projects?: Array<{ title: string; description: string; techStack: string; link?: string }>;
  internshipExperience?: Array<{ role: string; company: string; duration: string; description: string }>;
  linkedInUrl?: string;
  gitHubUrl?: string;
  resumeUrl?: string;
  resumeFilename?: string;
  profileCompletion: number;
}

export interface Company {
  id: string;
  name: string;
  logo?: string;
  industry: string;
  website: string;
  description: string;
  headquarters: string;
  companySize: string;
  hrContactEmail: string;
  hrContactPhone: string;
  isVerified: boolean;
  _count?: {
    jobs: number;
    offers: number;
  };
}

export interface RecruiterProfile {
  id: string;
  userId: string;
  companyId: string;
  fullName: string;
  designation: string;
  phone: string;
  company?: Company;
}

export interface CriterionResult {
  name: string;
  status: 'PASS' | 'FAIL';
  message: string;
  required: any;
  studentValue: any;
}

export interface SkillMatchResult {
  matchPercentage: number;
  matchedSkills: string[];
  missingSkills: string[];
}

export interface EligibilityReport {
  isEligible: boolean;
  canApply: boolean;
  blockReason?: string;
  criteriaBreakdown: CriterionResult[];
  passedReasons: string[];
  failedReasons: string[];
  skillMatch: SkillMatchResult;
  evaluatedAt: string;
}

export interface Job {
  id: string;
  companyId: string;
  company: Company;
  title: string;
  description: string;
  location: string;
  employmentType: 'FULL_TIME' | 'INTERNSHIP' | 'INTERN_TO_FTE';
  salaryRange: string;
  minSalary?: number;
  maxSalary?: number;
  vacancies: number;
  selectionProcess?: string;
  status: 'DRAFT' | 'PENDING_APPROVAL' | 'PUBLISHED' | 'CLOSED' | 'CANCELLED';
  applicationOpeningDate: string;
  applicationDeadline: string;
  minCgpa: number;
  maxActiveBacklogs: number;
  eligibleDepartments: string[];
  eligibleGraduationYears: number[];
  requiredSkills: string[];
  _count?: {
    applications: number;
  };
  hasApplied?: boolean;
  eligibility?: EligibilityReport;
}

export interface Application {
  id: string;
  studentId: string;
  student: StudentProfile;
  jobId: string;
  job: Job;
  status: 'SUBMITTED' | 'SHORTLISTED' | 'INTERVIEW_SCHEDULED' | 'SELECTED' | 'REJECTED' | 'WITHDRAWN';
  eligibilityReport?: EligibilityReport;
  resumeUrl?: string;
  notes?: string;
  createdAt: string;
  interviews?: Interview[];
  offer?: Offer;
}

export interface Interview {
  id: string;
  applicationId: string;
  studentId: string;
  jobId: string;
  round: 'TECHNICAL' | 'HR' | 'GROUP_DISCUSSION' | 'ONLINE_ASSESSMENT' | 'FINAL';
  scheduledDate: string;
  scheduledTime: string;
  durationMinutes: number;
  mode: 'ONLINE' | 'OFFLINE';
  meetingLink?: string;
  venue?: string;
  instructions?: string;
  status: 'SCHEDULED' | 'COMPLETED' | 'CANCELLED';
  feedback?: string;
  result: 'PENDING' | 'PASSED' | 'FAILED';
  job?: Job;
  student?: StudentProfile;
}

export interface Offer {
  id: string;
  applicationId: string;
  studentId: string;
  jobId: string;
  companyId: string;
  ctc: string;
  designation: string;
  location: string;
  joiningDate?: string;
  status: 'OFFERED' | 'ACCEPTED' | 'DECLINED';
  company?: Company;
  job?: Job;
  student?: StudentProfile;
  createdAt: string;
}

export interface NotificationItem {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'APPLICATION' | 'INTERVIEW' | 'OFFER' | 'SYSTEM' | 'JOB';
  isRead: boolean;
  link?: string;
  createdAt: string;
}

export interface AuditLogItem {
  id: string;
  userId?: string;
  userEmail: string;
  userRole: string;
  action: string;
  entityType: string;
  entityId?: string;
  details?: any;
  createdAt: string;
}

