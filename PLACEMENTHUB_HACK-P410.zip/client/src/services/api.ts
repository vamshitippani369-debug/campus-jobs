import axios from 'axios';
import { INITIAL_MOCK_STATE } from './mockData';

// Determine Base URL
const baseURL = (import.meta.env.VITE_API_URL as string) || '/api';

export const api = axios.create({
  baseURL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 4000, // Quick timeout before fallback
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Deterministic Eligibility Checker (Client Fallback)
const evaluateEligibility = (student: any, job: any) => {
  const isCgpaPass = student.cgpa >= job.minCgpa;
  const isBacklogPass = student.activeBacklogs <= job.maxActiveBacklogs;
  const isDeptPass = job.eligibleDepartments.includes(student.department);
  const isYearPass = job.eligibleGraduationYears.includes(student.graduationYear);

  const isEligible = isCgpaPass && isBacklogPass && isDeptPass && isYearPass;
  const canApply = isEligible && Boolean(student.resumeUrl);

  const criteriaBreakdown = [
    {
      name: 'Minimum CGPA',
      status: isCgpaPass ? 'PASS' : 'FAIL',
      message: isCgpaPass
        ? `CGPA requirement satisfied (${student.cgpa.toFixed(2)} ≥ ${job.minCgpa.toFixed(2)})`
        : `Minimum CGPA required: ${job.minCgpa.toFixed(2)}. Your CGPA: ${student.cgpa.toFixed(2)}`,
    },
    {
      name: 'Active Backlogs',
      status: isBacklogPass ? 'PASS' : 'FAIL',
      message: isBacklogPass
        ? `Active backlog requirement satisfied (${student.activeBacklogs} ≤ ${job.maxActiveBacklogs})`
        : `Maximum allowed active backlogs is ${job.maxActiveBacklogs}, but you have ${student.activeBacklogs}`,
    },
    {
      name: 'Eligible Department',
      status: isDeptPass ? 'PASS' : 'FAIL',
      message: isDeptPass
        ? `Department requirement satisfied (${student.department})`
        : `Your department (${student.department}) is not in eligible list (${job.eligibleDepartments.join(', ')})`,
    },
    {
      name: 'Graduation Year',
      status: isYearPass ? 'PASS' : 'FAIL',
      message: isYearPass
        ? `Graduation year requirement satisfied (${student.graduationYear})`
        : `Batch ${student.graduationYear} is not eligible. Required: ${job.eligibleGraduationYears.join(', ')}`,
    },
  ];

  const studentSkills = (student.technicalSkills || []).map((s: string) => s.toLowerCase());
  const requiredSkills = job.requiredSkills || [];
  const matchedSkills = requiredSkills.filter((s: string) => studentSkills.includes(s.toLowerCase()));
  const missingSkills = requiredSkills.filter((s: string) => !studentSkills.includes(s.toLowerCase()));
  const matchPercentage = requiredSkills.length > 0 ? Math.round((matchedSkills.length / requiredSkills.length) * 100) : 100;

  return {
    isEligible,
    canApply,
    criteriaBreakdown,
    passedReasons: criteriaBreakdown.filter(c => c.status === 'PASS').map(c => c.message),
    failedReasons: criteriaBreakdown.filter(c => c.status === 'FAIL').map(c => c.message),
    skillMatch: {
      matchPercentage,
      matchedSkills,
      missingSkills,
    },
  };
};

// Mock response handler for standalone Vercel preview
const handleMockFallback = (config: any): any => {
  const url = config.url || '';
  const method = (config.method || 'get').toLowerCase();

  // 1. Auth: Login
  if (url.includes('/auth/login') && method === 'post') {
    const data = typeof config.data === 'string' ? JSON.parse(config.data) : config.data;
    const email = data.email?.toLowerCase().trim();

    let userRole = 'STUDENT';
    let userProfile: any = INITIAL_MOCK_STATE.demoStudent;
    let recruiterProfile: any = null;

    if (email.includes('admin')) {
      userRole = 'ADMIN';
    } else if (email.includes('recruiter')) {
      userRole = 'RECRUITER';
      recruiterProfile = {
        fullName: 'Vikram Malhotra',
        designation: 'Senior Talent Acquisition Lead',
        companyId: 'comp-1',
        company: INITIAL_MOCK_STATE.companies[0],
      };
    }

    const userData = {
      id: `user-${userRole.toLowerCase()}`,
      email,
      role: userRole,
      studentProfile: userRole === 'STUDENT' ? userProfile : null,
      recruiterProfile,
    };

    return {
      data: {
        success: true,
        token: 'mock-jwt-token-vercel',
        user: userData,
      },
    };
  }

  // 2. Auth: Me
  if (url.includes('/auth/me')) {
    const savedUser = localStorage.getItem('user');
    const user = savedUser ? JSON.parse(savedUser) : {
      id: 'user-student',
      email: 'student@placementhub.demo',
      role: 'STUDENT',
      studentProfile: INITIAL_MOCK_STATE.demoStudent,
    };
    return { data: { success: true, user } };
  }

  // 3. Student Dashboard
  if (url.includes('/student/dashboard')) {
    return {
      data: {
        success: true,
        stats: {
          totalApplied: 2,
          shortlistedCount: 1,
          interviewCount: 1,
          selectedCount: 1,
          rejectedCount: 0,
          profileCompletion: 92,
        },
        recentApplications: INITIAL_MOCK_STATE.applications.map(app => {
          const job = INITIAL_MOCK_STATE.jobs.find(j => j.id === app.jobId);
          const company = INITIAL_MOCK_STATE.companies.find(c => c.id === job?.companyId);
          return {
            ...app,
            job: { ...job, company },
          };
        }),
        upcomingInterviews: INITIAL_MOCK_STATE.interviews.map(inv => {
          const job = INITIAL_MOCK_STATE.jobs.find(j => j.id === inv.jobId);
          const company = INITIAL_MOCK_STATE.companies.find(c => c.id === job?.companyId);
          return {
            ...inv,
            job: { ...job, company },
          };
        }),
      },
    };
  }

  // 4. Student Profile
  if (url.includes('/student/profile')) {
    if (method === 'put') {
      const updated = typeof config.data === 'string' ? JSON.parse(config.data) : config.data;
      return { data: { success: true, profile: updated } };
    }
    return { data: { success: true, profile: INITIAL_MOCK_STATE.demoStudent } };
  }

  // 5. Jobs List
  if (url.includes('/jobs') && !url.includes('/applicants')) {
    const parts = url.split('/');
    const jobId = parts[parts.length - 1];

    if (jobId && jobId !== 'jobs' && !jobId.includes('?')) {
      const job = INITIAL_MOCK_STATE.jobs.find(j => j.id === jobId) || INITIAL_MOCK_STATE.jobs[0];
      const company = INITIAL_MOCK_STATE.companies.find(c => c.id === job.companyId);
      const eligibility = evaluateEligibility(INITIAL_MOCK_STATE.demoStudent, job);
      const application = INITIAL_MOCK_STATE.applications.find(a => a.jobId === job.id);
      return {
        data: {
          success: true,
          job: { ...job, company },
          eligibility,
          application,
        },
      };
    }

    const formatted = INITIAL_MOCK_STATE.jobs.map(job => {
      const company = INITIAL_MOCK_STATE.companies.find(c => c.id === job.companyId);
      const eligibility = evaluateEligibility(INITIAL_MOCK_STATE.demoStudent, job);
      const hasApplied = INITIAL_MOCK_STATE.applications.some(a => a.jobId === job.id);
      return {
        ...job,
        company,
        eligibility,
        hasApplied,
      };
    });
    return { data: { success: true, count: formatted.length, jobs: formatted } };
  }

  // 6. Applications
  if (url.includes('/applications')) {
    if (method === 'post') {
      return { data: { success: true, message: 'Application submitted successfully!' } };
    }
    const apps = INITIAL_MOCK_STATE.applications.map(app => {
      const job = INITIAL_MOCK_STATE.jobs.find(j => j.id === app.jobId);
      const company = INITIAL_MOCK_STATE.companies.find(c => c.id === job?.companyId);
      return {
        ...app,
        job: { ...job, company },
        interviews: INITIAL_MOCK_STATE.interviews.filter(i => i.applicationId === app.id),
      };
    });
    return { data: { success: true, count: apps.length, applications: apps } };
  }

  // 7. Interviews
  if (url.includes('/interviews')) {
    const list = INITIAL_MOCK_STATE.interviews.map(inv => {
      const job = INITIAL_MOCK_STATE.jobs.find(j => j.id === inv.jobId);
      const company = INITIAL_MOCK_STATE.companies.find(c => c.id === job?.companyId);
      return {
        ...inv,
        job: { ...job, company },
      };
    });
    return { data: { success: true, count: list.length, interviews: list } };
  }

  // 8. Offers
  if (url.includes('/offers')) {
    const list = INITIAL_MOCK_STATE.offers.map(off => {
      const company = INITIAL_MOCK_STATE.companies.find(c => c.id === off.companyId);
      const job = INITIAL_MOCK_STATE.jobs.find(j => j.id === off.jobId);
      return {
        ...off,
        company,
        job,
      };
    });
    return { data: { success: true, count: list.length, offers: list } };
  }

  // 9. Admin Stats
  if (url.includes('/admin/stats')) {
    return {
      data: {
        success: true,
        metrics: {
          totalStudents: 20,
          totalCompanies: 3,
          activeDrives: 5,
          totalApplications: 12,
          totalShortlisted: 6,
          totalInterviews: 4,
          totalPlacedStudents: 3,
          totalOffers: 4,
          overallPlacementRate: 85.0,
          highestPackage: '21.0 LPA',
          avgPackage: '16.5 LPA',
        },
        departmentStats: [
          { department: 'CSE', totalStudents: 8, placedStudents: 7, placementRate: 87.5, avgPackage: 17.2 },
          { department: 'IT', totalStudents: 6, placedStudents: 5, placementRate: 83.3, avgPackage: 15.8 },
          { department: 'ECE', totalStudents: 4, placedStudents: 3, placementRate: 75.0, avgPackage: 12.5 },
          { department: 'EEE', totalStudents: 2, placedStudents: 2, placementRate: 100.0, avgPackage: 13.0 },
        ],
        statusDistribution: [
          { status: 'SUBMITTED', count: 3 },
          { status: 'SHORTLISTED', count: 3 },
          { status: 'INTERVIEW SCHEDULED', count: 2 },
          { status: 'SELECTED', count: 4 },
        ],
        companyStats: INITIAL_MOCK_STATE.companies.map(c => ({
          id: c.id,
          name: c.name,
          industry: c.industry,
          isVerified: c.isVerified,
          totalJobs: 2,
          totalApplicants: 5,
          totalOffers: 1,
        })),
      },
    };
  }

  // 10. Admin Students
  if (url.includes('/admin/students')) {
    return {
      data: {
        success: true,
        students: [
          { ...INITIAL_MOCK_STATE.demoStudent, _count: { applications: 3, offers: 1 } },
          { id: 'st-2', fullName: 'Ananya Verma', studentId: '21CS002', collegeEmail: 'ananya@univ.edu', department: 'CSE', graduationYear: 2025, cgpa: 9.42, activeBacklogs: 0, _count: { applications: 2, offers: 1 } },
          { id: 'st-3', fullName: 'Rohan Iyer', studentId: '21IT003', collegeEmail: 'rohan@univ.edu', department: 'IT', graduationYear: 2025, cgpa: 7.82, activeBacklogs: 0, _count: { applications: 1, offers: 0 } },
          { id: 'st-4', fullName: 'Sneha Patel', studentId: '21EC004', collegeEmail: 'sneha@univ.edu', department: 'ECE', graduationYear: 2025, cgpa: 8.10, activeBacklogs: 0, _count: { applications: 2, offers: 1 } },
        ],
      },
    };
  }

  // 11. Companies
  if (url.includes('/companies')) {
    return { data: { success: true, companies: INITIAL_MOCK_STATE.companies } };
  }

  // 12. Notifications
  if (url.includes('/notifications')) {
    return {
      data: {
        success: true,
        count: INITIAL_MOCK_STATE.notifications.length,
        unreadCount: 2,
        notifications: INITIAL_MOCK_STATE.notifications,
      },
    };
  }

  // 13. Audit logs
  if (url.includes('/admin/audit-logs')) {
    return {
      data: {
        success: true,
        total: INITIAL_MOCK_STATE.auditLogs.length,
        logs: INITIAL_MOCK_STATE.auditLogs,
      },
    };
  }

  // Default fallback
  return { data: { success: true, message: 'OK' } };
};

// Response interceptor with graceful cloud fallback
api.interceptors.response.use(
  (response) => response,
  (error) => {
    // If backend is not reached (e.g. static Vercel preview or server down), use mock fallback
    if (!error.response || error.response.status === 404 || error.response.status >= 500 || error.code === 'ERR_NETWORK') {
      try {
        const mockRes = handleMockFallback(error.config);
        if (mockRes) {
          return Promise.resolve(mockRes);
        }
      } catch (e) {
        console.warn('Fallback error', e);
      }
    }

    if (error.response?.status === 401) {
      if (!window.location.pathname.startsWith('/login') && !window.location.pathname.startsWith('/register') && window.location.pathname !== '/') {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);
