import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';

// Layouts & Auth
import { DashboardLayout } from './layouts/DashboardLayout';

// Public Pages
import { LandingPage } from './pages/public/LandingPage';
import { LoginPage } from './pages/public/LoginPage';
import { RegisterStudentPage } from './pages/public/RegisterStudentPage';
import { RegisterRecruiterPage } from './pages/public/RegisterRecruiterPage';

// Student Pages
import { StudentDashboard } from './pages/student/StudentDashboard';
import { BrowseJobsPage } from './pages/student/BrowseJobsPage';
import { JobDetailPage } from './pages/student/JobDetailPage';
import { StudentApplicationsPage } from './pages/student/StudentApplicationsPage';
import { StudentInterviewsPage } from './pages/student/StudentInterviewsPage';
import { StudentOffersPage } from './pages/student/StudentOffersPage';
import { StudentProfilePage } from './pages/student/StudentProfilePage';

// Recruiter Pages
import { RecruiterDashboard } from './pages/recruiter/RecruiterDashboard';
import { RecruiterJobsPage } from './pages/recruiter/RecruiterJobsPage';
import { CreateJobPage } from './pages/recruiter/CreateJobPage';
import { ApplicantManagementPage } from './pages/recruiter/ApplicantManagementPage';
import { CompanyProfilePage } from './pages/recruiter/CompanyProfilePage';

// Admin Pages
import { AdminDashboard } from './pages/admin/AdminDashboard';
import { AdminStudentsPage } from './pages/admin/AdminStudentsPage';
import { AdminCompaniesPage } from './pages/admin/AdminCompaniesPage';
import { AdminJobsPage } from './pages/admin/AdminJobsPage';
import { AdminAuditLogsPage } from './pages/admin/AdminAuditLogsPage';

// Common
import { NotificationsPage } from './pages/common/NotificationsPage';

export const App: React.FC = () => {
  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/" element={<LandingPage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register/student" element={<RegisterStudentPage />} />
      <Route path="/register/recruiter" element={<RegisterRecruiterPage />} />

      {/* Student Protected Routes */}
      <Route element={<DashboardLayout allowedRoles={['STUDENT']} />}>
        <Route path="/dashboard" element={<StudentDashboard />} />
        <Route path="/opportunities" element={<BrowseJobsPage />} />
        <Route path="/opportunities/:id" element={<JobDetailPage />} />
        <Route path="/applications" element={<StudentApplicationsPage />} />
        <Route path="/interviews" element={<StudentInterviewsPage />} />
        <Route path="/offers" element={<StudentOffersPage />} />
        <Route path="/profile" element={<StudentProfilePage />} />
      </Route>

      {/* Recruiter Protected Routes */}
      <Route element={<DashboardLayout allowedRoles={['RECRUITER']} />}>
        <Route path="/recruiter/dashboard" element={<RecruiterDashboard />} />
        <Route path="/recruiter/jobs" element={<RecruiterJobsPage />} />
        <Route path="/recruiter/jobs/create" element={<CreateJobPage />} />
        <Route path="/recruiter/jobs/:id/applicants" element={<ApplicantManagementPage />} />
        <Route path="/recruiter/company" element={<CompanyProfilePage />} />
      </Route>

      {/* Admin Protected Routes */}
      <Route element={<DashboardLayout allowedRoles={['ADMIN']} />}>
        <Route path="/admin/dashboard" element={<AdminDashboard />} />
        <Route path="/admin/students" element={<AdminStudentsPage />} />
        <Route path="/admin/companies" element={<AdminCompaniesPage />} />
        <Route path="/admin/jobs" element={<AdminJobsPage />} />
        <Route path="/admin/audit-logs" element={<AdminAuditLogsPage />} />
      </Route>

      {/* Common Authenticated Routes */}
      <Route element={<DashboardLayout allowedRoles={['STUDENT', 'RECRUITER', 'ADMIN']} />}>
        <Route path="/notifications" element={<NotificationsPage />} />
      </Route>

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

